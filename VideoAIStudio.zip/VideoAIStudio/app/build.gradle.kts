plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.videoaistudio.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.videoaistudio.app"
        // Zenfone 8 chạy Android 11 (API 30) trở lên, đặt minSdk 26 để tương thích rộng
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-skeleton"

        ndk {
            // Snapdragon 888 trên Zenfone 8 là arm64
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // --- Phát video xem trước cho tính năng Trim/Split trực quan ---
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")

    // --- Local AI inference (Phase 2 + bắt đầu Phase 3: QNN) ---
    // Chuyển từ TensorFlow Lite sang ONNX Runtime Mobile:
    // - Có sẵn gói Kotlin/Java (.aar), không cần viết JNI riêng như NCNN.
    // - Không dính bug đóng gói GpuDelegateFactory đang tồn đọng ở TFLite/LiteRT.
    // - Có đường NNAPI (lớp nền) và có thể mở rộng QNN Execution Provider
    //   (lớp nâng cao, ép chạy thẳng Hexagon NPU) ở phase sau.
    //
    // CẬP NHẬT: đổi từ "onnxruntime-android" (bản thường, chỉ CPU/NNAPI) sang
    // "onnxruntime-android-qnn" — bản do chính Microsoft/Qualcomm phát hành sẵn
    // trên Maven Central, ĐÃ ĐÓNG GÓI SẴN QNN Execution Provider (thư viện native
    // Hexagon HTP của Qualcomm) bên trong, KHÔNG cần tự tải QAIRT SDK riêng như
    // ghi chú cũ (đúng theo tài liệu chính thức ONNX Runtime từ bản 1.18.0 trở đi).
    // ĐÁNH ĐỔI cần biết: file .aar này NẶNG HƠN đáng kể (kèm thư viện native Hexagon),
    // APK sẽ to hơn vài chục MB so với bản thường. CHƯA build/test thật — nếu Gradle
    // không resolve được version này hoặc NNAPI (lớp nền) bị ảnh hưởng, đây là chỗ
    // đầu tiên cần xem lại.
    implementation("com.microsoft.onnxruntime:onnxruntime-android-qnn:1.21.1")

    // --- Xử lý video: trim/split/merge/tách audio/nén ---
    // LƯU Ý: thư viện gốc "ffmpeg-kit" (arthenica) đã NGỪNG PHÁT TRIỂN từ 4/2025,
    // binary bị gỡ khỏi Maven Central. Dùng fork cộng đồng dưới đây (giữ nguyên API
    // gốc, chỉ cập nhật để tương thích Android mới) vì đây là lựa chọn khả dụng
    // đơn giản nhất không cần tự build NDK. Nếu fork này ngừng duy trì, chỉ cần
    // đổi dependency này + VideoEngine.kt, không ảnh hưởng phần còn lại của app.
    implementation("com.moizhassan.ffmpeg:ffmpeg-kit-16kb:6.1.1")

    // --- Gọi API cloud model (Phase 2 sẽ dùng) ---
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // --- Xử lý video: trim/split/merge/tách audio/nén (Phase 3 sẽ dùng) ---
    // Lưu ý: thêm dependency FFmpeg-Kit ở Phase 3 khi bắt đầu code video engine,
    // để tránh build lỗi ở bản skeleton này (repo ffmpeg-kit đã ngừng cập nhật,
    // Phase 3 sẽ chốt lại nguồn build phù hợp nhất tại thời điểm đó).

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}
