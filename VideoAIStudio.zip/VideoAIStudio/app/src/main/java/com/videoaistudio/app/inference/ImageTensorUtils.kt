package com.videoaistudio.app.inference

import android.graphics.Bitmap
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import java.nio.FloatBuffer

/**
 * Chuyển đổi Bitmap <-> Tensor theo ĐÚNG QUY ƯỚC CHUNG mà đại đa số model
 * super-resolution ONNX (ESRGAN, Real-ESRGAN, SRCNN và các biến thể) sử dụng:
 * - Giá trị pixel chuẩn hoá về [0,1] (chia 255), không phải [0,255] hay [-1,1].
 * - Thứ tự kênh màu RGB (không phải BGR).
 *
 * Đây KHÔNG phải hardcode riêng cho 1 model — đây là quy ước phổ biến nhất của
 * CẢ THỂ LOẠI model upscale ảnh, áp dụng chung cho mọi model theo layout mà
 * detectUpscaleModelSpec() đã tự dò được (NCHW hoặc NHWC).
 *
 * Giới hạn thành thật: một số ít model dùng quy ước khác ([-1,1] hoặc [0,255]).
 * Nếu ảnh ra bị sai màu/quá sáng/quá tối, đó là dấu hiệu model thuộc nhóm thiểu số
 * này — cần bổ sung tuỳ chọn normalization khác ở bản sau, không phải lỗi code.
 */
object ImageTensorUtils {

    fun bitmapToTensor(env: OrtEnvironment, bitmap: Bitmap, layout: TensorLayout): OnnxTensor {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val floatArray = FloatArray(3 * width * height)

        if (layout == TensorLayout.NCHW) {
            // [1,3,H,W]: từng kênh liền mạch nhau
            val channelSize = width * height
            for (i in pixels.indices) {
                val p = pixels[i]
                floatArray[i] = ((p shr 16) and 0xFF) / 255f                  // R
                floatArray[channelSize + i] = ((p shr 8) and 0xFF) / 255f     // G
                floatArray[2 * channelSize + i] = (p and 0xFF) / 255f         // B
            }
        } else {
            // [1,H,W,3]: xen kẽ R,G,B liên tiếp theo từng pixel
            for (i in pixels.indices) {
                val p = pixels[i]
                floatArray[i * 3] = ((p shr 16) and 0xFF) / 255f
                floatArray[i * 3 + 1] = ((p shr 8) and 0xFF) / 255f
                floatArray[i * 3 + 2] = (p and 0xFF) / 255f
            }
        }

        val shape = if (layout == TensorLayout.NCHW) {
            longArrayOf(1, 3, height.toLong(), width.toLong())
        } else {
            longArrayOf(1, height.toLong(), width.toLong(), 3)
        }

        return OnnxTensor.createTensor(env, FloatBuffer.wrap(floatArray), shape)
    }

    fun tensorToBitmap(floatArray: FloatArray, width: Int, height: Int, layout: TensorLayout): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(width * height)
        val channelSize = width * height

        for (i in 0 until width * height) {
            val r: Float
            val g: Float
            val b: Float
            if (layout == TensorLayout.NCHW) {
                r = floatArray[i]
                g = floatArray[channelSize + i]
                b = floatArray[2 * channelSize + i]
            } else {
                r = floatArray[i * 3]
                g = floatArray[i * 3 + 1]
                b = floatArray[i * 3 + 2]
            }
            val ri = (r.coerceIn(0f, 1f) * 255).toInt()
            val gi = (g.coerceIn(0f, 1f) * 255).toInt()
            val bi = (b.coerceIn(0f, 1f) * 255).toInt()
            pixels[i] = (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        return bitmap
    }
}
