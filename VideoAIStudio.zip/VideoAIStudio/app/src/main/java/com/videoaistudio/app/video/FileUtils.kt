package com.videoaistudio.app.video

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * FFmpeg cần đường dẫn file thật, trong khi Android (từ scoped storage) trả về
 * content:// Uri khi người dùng chọn file qua trình chọn hệ thống. Hàm này copy
 * nội dung Uri ra file tạm trong bộ nhớ riêng của app để xử lý.
 */
object FileUtils {

    /**
     * Copy file người dùng chọn (model .onnx, file labels...) vào bộ nhớ riêng LÂU DÀI
     * của app (khác với cache tạm dùng cho video input, có thể bị hệ thống dọn bất kỳ lúc nào).
     */
    fun copyUriToPermanentStorage(context: Context, uri: Uri, subDir: String, suggestedName: String): File {
        val dir = File(context.getExternalFilesDir(null), subDir).apply { mkdirs() }
        val destFile = File(dir, suggestedName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("Không đọc được file đã chọn")
        return destFile
    }

    /** Dọn sạch cache video input — gọi khi mở lại màn hình chọn video, tránh tích tụ
     *  dung lượng qua nhiều phiên (đặc biệt sau các lần bị crash giữa chừng, file cũ
     *  không được dọn sẽ nằm mãi trong cache và chiếm dung lượng oan). */
    fun clearVideoInputCache(context: Context) {
        File(context.cacheDir, "video_input").deleteRecursively()
    }

    fun copyUriToCache(context: Context, uri: Uri, suggestedName: String): File {
        val cacheDir = File(context.cacheDir, "video_input").apply { mkdirs() }
        val destFile = File(cacheDir, suggestedName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalStateException("Không đọc được file đã chọn")
        return destFile
    }

    /**
     * Copy file phụ đề người dùng chọn vào cache — LUÔN dùng tên CỐ ĐỊNH đơn giản
     * ("subtitle_input.<đuôi gốc>"), KHÔNG dùng tên file gốc như `copyUriToCache()` ở
     * trên vẫn làm cho video. Lý do: đường dẫn phụ đề sẽ được nhét thẳng vào cú pháp
     * filter FFmpeg `subtitles=<đường_dẫn>` — nếu tên file gốc có dấu cách, dấu `:`,
     * dấu `'`... có thể làm SAI CÚ PHÁP filter (lỗi khó nhận ra, không phải kiểu lỗi
     * "không tìm thấy file" rõ ràng). Dùng tên tự đặt, đơn giản, tránh hẳn rủi ro này
     * thay vì phải viết logic escape ký tự đặc biệt (dễ sai, khó test đủ mọi trường hợp).
     */
    fun copySubtitleToCache(context: Context, uri: Uri, originalName: String): File {
        val cacheDir = File(context.cacheDir, "video_input").apply { mkdirs() }
        val ext = originalName.substringAfterLast('.', "srt").lowercase().filter { it.isLetterOrDigit() }.ifBlank { "srt" }
        val destFile = File(cacheDir, "subtitle_input.$ext")
        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("Không đọc được file phụ đề đã chọn")
        return destFile
    }

    /** Đọc FPS thật của video để dựng lại đúng tốc độ gốc sau khi xử lý frame-by-frame. */
    /** Đọc thời lượng video (giây) để chia thành các chunk xử lý cuốn chiếu. */
    /** Đọc bitrate gốc của video (bit/giây) — dùng làm cơ sở ước lượng dung lượng sau upscale,
     *  thay vì tra bảng "bitrate chuẩn cho 4K" (sai lệch vì không phản ánh đúng nội dung thật). */
    /**
     * Tính bitrate THẬT dựa trên dung lượng file / thời lượng — cách này LUÔN CHÍNH XÁC
     * về mặt toán học (không như metadata trong file có thể bị ghi sai hoặc thiếu tuỳ
     * codec/container). Đây là bản sửa cho lỗi "nén ra nặng hơn cả gốc" — nguyên nhân
     * là bitrate đọc từ metadata (getVideoBitrate) có thể sai, khiến app tính nhầm mức
     * bitrate mục tiêu cao hơn cả bitrate gốc thật.
     */
    fun calculateActualBitrateBps(path: String): Long {
        val durationSec = getVideoDurationSec(path)
        if (durationSec <= 0) return 0L
        val fileSizeBits = File(path).length() * 8
        return (fileSizeBits / durationSec).toLong()
    }

    fun getVideoBitrate(path: String): Long {
        val retriever = android.media.MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            retriever.release()
        }
    }

    /**
     * Ước lượng dung lượng sau upscale khi nén bằng QP qua libkvazaar — dùng lại đúng
     * nguyên lý CRF/QP: cứ +6 vào QP thì bitrate giảm khoảng một nửa (quy tắc kinh
     * nghiệm phổ biến trong encoding, áp dụng tương tự cho QP vì cùng cơ chế lượng tử
     * hoá, dù QP kém tinh vi hơn CRF thật một chút).
     */
    fun estimateUpscaledSizeBytes(originalBitrateBps: Long, scaleFactor: Int, durationSec: Double, qp: Int): Long {
        if (originalBitrateBps <= 0) return 0L
        val pixelRatio = (scaleFactor * scaleFactor).toDouble()
        val smoothingFactor = 0.8
        val qpAdjust = Math.pow(2.0, (26 - qp) / 6.0) // mốc QP 26 ~ CRF 23 x264
        val estimatedBitrate = originalBitrateBps * pixelRatio * smoothingFactor * qpAdjust
        return (estimatedBitrate * durationSec / 8).toLong()
    }

    fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        // Ép Locale.US để luôn hiện dấu chấm thập phân, tránh lẫn lộn với dấu phẩy
        // ngăn cách hàng nghìn/đơn vị khi hiển thị, dù đây chỉ là text hiển thị (không
        // ảnh hưởng lệnh FFmpeg) nhưng vẫn nên nhất quán.
        return if (mb >= 1024) "%.2f GB".format(java.util.Locale.US, mb / 1024.0) else "%.1f MB".format(java.util.Locale.US, mb)
    }

    /**
     * Với "-c copy" (không encode lại), FFmpeg BẮT BUỘC phải bắt đầu file output đúng
     * tại 1 khung hình khoá (keyframe/sync sample) — không thể cắt giữa chừng 1 GOP vì
     * không giải mã lại. Vì vậy khi người dùng chọn giây X làm điểm bắt đầu, FFmpeg sẽ
     * tự động lùi về khung hình khoá gần nhất TRƯỚC hoặc ĐÚNG giây X đó — đây chính là
     * nguyên nhân "số giây hiển thị trên preview khác với video output thật": preview
     * (ExoPlayer) tua chính xác tới đúng khung hình bất kỳ, nhưng file cắt ra thì không.
     *
     * Hàm này tìm ĐÚNG khung hình khoá đó (dùng MediaExtractor.SEEK_TO_PREVIOUS_SYNC —
     * chính cơ chế FFmpeg dùng bên trong khi input-seeking + stream copy), để UI có thể
     * hiển thị/tua preview tới ĐÚNG giây mà video output sẽ thật sự bắt đầu, thay vì để
     * người dùng thấy 1 giây rồi ra 1 giây khác.
     */
    fun findPrecedingKeyframeSec(path: String, targetSec: Double): Double {
        if (targetSec <= 0.0) return 0.0
        val extractor = android.media.MediaExtractor()
        return try {
            extractor.setDataSource(path)
            var videoTrack = -1
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(android.media.MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) { videoTrack = i; break }
            }
            if (videoTrack < 0) return targetSec
            extractor.selectTrack(videoTrack)
            val targetUs = (targetSec * 1_000_000L).toLong()
            extractor.seekTo(targetUs, android.media.MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val actualUs = extractor.sampleTime
            if (actualUs < 0) targetSec else actualUs / 1_000_000.0
        } catch (e: Exception) {
            targetSec // đọc lỗi -> giữ nguyên giá trị gốc, không chặn luồng sử dụng
        } finally {
            extractor.release()
        }
    }

    fun getVideoDurationSec(path: String): Double {
        val retriever = android.media.MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            val durationMs = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            durationMs / 1000.0
        } catch (e: Exception) {
            0.0
        } finally {
            retriever.release()
        }
    }

    fun getVideoFps(path: String): Double {
        val extractor = android.media.MediaExtractor()
        return try {
            extractor.setDataSource(path)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(android.media.MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && format.containsKey(android.media.MediaFormat.KEY_FRAME_RATE)) {
                    return format.getInteger(android.media.MediaFormat.KEY_FRAME_RATE).toDouble()
                }
            }
            30.0 // mặc định an toàn nếu không đọc được (hiếm khi xảy ra)
        } catch (e: Exception) {
            30.0
        } finally {
            extractor.release()
        }
    }

    fun getOutputDir(context: Context): File {
        val dir = context.getExternalFilesDir("VideoAIStudioOutput") ?: context.filesDir
        dir.mkdirs()
        return dir
    }

    fun queryDisplayName(context: Context, uri: Uri): String {
        var name = "video_${System.currentTimeMillis()}"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }
}
