package com.videoaistudio.app.inference

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.nio.FloatBuffer

/**
 * Chạy model do người dùng tự chọn (.onnx) — đọc THẲNG nội dung từ Content URI vào
 * RAM để nạp vào ONNX Runtime, KHÔNG copy ra thành file riêng trên ổ đĩa. Lý do đổi
 * cách này: copy ra đĩa sẽ chiếm gấp đôi dung lượng máy một cách không cần thiết,
 * nhất là với model vài trăm MB — đọc thẳng vào RAM rồi giải phóng ngay sau khi
 * nạp xong (ONNX Runtime giữ bản sao trong bộ nhớ của chính nó, buffer tạm này
 * có thể giải phóng) là cách dùng tài nguyên hợp lý hơn.
 */
class LocalModelProvider(
    private val context: Context,
    private val config: ModelConfig
) : IInferenceProvider {

    private val ortEnv: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }
    private var session: OrtSession? = null

    private fun readModelBytes(): ByteArray {
        val pathOrUri = config.localFilePath
            ?: throw IllegalArgumentException("ModelConfig thiếu localFilePath cho model local: ${config.displayName}")

        return if (pathOrUri.startsWith("content://")) {
            context.contentResolver.openInputStream(Uri.parse(pathOrUri))?.use { it.readBytes() }
                ?: throw IllegalStateException("Không đọc được model từ URI (có thể quyền truy cập đã bị thu hồi)")
        } else {
            // Tương thích ngược cho trường hợp có sẵn đường dẫn file thật (ít dùng tới).
            val f = File(pathOrUri)
            require(f.exists()) { "Không tìm thấy file model tại: $pathOrUri" }
            f.readBytes()
        }
    }

    private fun loadSessionIfNeeded() {
        if (session != null) return

        val modelBytes = readModelBytes()
        val options = OrtSession.SessionOptions()

        when (config.hardwareTarget) {
            HardwareTarget.GPU_NPU_AUTO -> {
                options.addNnapi()
            }
            HardwareTarget.NPU_QNN_FORCED -> {
                // TRIỂN KHAI THẬT (Phase 3) — trước đây luôn throw ở đây.
                //
                // Dùng QNN Execution Provider có sẵn trong gói
                // "onnxruntime-android-qnn" (xem app/build.gradle.kts) — KHÔNG cần tải
                // riêng QAIRT SDK, thư viện native Hexagon HTP đã nằm sẵn trong APK sau
                // khi build, Android tự giải nén vào thư mục native lib riêng của app.
                //
                // "backend_path" PHẢI trỏ đúng đường dẫn thật của libQnnHtp.so trên máy
                // (không phải chỉ tên file suông) — dùng applicationInfo.nativeLibraryDir
                // để lấy đúng đường dẫn, vì đây là nơi Android giải nén các thư viện .so
                // đóng gói theo từng ABI khi cài app.
                try {
                    val nativeLibDir = context.applicationInfo.nativeLibraryDir
                    val htpBackend = File(nativeLibDir, "libQnnHtp.so")
                    if (!htpBackend.exists()) {
                        throw UnsupportedOperationException(
                            "Không tìm thấy thư viện QNN HTP ($htpBackend) trong app. " +
                            "Máy này có thể không hỗ trợ kiến trúc CPU (ABI) mà QNN yêu cầu " +
                            "(cần arm64-v8a), hoặc gói onnxruntime-android-qnn chưa được " +
                            "build đúng cho thiết bị này."
                        )
                    }
                    // FIX: dùng đúng hàm Java API CHÍNH THỨC "addQnn(Map<String,String>)"
                    // (xem Javadoc: OrtSession.SessionOptions trên onnxruntime.ai) thay vì
                    // "addExecutionProvider(\"QNN\", map)" — hàm đó KHÔNG có overload nhận
                    // String tên provider trong Java API của ONNX Runtime; overload thật
                    // của addExecutionProvider() nhận List<OrtEpDevice>, không phải String.
                    // Gọi sai overload có thể không compile được hoặc gọi nhầm API khác.
                    options.addQnn(
                        mapOf(
                            "backend_path" to htpBackend.absolutePath,
                            // "burst": ưu tiên tốc độ tối đa cho phiên chạy ngắn (đúng use-case
                            // xử lý từng frame video), đánh đổi hao pin hơn so với "balanced".
                            "htp_performance_mode" to "burst"
                        )
                    )
                } catch (e: UnsupportedOperationException) {
                    throw e
                } catch (e: Exception) {
                    // QNN EP có thể ném lỗi native (UnsatisfiedLinkError, RuntimeException...)
                    // nếu chip không có Hexagon NPU tương thích hoặc driver máy quá cũ/mới so
                    // với bản QNN đóng gói — bọc lại thành 1 loại lỗi rõ ràng, nhất quán với
                    // hành vi cũ (throw UnsupportedOperationException) để UI xử lý đồng nhất.
                    throw UnsupportedOperationException(
                        "Máy này không chạy được QNN (Hexagon NPU): ${e.message}. " +
                        "Hãy dùng lớp nền (GPU/NPU tự động) thay thế.",
                        e
                    )
                }
            }
            HardwareTarget.CPU -> {
                // Không thêm EP nào -> ONNX Runtime mặc định chạy CPU.
            }
        }

        session = ortEnv.createSession(modelBytes, options)
    }

    /**
     * Kiểm tra khả năng chạy model trên phần cứng đã cấu hình, kèm ước lượng
     * % phép tính chạy được trên accelerator (GPU/NPU) so với CPU khi dùng lớp nền.
     * UI gọi hàm này khi người dùng bấm "Kiểm tra model" hoặc trước lần chạy đầu tiên,
     * để quyết định chấp nhận hiệu suất hay tìm model khác.
     */
    suspend fun checkCompatibility(): CompatibilityReport = withContext(Dispatchers.Default) {
        try {
            loadSessionIfNeeded()
            session ?: throw IllegalStateException("Session chưa khởi tạo")

            when (config.hardwareTarget) {
                HardwareTarget.NPU_QNN_FORCED -> {
                    // Giờ CÓ THỂ tới được đây thật (trước đây throw ở loadSessionIfNeeded
                    // nên nhánh này chỉ là code chết). Không có API đếm % phép tính chạy
                    // trên Hexagon HTP như NNAPI profiling ở nhánh GPU_NPU_AUTO bên dưới —
                    // QNN EP của ONNX Runtime hiện chưa lộ thông tin breakdown này qua log
                    // profiling theo cùng định dạng, nên chỉ báo "chạy được", không có %.
                    CompatibilityReport(
                        hardwareTarget = config.hardwareTarget,
                        loadSucceeded = true,
                        message = "Model nạp thành công qua QNN (Hexagon NPU)."
                    )
                }
                HardwareTarget.GPU_NPU_AUTO -> {
                    val breakdown = estimateHardwareBreakdown()
                    CompatibilityReport(
                        hardwareTarget = config.hardwareTarget,
                        loadSucceeded = true,
                        percentOpsOnAccelerator = breakdown?.first,
                        percentOpsOnCpu = breakdown?.second,
                        message = if (breakdown != null) {
                            "Model chạy được. Ước tính ${breakdown.first}% phép tính qua GPU/NPU, ${breakdown.second}% qua CPU."
                        } else {
                            "Model chạy được qua NNAPI, nhưng không xác định được chi tiết tỉ lệ GPU/NPU vs CPU trên thiết bị này."
                        }
                    )
                }
                HardwareTarget.CPU -> {
                    CompatibilityReport(
                        hardwareTarget = config.hardwareTarget,
                        loadSucceeded = true,
                        percentOpsOnAccelerator = 0,
                        percentOpsOnCpu = 100,
                        message = "Chạy hoàn toàn trên CPU (không dùng accelerator)."
                    )
                }
            }
        } catch (e: UnsupportedOperationException) {
            CompatibilityReport(
                hardwareTarget = config.hardwareTarget,
                loadSucceeded = false,
                message = e.message ?: "Chế độ phần cứng này chưa được hỗ trợ."
            )
        } catch (e: Exception) {
            CompatibilityReport(
                hardwareTarget = config.hardwareTarget,
                loadSucceeded = false,
                message = "Model không tương thích hoặc lỗi khi nạp: ${e.message}"
            )
        }
    }

    /**
     * Chạy thử 1 lần suy luận với input rỗng (giá trị 0) để bật profiling, đọc lại
     * log profiling của ONNX Runtime nhằm ước lượng số phép tính chạy trên NNAPI EP
     * so với CPU EP fallback. Đây là ước lượng best-effort: nếu định dạng log
     * profiling thay đổi giữa các phiên bản ONNX Runtime, hàm sẽ trả null thay vì
     * báo số liệu sai.
     */
    private fun estimateHardwareBreakdown(): Pair<Int, Int>? {
        var profSession: OrtSession? = null
        val tensors = mutableListOf<OnnxTensor>()
        return try {
            val profilingOptions = OrtSession.SessionOptions().apply { addNnapi() }
            profilingOptions.enableProfiling("model_profile")
            profSession = ortEnv.createSession(readModelBytes(), profilingOptions)

            val inputs = mutableMapOf<String, OnnxTensor>()
            profSession.inputInfo.forEach { (name, info) ->
                val tensorInfo = info.info as? ai.onnxruntime.TensorInfo ?: return@forEach
                val fixedShape = tensorInfo.shape.map { if (it <= 0) 1L else it }.toLongArray()
                val size = fixedShape.fold(1L) { acc, d -> acc * d }.toInt()
                val tensor = OnnxTensor.createTensor(ortEnv, FloatBuffer.allocate(size), fixedShape)
                tensors.add(tensor)
                inputs[name] = tensor
            }

            if (inputs.isNotEmpty()) {
                profSession.run(inputs)
            }
            val profileFilePath = profSession.endProfiling()

            val profileFile = File(profileFilePath)
            if (!profileFile.exists()) return null

            val json = JSONArray(profileFile.readText())
            var acceleratedCount = 0
            var cpuCount = 0
            for (i in 0 until json.length()) {
                val entry = json.optJSONObject(i) ?: continue
                val args = entry.optJSONObject("args") ?: continue
                val provider = args.optString("provider", "")
                when {
                    provider.contains("Nnapi", ignoreCase = true) -> acceleratedCount++
                    provider.contains("CPU", ignoreCase = true) -> cpuCount++
                }
            }
            profileFile.delete()

            val total = acceleratedCount + cpuCount
            if (total == 0) return null

            val acceleratedPercent = (acceleratedCount * 100) / total
            Pair(acceleratedPercent, 100 - acceleratedPercent)
        } catch (e: Exception) {
            null
        } finally {
            tensors.forEach { it.close() }
            profSession?.close()
        }
    }

    /**
     * Tự dò cấu trúc I/O của model upscale, KHÔNG hardcode bất kỳ model cụ thể nào —
     * áp dụng nguyên lý chung của mọi model super-resolution: nhận 1 ảnh, trả 1 ảnh
     * lớn hơn theo 1 hệ số cố định.
     *
     * Cách dò:
     * 1. Đọc shape input để biết bố cục NCHW ([1,3,H,W]) hay NHWC ([1,H,W,3]).
     * 2. Chạy thử với 1 ảnh giả kích thước cố định (dummy), so sánh kích thước
     *    output/input để tự tính hệ số upscale thực tế của MODEL ĐÓ (x2/x3/x4...),
     *    không cần người dùng khai báo tay, không cần biết trước tên/kiến trúc model.
     */
    suspend fun detectUpscaleModelSpec(): UpscaleModelSpec? = withContext(Dispatchers.Default) {
        val modelPath = config.localFilePath ?: return@withContext null
        var probeSession: OrtSession? = null
        val tensors = mutableListOf<OnnxTensor>()
        try {
            probeSession = ortEnv.createSession(readModelBytes(), OrtSession.SessionOptions())

            val inputEntry = probeSession.inputInfo.entries.firstOrNull() ?: return@withContext null
            val inputTensorInfo = inputEntry.value.info as? ai.onnxruntime.TensorInfo ?: return@withContext null
            val shape = inputTensorInfo.shape // vd [1,3,-1,-1] (NCHW) hoặc [1,-1,-1,3] (NHWC)

            val isNCHW = shape.size == 4 && shape[1] == 3L
            val isNHWC = shape.size == 4 && shape[3] == 3L
            if (!isNCHW && !isNHWC) return@withContext null // không nhận diện được bố cục -> báo không hỗ trợ, không đoán bừa

            val probeSize = 64 // kích thước ảnh giả nhỏ để dò nhanh, không tốn tài nguyên
            val dummyShape = if (isNCHW) longArrayOf(1, 3, probeSize.toLong(), probeSize.toLong())
                              else longArrayOf(1, probeSize.toLong(), probeSize.toLong(), 3)
            val elementCount = dummyShape.fold(1L) { acc, d -> acc * d }.toInt()
            val dummyTensor = OnnxTensor.createTensor(ortEnv, FloatBuffer.allocate(elementCount), dummyShape)
            tensors.add(dummyTensor)

            val outputs = probeSession.run(mapOf(inputEntry.key to dummyTensor))
            val outputTensorInfo = outputs[0].info as? ai.onnxruntime.TensorInfo ?: return@withContext null
            val outShape = outputTensorInfo.shape
            outputs.close()

            val outHeight = if (isNCHW) outShape.getOrNull(2) else outShape.getOrNull(1)
            val outWidth = if (isNCHW) outShape.getOrNull(3) else outShape.getOrNull(2)
            if (outHeight == null || outWidth == null || outHeight <= 0 || outWidth <= 0) return@withContext null

            val scaleFactor = (outHeight.toDouble() / probeSize).let { Math.round(it).toInt() }
                .coerceAtLeast(1)

            UpscaleModelSpec(
                layout = if (isNCHW) TensorLayout.NCHW else TensorLayout.NHWC,
                detectedScaleFactor = scaleFactor,
                supportsDynamicResolution = shape.any { it <= 0 }
            )
        } catch (e: Exception) {
            null
        } finally {
            tensors.forEach { it.close() }
            probeSession?.close()
        }
    }

    /**
     * Chạy upscale cho 1 frame ảnh bất kỳ, dùng ĐÚNG layout (NCHW/NHWC) đã tự dò được
     * từ chính model — không hardcode kiến trúc của bất kỳ model cụ thể nào.
     */
    suspend fun upscaleFrame(bitmap: android.graphics.Bitmap, layout: TensorLayout): android.graphics.Bitmap? =
        withContext(Dispatchers.Default) {
            try {
                loadSessionIfNeeded()
                val currentSession = session ?: return@withContext null
                val inputName = currentSession.inputNames.first()

                val inputTensor = ImageTensorUtils.bitmapToTensor(ortEnv, bitmap, layout)
                val results = currentSession.run(mapOf(inputName to inputTensor))
                inputTensor.close()

                val outputInfo = results[0].info as? ai.onnxruntime.TensorInfo
                val outShape = outputInfo?.shape
                @Suppress("UNCHECKED_CAST")
                val rawOutput = results[0].value

                val outHeight = (if (layout == TensorLayout.NCHW) outShape?.getOrNull(2) else outShape?.getOrNull(1))?.toInt() ?: return@withContext null
                val outWidth = (if (layout == TensorLayout.NCHW) outShape?.getOrNull(3) else outShape?.getOrNull(2))?.toInt() ?: return@withContext null

                val flatArray = flattenOnnxOutput(rawOutput)
                results.close()

                if (flatArray == null) return@withContext null
                ImageTensorUtils.tensorToBitmap(flatArray, outWidth, outHeight, layout)
            } catch (e: Exception) {
                null
            }
        }

    /** ONNX Runtime trả output dạng mảng lồng nhau (float[][][][]) — làm phẳng thành FloatArray 1 chiều. */
    private fun flattenOnnxOutput(value: Any?): FloatArray? {
        val result = mutableListOf<Float>()
        fun recurse(v: Any?) {
            when (v) {
                is FloatArray -> v.forEach { result.add(it) }
                is Array<*> -> v.forEach { recurse(it) }
                else -> {}
            }
        }
        recurse(value)
        return if (result.isEmpty()) null else result.toFloatArray()
    }

    /**
     * Chạy inference thô cho model detection, trả về (mảng số phẳng, shape output).
     * Việc giải mã (decode YOLO-style, NMS...) làm ở lớp ngoài (DetectionUtils) để
     * LocalModelProvider chỉ lo phần "chạy model", không gắn cứng logic của 1 họ
     * model detection cụ thể nào vào đây.
     *
     * Giả định input vuông (WxW) theo đúng chuẩn phổ biến của model YOLO-style
     * (thường 640x640). Đọc kích thước thật từ chính model, không hardcode.
     */
    suspend fun runRawDetection(bitmap: android.graphics.Bitmap): Pair<FloatArray, LongArray>? =
        withContext(Dispatchers.Default) {
            try {
                loadSessionIfNeeded()
                val currentSession = session ?: return@withContext null
                val inputName = currentSession.inputNames.first()
                val inputInfo = currentSession.inputInfo[inputName]?.info as? ai.onnxruntime.TensorInfo
                    ?: return@withContext null
                val shape = inputInfo.shape // vd [1,3,640,640]

                val isNCHW = shape.size == 4 && shape[1] == 3L
                val inputSize = (if (isNCHW) shape.getOrNull(2) else shape.getOrNull(1))?.toInt()?.takeIf { it > 0 } ?: 640

                val resized = android.graphics.Bitmap.createScaledBitmap(bitmap, inputSize, inputSize, true)
                val layout = if (isNCHW) TensorLayout.NCHW else TensorLayout.NHWC
                val inputTensor = ImageTensorUtils.bitmapToTensor(ortEnv, resized, layout)
                if (resized != bitmap) resized.recycle()

                val results = currentSession.run(mapOf(inputName to inputTensor))
                inputTensor.close()

                val outputInfo = results[0].info as? ai.onnxruntime.TensorInfo ?: return@withContext null
                val outShape = outputInfo.shape
                val flat = flattenOnnxOutput(results[0].value)
                results.close()

                if (flat == null) null else flat to outShape
            } catch (e: Exception) {
                null
            }
        }

    /** Kích thước input vuông thật của model (để lớp ngoài biết cách scale toạ độ box về ảnh gốc). */
    suspend fun getSquareInputSize(): Int = withContext(Dispatchers.Default) {
        try {
            loadSessionIfNeeded()
            val currentSession = session ?: return@withContext 640
            val inputName = currentSession.inputNames.first()
            val inputInfo = currentSession.inputInfo[inputName]?.info as? ai.onnxruntime.TensorInfo ?: return@withContext 640
            val shape = inputInfo.shape
            val isNCHW = shape.size == 4 && shape[1] == 3L
            (if (isNCHW) shape.getOrNull(2) else shape.getOrNull(1))?.toInt()?.takeIf { it > 0 } ?: 640
        } catch (e: Exception) {
            640
        }
    }

    override suspend fun isReady(): Boolean = withContext(Dispatchers.IO) {
        try {
            loadSessionIfNeeded()
            true
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun runInference(input: InferenceInput): InferenceOutput = withContext(Dispatchers.Default) {
        try {
            loadSessionIfNeeded()

            // TODO (bước tiếp theo - riêng theo từng TaskType):
            // Mỗi tác vụ (upscale / detect / segment) có tiền xử lý (resize, normalize)
            // và hậu xử lý (decode bounding box, ghép ảnh...) khác nhau.
            // Đây là chỗ sẽ cắm logic cụ thể cho từng loại model.

            InferenceOutput(
                success = false,
                errorMessage = "Chưa cài đặt logic xử lý cho tác vụ ${input.taskType} (sẽ bổ sung ở các bước tiếp theo)."
            )
        } catch (e: Exception) {
            InferenceOutput(success = false, errorMessage = e.message)
        }
    }

    override fun release() {
        session?.close()
        session = null
    }
}
