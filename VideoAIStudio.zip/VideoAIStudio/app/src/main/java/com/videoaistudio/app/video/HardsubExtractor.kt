package com.videoaistudio.app.video

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File

/**
 * TÍNH NĂNG MỚI (06/09/2026): tách phụ đề TỪ video đã có sẵn phụ đề CỨNG (hardsub — chữ dính
 * cứng vào hình, không có track phụ đề riêng để đọc thẳng ra).
 *
 * CHƯA CÓ CÁCH NÀO ĐỌC "HOÀN HẢO" — đây là bài toán OCR (nhận diện chữ trong ảnh), LUÔN có tỉ
 * lệ sai nhất định (chữ nghiêng, màu nền phức tạp, phông chữ lạ, chữ nhỏ, video nén mất nét...).
 * Kết quả trả về là BẢN NHÁP để người dùng tự sửa lại, KHÔNG PHẢI kết quả chắc chắn đúng 100%
 * như đọc thẳng 1 track phụ đề có sẵn.
 *
 * THUẬT TOÁN (không có "công thức chuẩn" chung cho việc này, đây là cách tiếp cận hợp lý,
 * đơn giản, tận dụng lại đúng pattern lấy mẫu frame đã có sẵn trong `ObjectExtractActivity`):
 *   1. Lấy mẫu frame theo nhịp cố định (mặc định 2 frame/giây) bằng FFmpeg `-vf fps=...`
 *      (CÙNG kỹ thuật `ObjectExtractActivity.sampleFrames()` đã dùng — không phát minh lại).
 *   2. Với MỖI frame: cắt lấy vùng dưới cùng ảnh (mặc định 25% chiều cao, tính từ đáy lên) —
 *      giả định phụ đề luôn nằm ở dưới, giả định ĐÚNG với đa số video nhưng KHÔNG PHẢI luôn
 *      luôn đúng (phụ đề trên đầu hoặc giữa hình sẽ bị bỏ sót — CHƯA xử lý được trường hợp này).
 *   3. Chạy OCR (ML Kit, model Latin — đủ cho tiếng Việt có dấu + tiếng Anh) lên từng vùng cắt.
 *   4. Gộp các frame LIÊN TIẾP có chữ GIỐNG NHAU (so bằng tỉ lệ khớp ký tự, không cần khớp
 *      tuyệt đối — vì OCR có thể đọc lệch 1-2 ký tự giữa các frame dù nhìn cùng 1 dòng phụ đề)
 *      thành 1 "đoạn thoại" — thời điểm bắt đầu/kết thúc lấy theo frame ĐẦU/CUỐI của đoạn đó.
 *   5. Xuất ra định dạng .srt chuẩn.
 *
 * 🔴 CHƯA TEST THẬT TRÊN MÁY — tính năng phức tạp nhất trong tất cả các tính năng phụ đề đã
 * làm, nhiều khả năng cần chỉnh tay sau khi có, không nên kỳ vọng đúng 100% ngay lần đầu.
 */
object HardsubExtractor {

    data class ExtractResult(val success: Boolean, val srtContent: String, val log: String)

    /**
     * @param framesPerSecond nhịp lấy mẫu — mặc định 2 (1 frame mỗi 0.5 giây). CAO hơn = bắt
     *        được phụ đề đổi nhanh chính xác hơn nhưng CHẠY LÂU HƠN (chạy OCR nhiều frame hơn,
     *        tuyến tính) — số này CHƯA được đo trên máy thật để biết thời gian xử lý thực tế
     *        cho video dài, có thể cần giảm xuống (vd 1) nếu quá chậm.
     * @param bottomRegionFraction tỉ lệ chiều cao ảnh tính từ ĐÁY lên coi là "vùng phụ đề" —
     *        mặc định 0.25 (25% dưới cùng). Phụ đề nằm ngoài vùng này (trên đầu/giữa hình) SẼ
     *        BỊ BỎ SÓT — CHƯA có cách tự động dò đúng vị trí phụ đề trong khung hình.
     * @param similarityThreshold 0.0-1.0 — 2 frame liên tiếp được coi là "cùng 1 câu thoại"
     *        nếu tỉ lệ khớp ký tự (Levenshtein) >= ngưỡng này. Mặc định 0.6 — THẤP hơn số
     *        thường dùng cho so khớp văn bản thường (vd 0.8-0.9) CÓ CHỦ Ý, vì OCR trên video
     *        nén dễ đọc sai nhiều ký tự hơn ảnh chụp rõ nét bình thường; ngưỡng thấp hơn giúp
     *        đỡ bị tách vụn 1 câu thoại thành nhiều đoạn ngắn do OCR đọc lệch vài chữ giữa các
     *        frame — CHƯA đo thật để biết số này có hợp lý không, cần chỉnh lại sau khi test.
     */
    suspend fun extractHardsubToSrt(
        videoPath: String,
        workDir: File,
        framesPerSecond: Double = 2.0,
        bottomRegionFraction: Double = 0.25,
        similarityThreshold: Double = 0.6,
        onProgress: (Int) -> Unit = {}
    ): ExtractResult = withContext(Dispatchers.IO) {
        val framesDir = File(workDir, "hardsub_frames_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            // Bước 1: lấy mẫu frame — CÙNG lệnh FFmpeg đã dùng ở ObjectExtractActivity, không
            // viết lại logic khác cho cùng 1 việc.
            val pattern = File(framesDir, "frame_%06d.png").absolutePath
            val cmd = "-y -i \"$videoPath\" -vf fps=$framesPerSecond \"$pattern\""
            val session = com.arthenica.ffmpegkit.FFmpegKit.execute(cmd)
            if (!com.arthenica.ffmpegkit.ReturnCode.isSuccess(session.returnCode)) {
                return@withContext ExtractResult(false, "", "Lấy mẫu frame thất bại: ${session.allLogsAsString.takeLast(500)}")
            }

            val frameFiles = framesDir.listFiles { f -> f.extension == "png" }?.sortedBy { it.name } ?: emptyList()
            if (frameFiles.isEmpty()) {
                return@withContext ExtractResult(false, "", "Không lấy được frame nào từ video — kiểm tra lại file video có đọc được không.")
            }

            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            // (timeSec, recognizedText) cho từng frame đã lấy mẫu, theo đúng thứ tự thời gian.
            val perFrameText = mutableListOf<Pair<Double, String>>()
            frameFiles.forEachIndexed { index, frameFile ->
                val timeSec = index / framesPerSecond
                val text = try {
                    ocrBottomRegion(frameFile, bottomRegionFraction, recognizer)
                } catch (e: Exception) {
                    "" // 1 frame OCR lỗi không nên làm hỏng cả quá trình -> coi như không có chữ
                }
                perFrameText.add(timeSec to text)
                onProgress(((index + 1) * 100 / frameFiles.size))
            }
            recognizer.close()

            val srt = buildSrtFromFrameTexts(perFrameText, 1.0 / framesPerSecond, similarityThreshold)
            if (srt.isBlank()) {
                ExtractResult(false, "", "Không nhận diện được chữ nào trong toàn bộ video — có thể video không có phụ đề cứng, phụ đề nằm ngoài vùng 25% dưới cùng đã giả định, hoặc phông chữ/độ nét không đọc được.")
            } else {
                ExtractResult(true, srt, "Đã xử lý ${frameFiles.size} frame.")
            }
        } finally {
            framesDir.deleteRecursively() // dọn frame tạm, có thể chiếm nhiều dung lượng (hàng trăm-hàng ngàn ảnh)
        }
    }

    private suspend fun ocrBottomRegion(
        frameFile: File,
        bottomRegionFraction: Double,
        recognizer: com.google.mlkit.vision.text.TextRecognizer
    ): String {
        val original = BitmapFactory.decodeFile(frameFile.absolutePath) ?: return ""
        val cropHeight = (original.height * bottomRegionFraction).toInt().coerceAtLeast(1)
        val cropTop = (original.height - cropHeight).coerceAtLeast(0)
        val cropped: Bitmap = try {
            Bitmap.createBitmap(original, 0, cropTop, original.width, cropHeight)
        } finally {
            // original vẫn cần dùng nếu createBitmap trả về CHÍNH original (trường hợp
            // cropHeight == original.height) -> không recycle original ở đây, để GC tự lo,
            // tránh recycle nhầm bitmap đang được cropped tham chiếu tới.
        }
        val image = InputImage.fromBitmap(cropped, 0)
        val result = recognizer.process(image).await()
        return result.text.replace("\n", " ").trim()
    }

    /** Tỉ lệ khớp ký tự 0.0-1.0 dựa trên khoảng cách Levenshtein — 1.0 = giống hệt nhau. */
    private fun textSimilarity(a: String, b: String): Double {
        if (a.isEmpty() && b.isEmpty()) return 1.0
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val dist = levenshtein(a, b)
        val maxLen = maxOf(a.length, b.length)
        return 1.0 - dist.toDouble() / maxLen
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                dp[i][j] = if (a[i - 1] == b[j - 1]) dp[i - 1][j - 1] else 1 + minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
            }
        }
        return dp[a.length][b.length]
    }

    private fun buildSrtFromFrameTexts(
        perFrameText: List<Pair<Double, String>>,
        frameIntervalSec: Double,
        similarityThreshold: Double
    ): String {
        data class Run(var startSec: Double, var endSec: Double, val texts: MutableList<String>)
        val runs = mutableListOf<Run>()
        for ((timeSec, text) in perFrameText) {
            val normalized = text.trim()
            val current = runs.lastOrNull()
            if (current != null && normalized.isNotBlank() &&
                textSimilarity(normalized, current.texts.last()) >= similarityThreshold
            ) {
                // Cùng 1 câu thoại đang tiếp diễn -> kéo dài thêm, không tạo đoạn mới.
                current.endSec = timeSec + frameIntervalSec
                current.texts.add(normalized)
            } else if (normalized.isNotBlank()) {
                // Chữ mới xuất hiện (khác hẳn câu trước, hoặc trước đó không có chữ) -> mở đoạn mới.
                runs.add(Run(timeSec, timeSec + frameIntervalSec, mutableListOf(normalized)))
            }
            // normalized rỗng -> không có phụ đề ở frame này, không mở/kéo dài đoạn nào cả
            // (đoạn đang mở dở, nếu có, coi như đã kết thúc ở frame trước đó).
        }
        if (runs.isEmpty()) return ""
        val sb = StringBuilder()
        runs.forEachIndexed { i, run ->
            // Chọn văn bản ĐẠI DIỆN cho cả đoạn: text xuất hiện NHIỀU LẦN NHẤT trong đoạn đó
            // (không phải frame đầu/cuối, vốn dễ dính khung hình chuyển cảnh mờ/nhoè) — giảm
            // ảnh hưởng của các lần OCR đọc sai lẻ tẻ.
            val representative = run.texts.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: run.texts.first()
            sb.append(i + 1).append('\n')
            sb.append(formatSrtTimestamp(run.startSec)).append(" --> ").append(formatSrtTimestamp(run.endSec)).append('\n')
            sb.append(representative).append("\n\n")
        }
        return sb.toString()
    }

    private fun formatSrtTimestamp(totalSec: Double): String {
        val totalMs = Math.round(totalSec.coerceAtLeast(0.0) * 1000.0)
        val h = totalMs / 3_600_000
        val m = (totalMs % 3_600_000) / 60_000
        val s = (totalMs % 60_000) / 1000
        val ms = totalMs % 1000
        return "%02d:%02d:%02d,%03d".format(h, m, s, ms)
    }
}
