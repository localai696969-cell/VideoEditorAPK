package com.videoaistudio.app.inference

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Nơi duy nhất trong app biết cách "biến" 1 ModelConfig (do người dùng khai báo)
 * thành 1 IInferenceProvider có thể chạy được.
 *
 * Mọi module tính năng sau này (VideoUpscaler, ObjectDetector, FrameInterpolator...)
 * đều gọi qua đây, KHÔNG bao giờ tự new LocalModelProvider/ApiProvider trực tiếp.
 * Nhờ vậy khi cần thêm loại provider mới, chỉ sửa 1 chỗ duy nhất trong file này.
 */
class InferenceManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("model_configs", Context.MODE_PRIVATE)
    private val activeProviders = mutableMapOf<String, IInferenceProvider>()

    /** Lấy provider đã cấu hình cho 1 loại tác vụ. Trả null nếu người dùng chưa chọn model nào. */
    fun getProviderFor(taskType: TaskType): IInferenceProvider? {
        val config = getConfigFor(taskType) ?: return null

        return activeProviders.getOrPut(config.id) {
            when (config.source) {
                ProviderSource.LOCAL_MODEL -> LocalModelProvider(context, config)
                ProviderSource.REMOTE_API -> ApiProvider(config)
            }
        }
    }

    fun getConfigFor(taskType: TaskType): ModelConfig? =
        getAllConfigs().firstOrNull { it.taskType == taskType }

    fun getAllConfigs(): List<ModelConfig> {
        val raw = prefs.getString(KEY_CONFIGS, null) ?: return emptyList()
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i -> configFromJson(arr.getJSONObject(i)) }
    }

    fun saveConfig(config: ModelConfig) {
        val existing = getAllConfigs().filterNot { it.id == config.id }
        val updated = existing + config
        persist(updated)
        activeProviders.remove(config.id)?.release()
    }

    fun deleteConfig(configId: String) {
        val updated = getAllConfigs().filterNot { it.id == configId }
        persist(updated)
        activeProviders.remove(configId)?.release()
    }

    fun releaseAll() {
        activeProviders.values.forEach { it.release() }
        activeProviders.clear()
    }

    private fun persist(configs: List<ModelConfig>) {
        val arr = JSONArray()
        configs.forEach { arr.put(configToJson(it)) }
        prefs.edit().putString(KEY_CONFIGS, arr.toString()).apply()
    }

    private fun configToJson(c: ModelConfig): JSONObject = JSONObject().apply {
        put("id", c.id)
        put("displayName", c.displayName)
        put("taskType", c.taskType.name)
        put("source", c.source.name)
        put("hardwareTarget", c.hardwareTarget.name)
        put("localFilePath", c.localFilePath)
        put("apiEndpoint", c.apiEndpoint)
        put("apiKey", c.apiKey)
        put("apiExtraHeaders", JSONObject(c.apiExtraHeaders))
        put("labelsFilePath", c.labelsFilePath)
    }

    private fun configFromJson(o: JSONObject): ModelConfig {
        val headers = mutableMapOf<String, String>()
        o.optJSONObject("apiExtraHeaders")?.let { h ->
            h.keys().forEach { k -> headers[k] = h.getString(k) }
        }
        return ModelConfig(
            id = o.getString("id"),
            displayName = o.getString("displayName"),
            taskType = TaskType.valueOf(o.getString("taskType")),
            source = ProviderSource.valueOf(o.getString("source")),
            hardwareTarget = HardwareTarget.valueOf(o.getString("hardwareTarget")),
            localFilePath = o.optString("localFilePath", null),
            apiEndpoint = o.optString("apiEndpoint", null),
            apiKey = o.optString("apiKey", null),
            apiExtraHeaders = headers,
            labelsFilePath = o.optString("labelsFilePath", null)
        )
    }

    companion object {
        private const val KEY_CONFIGS = "configs_json"
    }
}
