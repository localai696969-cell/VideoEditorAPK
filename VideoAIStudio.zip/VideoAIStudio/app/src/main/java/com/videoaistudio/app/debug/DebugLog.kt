package com.videoaistudio.app.debug

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Bộ ghi log debug đơn giản, ghi xuống file trên đĩa (sống sót qua việc app bị tắt/mở
 * lại nhiều lần — khác với Logcat thông thường vốn chỉ sống trong 1 phiên chạy và cần
 * máy tính + lệnh `adb` để xem, thứ mà người dùng KHÔNG có).
 *
 * Lý do cần cái này: sau nhiều vòng chẩn đoán lỗi Compress chỉ dựa vào ảnh chụp màn
 * hình (dễ thiếu thông tin, dễ đoán sai — đã xảy ra vài lần), cần bằng chứng CHÍNH XÁC
 * về trình tự sự kiện thật (Activity/Service được tạo/huỷ lúc nào, Service nhận lệnh
 * bắt đầu mấy lần, tiến độ cập nhật ra sao) để chẩn đoán đúng thay vì suy luận.
 *
 * Cách dùng: gọi `DebugLog.log(context, "tag", "nội dung")` ở các điểm quan trọng.
 * Xem lại bằng `DebugLog.readAll(context)`. Chia sẻ qua Intent.ACTION_SEND (xem
 * VideoToolsActivity — nút "Xem/Chia sẻ log debug").
 */
object DebugLog {
    private const val FILE_NAME = "debug_log.txt"
    private const val MAX_LINES = 1000 // tự cắt bớt để không phình vô hạn theo thời gian
    private val timeFormat = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun log(context: Context, tag: String, message: String) {
        try {
            val file = logFile(context)
            val timestamp = timeFormat.format(System.currentTimeMillis())
            val pid = android.os.Process.myPid()
            val line = "$timestamp [pid=$pid] [$tag] $message\n"
            file.appendText(line)
            trimIfTooLong(file)
        } catch (e: Exception) {
            // Ghi log mà lỗi thì bỏ qua luôn — không được để việc ghi log làm crash app thật.
        }
    }

    fun readAll(context: Context): String {
        return try {
            val file = logFile(context)
            if (file.exists()) file.readText() else "(chưa có log nào được ghi)"
        } catch (e: Exception) {
            "(lỗi đọc log: ${e.message})"
        }
    }

    fun clear(context: Context) {
        try {
            logFile(context).writeText("")
        } catch (e: Exception) { /* bỏ qua */ }
    }

    private fun logFile(context: Context): File = File(context.filesDir, FILE_NAME)

    private fun trimIfTooLong(file: File) {
        val lines = file.readLines()
        if (lines.size > MAX_LINES) {
            file.writeText(lines.takeLast(MAX_LINES).joinToString("\n") + "\n")
        }
    }
}
