package com.videoaistudio.app.inference

/**
 * Các loại tác vụ AI mà app hỗ trợ.
 * Thêm tác vụ mới trong tương lai (vd: FRAME_INTERPOLATION cho tạo ảnh động,
 * OBJECT_REMOVAL cho xoá object) chỉ cần thêm 1 dòng enum ở đây,
 * không cần sửa các phần khác của kiến trúc.
 */
enum class TaskType {
    VIDEO_UPSCALE,
    OBJECT_DETECTION,
    OBJECT_SEGMENTATION,
    FRAME_INTERPOLATION,   // dùng cho tính năng "tạo ảnh động" / tăng FPS
    OBJECT_REMOVAL         // dùng cho tính năng xoá object khỏi video
}

/** Bố cục tensor ảnh: kênh màu ở vị trí nào trong shape. */
enum class TensorLayout { NCHW, NHWC }

/**
 * Thông tin tự dò được từ MỘT model upscale bất kỳ (không hardcode model cụ thể).
 * UI dùng cái này để hiển thị "Model này upscale x{detectedScaleFactor}" cho người
 * dùng biết, thay vì bắt người dùng tự khai báo hoặc app tự đoán bừa.
 */
data class UpscaleModelSpec(
    val layout: TensorLayout,
    val detectedScaleFactor: Int,
    val supportsDynamicResolution: Boolean
)
enum class ProviderSource {
    LOCAL_MODEL,
    REMOTE_API
}

/** Phần cứng ưu tiên khi chạy model local. */
enum class HardwareTarget {
    CPU,
    GPU_NPU_AUTO,   // "Lớp nền": qua NNAPI, Android tự route từng phép tính tới GPU/NPU nếu driver hỗ trợ, phần còn lại rớt CPU
    NPU_QNN_FORCED  // "Lớp nâng cao": ép toàn bộ chạy Hexagon NPU qua QNN, model không tương thích sẽ báo lỗi thay vì rớt CPU
}

/**
 * Kết quả kiểm tra khả năng chạy của 1 model trên phần cứng cụ thể.
 * Dùng để hiện cho người dùng quyết định: chấp nhận hiệu suất này hay đổi model khác.
 */
data class CompatibilityReport(
    val hardwareTarget: HardwareTarget,
    val loadSucceeded: Boolean,
    val percentOpsOnAccelerator: Int? = null, // % phép tính chạy GPU/NPU, null nếu không đo được (vd: QNN fail thẳng)
    val percentOpsOnCpu: Int? = null,
    val message: String
)

/**
 * Cấu hình 1 model do người dùng khai báo trong màn hình Settings.
 * Đây là điểm mấu chốt để "không hardcode model/API": mọi thông tin
 * (đường dẫn file local, hoặc endpoint + API key) đều do người dùng nhập,
 * lưu vào đây, ứng dụng chỉ đọc theo cấu hình này.
 */
data class ModelConfig(
    val id: String,
    val displayName: String,
    val taskType: TaskType,
    val source: ProviderSource,
    val hardwareTarget: HardwareTarget = HardwareTarget.GPU_NPU_AUTO,

    // Dùng khi source = LOCAL_MODEL
    val localFilePath: String? = null,   // đường dẫn file .tflite / .onnx người dùng đã tải vào máy

    // Dùng khi source = REMOTE_API
    val apiEndpoint: String? = null,
    val apiKey: String? = null,
    val apiExtraHeaders: Map<String, String> = emptyMap(),

    // Dùng riêng cho TaskType.OBJECT_DETECTION: URI file danh sách nhãn (mỗi dòng 1 tên lớp,
    // đúng thứ tự model đã được train). App không tự biết tên các lớp trong model —
    // đây là thông tin CHỈ người cung cấp model mới biết, giống như mọi công cụ
    // detection khác đều cần kèm labels.txt bên cạnh file model.
    val labelsFilePath: String? = null
)

/** Input chung cho 1 lần chạy inference. */
data class InferenceInput(
    val taskType: TaskType,
    val inputFilePath: String,       // frame ảnh hoặc file video tuỳ tác vụ
    val extraParams: Map<String, String> = emptyMap()
)

/** Output chung, thống nhất định dạng để bước xử lý sau (video engine) dùng lại được. */
data class InferenceOutput(
    val success: Boolean,
    val outputFilePaths: List<String> = emptyList(),
    val metadata: Map<String, String> = emptyMap(),
    val errorMessage: String? = null
)
