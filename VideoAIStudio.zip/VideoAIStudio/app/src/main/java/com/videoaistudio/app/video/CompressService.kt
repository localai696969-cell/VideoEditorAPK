package com.videoaistudio.app.video

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.videoaistudio.app.debug.DebugLog
import com.videoaistudio.app.ui.VideoToolsActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * Chạy nén video dưới dạng Foreground Service — đây là bản sửa GỐC RỄ cho vấn đề
 * "rời app thì tiến trình nén dừng, không báo lỗi, quay lại thấy file hỏng":
 *
 * Trước đây việc nén chạy trong `lifecycleScope` của Activity — khi Activity bị
 * Android tạm dừng/huỷ (do rời app, xoay màn hình, hệ thống thu hồi bộ nhớ),
 * coroutine bị HUỶ NGANG, khiến FFmpeg nhận tín hiệu dừng giữa chừng (đúng hiện
 * tượng "signal 15" trong log trước đó) — file output vì vậy dở dang/hỏng.
 *
 * Service này có vòng đời RIÊNG, không phụ thuộc Activity — chạy nền bằng coroutine
 * scope của chính Service, kèm thông báo (notification) liên tục để Android không
 * coi đây là tiến trình "không hoạt động" rồi thu hồi.
 *
 * GIỚI HẠN CẦN BIẾT: Service vẫn có thể bị hệ thống dừng trong trường hợp cực đoan
 * (máy quá thiếu RAM, hoặc người dùng tự tay "Buộc dừng" app trong Cài đặt) — không
 * có gì trên Android đảm bảo chạy nền 100% tuyệt đối. Nhưng so với trước (chỉ cần
 * rời app vài giây là dừng), đây là cải thiện rất lớn.
 */
class CompressService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var notificationManager: NotificationManager
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        DebugLog.log(this, "CompressService", "onCreate() — Service instance được tạo")
        notificationManager = getSystemService(NotificationManager::class.java)
        createChannelIfNeeded()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val inputPaths = intent?.getStringArrayListExtra(EXTRA_INPUT_PATHS)
        DebugLog.log(this, "CompressService", "onStartCommand() startId=$startId, inputPaths=${inputPaths?.size ?: 0}, isRunning(trước đó)=${CompressResultHolder.isRunning}")
        if (inputPaths.isNullOrEmpty()) {
            DebugLog.log(this, "CompressService", "onStartCommand() KHÔNG có inputPaths -> stopSelf() ngay")
            stopSelf()
            return START_NOT_STICKY
        }

        // FIX QUAN TRỌNG: trước đây KHÔNG có gì chặn việc onStartCommand() được gọi
        // LẦN 2 trong lúc lần 1 vẫn đang chạy (`serviceScope.launch` không kiểm tra gì
        // trước khi tự do chạy thêm 1 coroutine mới). Nếu điều đó xảy ra (dù bằng cách
        // nào — bấm nhầm, xoay màn hình kích hoạt lại luồng khởi động, v.v.), sẽ có
        // 2 TIẾN TRÌNH NÉN CHẠY SONG SONG, CẢ 2 CÙNG GHI ĐÈ LÊN 1 THÔNG BÁO/1 TIẾN ĐỘ —
        // đúng y hệt hiện tượng "% tự nhiên tụt xuống thấp rồi lại chạy tiếp, như vòng
        // lặp" mà vẫn cùng nhãn "(phần cứng)" (vì tiến trình mới cũng bắt đầu bằng phần
        // cứng), vì tiến trình MỚI bắt đầu từ % thấp trong khi tiến trình CŨ vẫn đang ở
        // % cao — 2 bên đua nhau ghi đè, người dùng thấy % nhảy loạn. Giờ chặn cứng:
        // nếu đã có 1 tác vụ đang chạy, TỪ CHỐI yêu cầu mới thay vì chạy chồng lên.
        if (CompressResultHolder.isRunning) {
            DebugLog.log(this, "CompressService", "onStartCommand() BỊ CHẶN — đã có 1 tác vụ đang chạy, từ chối yêu cầu mới (startId=$startId)")
            return START_NOT_STICKY
        }

        val presetOrdinal = intent.getIntExtra(EXTRA_PRESET_ORDINAL, 1)
        val useHardware = intent.getBooleanExtra(EXTRA_USE_HARDWARE, true)
        val preset = VideoEngine.CompressPreset.values()[presetOrdinal]

        CompressResultHolder.isRunning = true
        CompressResultHolder.lastResult = null

        // Giữ CPU chạy full tốc độ kể cả khi tắt màn hình (đúng yêu cầu "treo máy qua đêm
        // không bị chậm/dừng") — không có cái này, Android có thể đưa CPU vào chế độ tiết
        // kiệm (Doze) dù tiến trình vẫn sống nhờ Foreground Service.
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VideoAIStudio::CompressWakeLock").apply {
            acquire(8 * 60 * 60 * 1000L) // tối đa 8 tiếng (đủ qua đêm), tự nhả nếu quên giải phóng
        }

        // PHẢI gọi startForeground ngay lập tức (trong vài giây) sau khi service được
        // khởi động, nếu không Android sẽ crash app (yêu cầu bắt buộc từ Android 12+).
        try {
            startForeground(NOTIF_ID, buildNotification("Đang chuẩn bị...", 0))
            DebugLog.log(this, "CompressService", "startForeground() THÀNH CÔNG (startId=$startId)")
        } catch (e: Exception) {
            // FIX: nếu startForeground() THẤT BẠI (vd bị hệ thống từ chối vì lý do nào đó
            // trên 1 số máy/bản Android), TRƯỚC ĐÂY không hề bắt lỗi này — coroutine bên
            // dưới vẫn cứ chạy mà KHÔNG CÓ THÔNG BÁO NÀO hiển thị, đúng khớp với hiện tượng
            // "chạy ngầm nhưng không thấy bất cứ thông báo nào". Giờ ghi log rõ để biết
            // chắc đây có phải nguyên nhân không, thay vì đoán.
            DebugLog.log(this, "CompressService", "startForeground() THẤT BẠI: ${e.javaClass.simpleName}: ${e.message}")
        }

        serviceScope.launch {
            // FIX QUAN TRỌNG NHẤT: trước đây TOÀN BỘ khối xử lý bên dưới KHÔNG có
            // try/catch bao ngoài. compressWithKnownBackend() tự bắt lỗi FFmpeg NÓ BIẾT
            // TRƯỚC (trả về VideoOpResult(success=false, log=...)) — nhưng nếu có bất kỳ
            // exception nào KHÁC xảy ra mà hàm đó không lường trước (vd lỗi đọc file, hết
            // bộ nhớ, lỗi định dạng video lạ khi tính bitrate/fps...), exception đó sẽ
            // KHÔNG bị bắt ở đâu cả -> coroutine crash NGANG, không bao giờ chạy tới
            // showFinalNotification()/broadcastComplete()/cập nhật CompressResultHolder.
            // Hậu quả đúng y hệt hiện tượng "chạy thất bại mà không thấy bất kỳ thông báo
            // gì": thông báo bị kẹt ở trạng thái cũ (hoặc biến mất do process chết), và
            // CompressResultHolder.isRunning bị KẸT ở true mãi mãi -> mở lại app chỉ thấy
            // "Đang nén ở chế độ nền..." treo vô thời hạn, không bao giờ tự hết.
            // Giờ bọc try/catch NGOÀI CÙNG để BẢO ĐẢM dù có chuyện gì xảy ra, người dùng
            // luôn nhận được 1 kết quả rõ ràng (thành công/thất bại) thay vì im lặng treo.
            DebugLog.log(this@CompressService, "CompressService", "coroutine bắt đầu chạy runCompressBatch() (startId=$startId)")
            try {
                runCompressBatch(inputPaths, preset, useHardware)
                DebugLog.log(this@CompressService, "CompressService", "runCompressBatch() xong bình thường (startId=$startId)")
            } catch (e: Throwable) {
                val crashLog = "Lỗi không lường trước (${e.javaClass.simpleName}): ${e.message ?: "không có mô tả"}"
                DebugLog.log(this@CompressService, "CompressService", "CRASH trong runCompressBatch(): $crashLog")
                CompressResultHolder.lastResult = VideoOpResult(false, emptyList(), crashLog)
                CompressResultHolder.isRunning = false
                CompressResultHolder.runningFileNames = emptyList()
                CompressResultStore.save(applicationContext, CompressResultHolder.lastResult!!)
                showFinalNotification(success = false, savedCount = 0, totalCount = inputPaths.size, hasWarning = false)
                broadcastComplete(VideoOpResult(false, emptyList(), crashLog))
            } finally {
                DebugLog.log(this@CompressService, "CompressService", "finally: stopForeground + stopSelf (startId=$startId)")
                stopForeground(STOP_FOREGROUND_DETACH)
                if (wakeLock?.isHeld == true) wakeLock?.release()
                stopSelf()
            }
        }

        return START_NOT_STICKY
    }

    /** Toàn bộ logic nén thật — tách riêng khỏi onStartCommand để khối try/catch bên
     *  trên bọc được TRỌN VẸN, không sót nhánh nào. */
    private suspend fun runCompressBatch(
        inputPaths: List<String>,
        preset: VideoEngine.CompressPreset,
        useHardware: Boolean
    ) {
        val outputDir = FileUtils.getOutputDir(applicationContext).absolutePath
        val outputPaths = mutableListOf<String>()
        val logs = StringBuilder()
        var allSuccess = true
        var anyWarning = false

        for ((index, path) in inputPaths.withIndex()) {
            val filePrefix = if (inputPaths.size > 1) "File ${index + 1}/${inputPaths.size}: " else ""
            DebugLog.log(this, "CompressService", "Bắt đầu nén file ${index + 1}/${inputPaths.size}: ${File(path).name}, useHardware=$useHardware")
            var lastLoggedDecile = -1
            val result = VideoEngine.compressWithKnownBackend(path, outputDir, preset, useHardware) { percent ->
                val statusText = "$filePrefix$percent% (${if (useHardware) "phần cứng" else "phần mềm"})"
                updateNotification(statusText, percent)
                broadcastProgress(index, inputPaths.size, percent, useHardware)
                // Chỉ ghi log mỗi khi qua 1 mốc 10% mới — tránh log phình to vô ích, nhưng
                // vẫn đủ dày để thấy được nếu % TỰ NHIÊN TỤT XUỐNG (thay vì tăng dần đều).
                val decile = percent / 10
                if (decile != lastLoggedDecile) {
                    lastLoggedDecile = decile
                    DebugLog.log(this, "CompressService", "Tiến độ file ${index + 1}: $percent% (${if (useHardware) "phần cứng" else "phần mềm"})")
                }
            }
            DebugLog.log(this, "CompressService", "Kết thúc file ${index + 1}/${inputPaths.size}: success=${result.success}, log 1 dòng cuối=${result.log.lineSequence().lastOrNull { it.isNotBlank() }}")
            if (result.success) {
                outputPaths.addAll(result.outputPaths)
                // FIX QUAN TRỌNG: trước đây khi result.success == true, result.log bị
                // BỎ QUA HOÀN TOÀN ở đây (chỉ log khi thất bại) — nhưng
                // compressWithKnownBackend() có thể trả success=true KÈM cảnh báo
                // "CẢNH BÁO: dung lượng sau nén không nhỏ hơn đáng kể so với gốc"
                // (khi cả phần cứng lẫn phần mềm đều không nén nhỏ đi được). Cảnh báo
                // đó bị mất ngay tại đây, trước khi kịp broadcast ra Activity — đây là
                // NGUYÊN NHÂN GỐC của lỗi "nén Vừa xong báo thành công nhưng không có
                // bất kỳ thay đổi nào" mà không hề thấy cảnh báo/lỗi gì hiển thị.
                if (result.log.contains("CẢNH BÁO", ignoreCase = true)) {
                    anyWarning = true
                    logs.appendLine("$filePrefix${result.log}")
                }
            } else {
                allSuccess = false
                // FIX: trước đây chỉ lấy DÒNG ĐẦU TIÊN của log (`lineSequence().firstOrNull()`)
                // — gần như luôn chỉ là dòng banner phiên bản FFmpeg, KHÔNG PHẢI lỗi thật.
                // Lỗi thật (vd "Unsupported pixel format", "Error while opening encoder"...)
                // luôn nằm ở CUỐI log. Giờ lấy 6 dòng cuối để còn thấy được lỗi thật, giúp
                // chẩn đoán vì sao "nén thất bại".
                val meaningfulLog = result.log.lineSequence().filter { it.isNotBlank() }.toList().takeLast(6).joinToString("\n")
                logs.appendLine("$filePrefix thất bại:\n$meaningfulLog")
            }
        }

        val finalResult = VideoOpResult(allSuccess, outputPaths, logs.toString())
        CompressResultHolder.lastResult = finalResult
        CompressResultHolder.isRunning = false
        CompressResultHolder.runningFileNames = emptyList()
        CompressResultStore.save(applicationContext, finalResult)

        showFinalNotification(allSuccess, outputPaths.size, inputPaths.size, anyWarning)
        broadcastComplete(finalResult)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        DebugLog.log(this, "CompressService", "onDestroy() — Service instance bị huỷ")
        serviceScope.cancel()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        CompressResultHolder.isRunning = false
        CompressResultHolder.runningFileNames = emptyList()
        super.onDestroy()
    }

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Xử lý video nền", NotificationManager.IMPORTANCE_LOW
            )
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildContentIntent(): PendingIntent {
        val intent = Intent(this, VideoToolsActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(VideoToolsActivity.EXTRA_MODE, "COMPRESS")
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT
        return PendingIntent.getActivity(this, 0, intent, flags)
    }

    private fun buildNotification(text: String, progress: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Đang nén video")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setContentIntent(buildContentIntent())
            .build()
    }

    private fun updateNotification(text: String, progress: Int) {
        notificationManager.notify(NOTIF_ID, buildNotification(text, progress))
    }

    private fun showFinalNotification(success: Boolean, savedCount: Int, totalCount: Int, hasWarning: Boolean = false) {
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(if (!success) "Nén thất bại" else if (hasWarning) "Nén xong — có cảnh báo" else "Nén xong")
            .setContentText(
                when {
                    !success -> "Có lỗi xảy ra, mở lại app để xem chi tiết."
                    hasWarning -> "Hoàn tất $savedCount/$totalCount file, nhưng dung lượng có thể KHÔNG giảm đáng kể. Mở app để xem chi tiết."
                    else -> "Hoàn tất $savedCount/$totalCount file. Mở lại app để xem/lưu."
                }
            )
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setOngoing(false)
            .setAutoCancel(true)
            .setContentIntent(buildContentIntent())
            .build()
        notificationManager.notify(NOTIF_ID, notif)
    }

    private fun broadcastProgress(fileIndex: Int, totalFiles: Int, percent: Int, useHardware: Boolean) {
        val intent = Intent(ACTION_PROGRESS).apply {
            putExtra("fileIndex", fileIndex)
            putExtra("totalFiles", totalFiles)
            putExtra("percent", percent)
            putExtra("useHardware", useHardware)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun broadcastComplete(result: VideoOpResult) {
        val intent = Intent(ACTION_COMPLETE).apply {
            putExtra("success", result.success)
            putStringArrayListExtra("outputPaths", ArrayList(result.outputPaths))
            putExtra("log", result.log)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    /** Giữ lại kết quả gần nhất trong bộ nhớ — để Activity biết trạng thái khi mở
     *  lại app sau khi Service đã chạy xong ở nền (không nhận được broadcast vì
     *  lúc đó Activity chưa đăng ký lắng nghe). */
    /**
     * FIX QUAN TRỌNG: `CompressResultHolder` chỉ là 1 object Kotlin sống TRONG BỘ NHỚ —
     * biến mất ngay khi tiến trình app bị Android tắt. Vấn đề là: ngay khi
     * runCompressBatch() (hoặc nhánh crash) xong việc, code gọi `stopForeground()` +
     * `stopSelf()` — tức là Service NGAY LẬP TỨC MẤT HẾT quyền bảo vệ "foreground" của
     * Android. Nếu đúng lúc đó người dùng đang làm việc khác (mở trình duyệt...) và máy
     * cần thu hồi RAM, tiến trình app hoàn toàn có thể bị dọn NGAY SAU KHI vừa hoàn tất
     * — xoá sạch `CompressResultHolder.lastResult` — TRƯỚC KHI người dùng kịp mở lại app
     * xem. Trong khi đó, thông báo (notification) là do hệ thống Android tự quản lý
     * riêng, VẪN CÒN HIỂN THỊ dù tiến trình app đã chết. Đây chính xác là hiện tượng
     * "thấy thông báo Nén thất bại, mở app ra thì chả có gì cả".
     *
     * Sửa bằng cách LƯU THÊM 1 bản xuống SharedPreferences (ổ đĩa, sống sót qua process
     * chết) mỗi khi có kết quả — VideoToolsActivity sẽ đọc từ đây làm phương án dự phòng
     * nếu bản trong bộ nhớ đã bị mất.
     */
    object CompressResultStore {
        private const val PREFS_NAME = "compress_result_store"
        private const val KEY_HAS_PENDING = "has_pending"
        private const val KEY_SUCCESS = "success"
        private const val KEY_OUTPUT_PATHS = "output_paths" // ngăn cách bằng "\u0001"
        private const val KEY_LOG = "log"

        fun save(context: android.content.Context, result: VideoOpResult) {
            context.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_HAS_PENDING, true)
                .putBoolean(KEY_SUCCESS, result.success)
                .putString(KEY_OUTPUT_PATHS, result.outputPaths.joinToString("\u0001"))
                .putString(KEY_LOG, result.log)
                .apply()
        }

        /** Đọc + XOÁ luôn (chỉ hiện 1 lần) kết quả đã lưu, hoặc null nếu không có gì. */
        fun consumePending(context: android.content.Context): VideoOpResult? {
            val prefs = context.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
            if (!prefs.getBoolean(KEY_HAS_PENDING, false)) return null
            val success = prefs.getBoolean(KEY_SUCCESS, false)
            val outputPaths = prefs.getString(KEY_OUTPUT_PATHS, "")
                ?.split("\u0001")
                ?.filter { it.isNotBlank() }
                ?: emptyList()
            val log = prefs.getString(KEY_LOG, "") ?: ""
            prefs.edit().clear().apply()
            return VideoOpResult(success, outputPaths, log)
        }
    }

    object CompressResultHolder {
        var isRunning: Boolean = false
        var lastResult: VideoOpResult? = null
        // FIX: lưu lại TÊN file đang được nén nền, để UI có thể hiện rõ "Đang nén: X"
        // thay vì để nguyên "Chưa chọn video nào" — dòng chữ đó khiến người dùng
        // tưởng nhầm là file đã "biến mất"/mất dấu, dù thực chất Service vẫn đang xử
        // lý đúng file đó bình thường (chỉ là danh sách chọn trong Activity bị reset
        // do Activity được tạo lại sau khi màn hình tắt/bật, không liên quan gì tới
        // dữ liệu thật Service đang xử lý).
        var runningFileNames: List<String> = emptyList()
    }

    companion object {
        const val ACTION_PROGRESS = "com.videoaistudio.app.COMPRESS_PROGRESS"
        const val ACTION_COMPLETE = "com.videoaistudio.app.COMPRESS_COMPLETE"
        const val EXTRA_INPUT_PATHS = "input_paths"
        const val EXTRA_PRESET_ORDINAL = "preset_ordinal"
        const val EXTRA_USE_HARDWARE = "use_hardware"
        private const val CHANNEL_ID = "compress_channel"
        private const val NOTIF_ID = 1001
    }
}
