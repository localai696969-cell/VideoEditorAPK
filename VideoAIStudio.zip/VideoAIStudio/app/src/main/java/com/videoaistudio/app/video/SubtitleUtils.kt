package com.videoaistudio.app.video

import java.io.File
import java.util.Locale

/**
 * BÀI TOÁN THẬT (khác với lúc đầu hiểu nhầm): người dùng CÓ file phụ đề của video GỐC
 * (đầy đủ cả video), nhưng KHÔNG CÒN video gốc — chỉ còn video ĐÃ CẮT SẴN (cắt bằng cách
 * nào đó, có thể không phải từ app này). Cần: (1) cắt/dịch lại giờ trong CHÍNH FILE PHỤ ĐỀ
 * cho khớp với mốc 0 của đoạn đã cắt, (2) sau đó ghép (burn) file phụ đề đã dịch giờ đó vào
 * NGUYÊN video đã cắt — bước này KHÔNG cần FFmpeg cắt gì nữa (video đã đúng độ dài rồi), chỉ
 * cần overlay phụ đề lên toàn bộ video, đơn giản hơn nhiều so với
 * `VideoEngine.trimWithBurnedSubtitles()` (dùng cho trường hợp KHÁC: còn giữ video gốc,
 * muốn cắt + ghép phụ đề trong 1 bước — vẫn giữ nguyên hàm đó cho ai ở đúng trường hợp đó).
 *
 * Object này CHỈ xử lý phần (1) — cắt/dịch giờ trong file phụ đề. Phần (2) — ghép vào video
 * đã cắt sẵn — nằm ở `VideoEngine.burnSubtitlesOntoAlreadyCutVideo()`.
 */
object SubtitleUtils {

    /** 1 dòng thoại đã parse: thời điểm hiện/ẩn (giây, tính từ đầu file phụ đề GỐC) + nội dung. */
    data class SubtitleEntry(val startSec: Double, val endSec: Double, val text: String)

    /**
     * Cắt + dịch giờ file phụ đề .srt hoặc .ass cho khớp với 1 đoạn [rangeStartSec,
     * rangeEndSec] tính theo mốc thời gian VIDEO GỐC (trước khi cắt) — trả về nội dung file
     * phụ đề MỚI, mốc 0 giờ ứng với `rangeStartSec`, tức là khớp thẳng với video ĐÃ CẮT
     * (video đã cắt luôn bắt đầu từ giây 0 của chính nó).
     *
     * Quy tắc với các dòng thoại nằm VẮT NGANG biên (bắt đầu trước rangeStartSec nhưng vẫn
     * còn hiện tới sau đó, hoặc bắt đầu trước rangeEndSec nhưng còn hiện qua sau đó): VẪN GIỮ
     * LẠI dòng đó (không bỏ hẳn, tránh mất ngữ cảnh), nhưng CẮT NGẮN phần thời gian hiện cho
     * gọn trong đúng đoạn đã cắt (coerce về [0, rangeEndSec-rangeStartSec]).
     *
     * @param format "srt" hoặc "ass" (không phân biệt hoa/thường, tự nhận theo đuôi file lúc gọi).
     * @throws IllegalArgumentException nếu định dạng không được hỗ trợ, hoặc không có dòng
     *         thoại nào rơi vào đúng đoạn [rangeStartSec, rangeEndSec] (rất có thể do người
     *         dùng nhập nhầm mốc "bắt đầu ở giây nào trong video gốc").
     */
    fun shiftSubtitleFile(inputFile: File, format: String, rangeStartSec: Double, rangeEndSec: Double): String {
        val raw = inputFile.readText(Charsets.UTF_8)
        return when (format.lowercase(Locale.ROOT)) {
            "srt" -> shiftSrt(raw, rangeStartSec, rangeEndSec)
            "ass", "ssa" -> shiftAss(raw, rangeStartSec, rangeEndSec)
            else -> throw IllegalArgumentException(
                "Định dạng phụ đề '$format' chưa được hỗ trợ cho tính năng cắt/dịch giờ này " +
                    "(chỉ hỗ trợ .srt và .ass/.ssa) — riêng tính năng 'cắt video + ghép phụ đề " +
                    "trong 1 bước lúc còn video gốc' (VideoEngine.trimWithBurnedSubtitles) thì " +
                    "vẫn nhận mọi định dạng libass đọc được (kể cả .vtt) vì FFmpeg tự lo phần đọc."
            )
        }
    }

    // ---------------------------------------------------------------------------------
    // SRT: khối cách nhau bởi dòng trống, mỗi khối: [số thứ tự] / [mốc giờ] / [1+ dòng chữ]
    // Mốc giờ: "00:01:23,456 --> 00:01:25,000"
    // ---------------------------------------------------------------------------------
    private val srtTimeRegex = Regex(
        """(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})"""
    )

    private fun parseSrtTimeToSec(h: String, m: String, s: String, ms: String): Double =
        h.toInt() * 3600.0 + m.toInt() * 60.0 + s.toInt() + ms.toInt() / 1000.0

    private fun formatSrtTime(totalSec: Double): String {
        val clamped = totalSec.coerceAtLeast(0.0)
        val totalMs = Math.round(clamped * 1000.0)
        val h = totalMs / 3_600_000
        val m = (totalMs % 3_600_000) / 60_000
        val s = (totalMs % 60_000) / 1000
        val ms = totalMs % 1000
        return "%02d:%02d:%02d,%03d".format(h, m, s, ms)
    }

    private fun shiftSrt(raw: String, rangeStartSec: Double, rangeEndSec: Double): String {
        val rangeDuration = rangeEndSec - rangeStartSec
        // Chuẩn hoá xuống dòng (file .srt tải từ nhiều nguồn có thể dùng \r\n) rồi tách khối
        // theo dòng trống — khối cuối file có thể không có dòng trống theo sau nên thêm 1
        // dòng trống ở cuối cho chắc trước khi tách.
        val normalized = raw.replace("\r\n", "\n").replace("\r", "\n").trim() + "\n\n"
        val blocks = normalized.split(Regex("""\n\s*\n"""))
        val kept = mutableListOf<Triple<Double, Double, String>>()
        for (block in blocks) {
            val lines = block.trim().split("\n").filter { it.isNotBlank() }
            if (lines.isEmpty()) continue
            // Dòng số thứ tự (nếu có) nằm riêng 1 dòng trước dòng mốc giờ — tìm dòng mốc giờ
            // bằng regex thay vì giả định đúng vị trí dòng thứ mấy, để chịu được file hơi
            // lệch định dạng (thiếu số thứ tự, thừa dòng trống lạ...).
            val timeLineIndex = lines.indexOfFirst { srtTimeRegex.containsMatchIn(it) }
            if (timeLineIndex == -1) continue // khối hỏng/không đúng định dạng -> bỏ qua, không dừng cả file
            val match = srtTimeRegex.find(lines[timeLineIndex]) ?: continue
            // LƯU Ý: KHÔNG dùng match.destructured ở đây — thư viện chuẩn Kotlin chỉ hỗ trợ
            // destructuring tới component5() cho MatchResult, trong khi regex này có 8 nhóm
            // (h1,m1,s1,ms1,h2,m2,s2,ms2) -> phải lấy qua groupValues theo chỉ số (0 là toàn
            // bộ chuỗi khớp, nhóm thật bắt đầu từ 1).
            val g = match.groupValues
            val entryStart = parseSrtTimeToSec(g[1], g[2], g[3], g[4])
            val entryEnd = parseSrtTimeToSec(g[5], g[6], g[7], g[8])
            if (entryEnd <= rangeStartSec || entryStart >= rangeEndSec) continue // hoàn toàn ngoài đoạn -> bỏ
            val text = lines.drop(timeLineIndex + 1).joinToString("\n")
            val newStart = (entryStart - rangeStartSec).coerceIn(0.0, rangeDuration)
            val newEnd = (entryEnd - rangeStartSec).coerceIn(0.0, rangeDuration)
            if (newEnd - newStart < 0.05) continue // cắt trúng đúng biên, còn lại chưa tới 50ms -> bỏ, không đáng hiện
            kept.add(Triple(newStart, newEnd, text))
        }
        if (kept.isEmpty()) {
            throw IllegalStateException(
                "Không có dòng thoại nào rơi vào đoạn [$rangeStartSec giây - $rangeEndSec giây] " +
                    "trong file phụ đề — kiểm tra lại mốc 'bắt đầu ở giây nào trong video gốc' đã nhập đúng chưa."
            )
        }
        val sb = StringBuilder()
        kept.forEachIndexed { i, (start, end, text) ->
            sb.append(i + 1).append('\n')
            sb.append(formatSrtTime(start)).append(" --> ").append(formatSrtTime(end)).append('\n')
            sb.append(text).append("\n\n")
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------------------------
    // ASS/SSA: giữ nguyên mọi phần khác (Script Info, Styles...), CHỈ xử lý các dòng bắt đầu
    // bằng "Dialogue:". Cấu trúc 1 dòng Dialogue (đúng 9 trường trước phần Text, phần Text
    // CÓ THỂ chứa dấu phẩy nên phải giới hạn số lần split):
    //   Dialogue: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
    // Mốc giờ ASS: "H:MM:SS.cc" (phần trăm giây - centisecond, 2 chữ số, KHÁC .srt dùng mili-
    // giây 3 chữ số).
    // ---------------------------------------------------------------------------------
    private val assTimeRegex = Regex("""(\d+):(\d{2}):(\d{2})\.(\d{2})""")

    private fun parseAssTimeToSec(h: String, m: String, s: String, cs: String): Double =
        h.toInt() * 3600.0 + m.toInt() * 60.0 + s.toInt() + cs.toInt() / 100.0

    private fun formatAssTime(totalSec: Double): String {
        val clamped = totalSec.coerceAtLeast(0.0)
        val totalCs = Math.round(clamped * 100.0)
        val h = totalCs / 360_000
        val m = (totalCs % 360_000) / 6_000
        val s = (totalCs % 6_000) / 100
        val cs = totalCs % 100
        return "%d:%02d:%02d.%02d".format(h, m, s, cs)
    }

    private fun shiftAss(raw: String, rangeStartSec: Double, rangeEndSec: Double): String {
        val rangeDuration = rangeEndSec - rangeStartSec
        val normalized = raw.replace("\r\n", "\n").replace("\r", "\n")
        val outLines = mutableListOf<String>()
        var dialogueCount = 0
        for (line in normalized.split("\n")) {
            if (!line.trimStart().startsWith("Dialogue:", ignoreCase = true)) {
                outLines.add(line) // Script Info / Styles / dòng khác -> giữ nguyên, không đụng
                continue
            }
            // "Dialogue:" + đúng 9 dấu phẩy trước phần Text -> split giới hạn 10 phần.
            val afterPrefix = line.substringAfter(":").trim()
            val fields = afterPrefix.split(",", limit = 10)
            if (fields.size < 10) { outLines.add(line); continue } // dòng lệch định dạng -> giữ nguyên, an toàn hơn bỏ
            val startMatch = assTimeRegex.find(fields[1])
            val endMatch = assTimeRegex.find(fields[2])
            if (startMatch == null || endMatch == null) { outLines.add(line); continue }
            val (h1, m1, s1, cs1) = startMatch.destructured
            val (h2, m2, s2, cs2) = endMatch.destructured
            val entryStart = parseAssTimeToSec(h1, m1, s1, cs1)
            val entryEnd = parseAssTimeToSec(h2, m2, s2, cs2)
            if (entryEnd <= rangeStartSec || entryStart >= rangeEndSec) continue // ngoài đoạn -> bỏ dòng này
            val newStart = (entryStart - rangeStartSec).coerceIn(0.0, rangeDuration)
            val newEnd = (entryEnd - rangeStartSec).coerceIn(0.0, rangeDuration)
            if (newEnd - newStart < 0.05) continue
            dialogueCount++
            val newFields = fields.toMutableList()
            newFields[1] = formatAssTime(newStart)
            newFields[2] = formatAssTime(newEnd)
            outLines.add("Dialogue: " + newFields.joinToString(","))
        }
        if (dialogueCount == 0) {
            throw IllegalStateException(
                "Không có dòng thoại nào rơi vào đoạn [$rangeStartSec giây - $rangeEndSec giây] " +
                    "trong file phụ đề .ass — kiểm tra lại mốc 'bắt đầu ở giây nào trong video gốc' đã nhập đúng chưa."
            )
        }
        return outLines.joinToString("\n")
    }
}
