package com.videoaistudio.app.inference

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Gọi API do CHÍNH NGƯỜI DÙNG khai báo (endpoint + API key tự nhập trong Settings).
 * App không gắn cứng với bất kỳ nhà cung cấp nào (OpenAI, Replicate, hay server riêng
 * của người dùng tự host) — tất cả đều đi qua cùng 1 luồng generic dưới đây.
 *
 * Giả định giao thức tối thiểu: POST multipart/form-data gồm file input,
 * trả về JSON có field "output_url" hoặc file nhị phân trực tiếp.
 * Vì mỗi API thực tế có format khác nhau, phần parse response sẽ cần
 * người dùng/hoặc bước cấu hình thêm "response mapping" ở Phase 2 —
 * bản skeleton này dựng sẵn phần gọi mạng + xác thực.
 */
class ApiProvider(
    private val config: ModelConfig
) : IInferenceProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    override suspend fun isReady(): Boolean = withContext(Dispatchers.IO) {
        !config.apiEndpoint.isNullOrBlank()
    }

    override suspend fun runInference(input: InferenceInput): InferenceOutput = withContext(Dispatchers.IO) {
        val endpoint = config.apiEndpoint
        if (endpoint.isNullOrBlank()) {
            return@withContext InferenceOutput(success = false, errorMessage = "Chưa cấu hình API endpoint cho ${config.displayName}")
        }

        try {
            val file = File(input.inputFilePath)
            val fileBody = file.asRequestBody("application/octet-stream".toMediaTypeOrNull())

            val multipartBuilder = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name, fileBody)
                .addFormDataPart("task_type", input.taskType.name)

            input.extraParams.forEach { (k, v) -> multipartBuilder.addFormDataPart(k, v) }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .post(multipartBuilder.build())

            if (!config.apiKey.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer ${config.apiKey}")
            }
            config.apiExtraHeaders.forEach { (k, v) -> requestBuilder.addHeader(k, v) }

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext InferenceOutput(
                        success = false,
                        errorMessage = "API trả lỗi HTTP ${response.code}: ${response.message}"
                    )
                }
                // TODO (Phase 2): parse response theo format cụ thể của API người dùng chọn
                // (JSON chứa URL kết quả, hoặc trả thẳng file binary). Bản skeleton chỉ
                // xác nhận gọi API thành công.
                InferenceOutput(success = true, metadata = mapOf("raw_status" to response.code.toString()))
            }
        } catch (e: Exception) {
            InferenceOutput(success = false, errorMessage = e.message)
        }
    }

    override fun release() {
        // OkHttpClient không cần giải phóng thủ công theo request-scope này.
    }
}
