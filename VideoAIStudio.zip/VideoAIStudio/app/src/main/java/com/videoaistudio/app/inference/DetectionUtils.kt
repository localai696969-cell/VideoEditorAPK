package com.videoaistudio.app.inference

import kotlin.math.max
import kotlin.math.min

/** 1 vùng phát hiện được: toạ độ theo pixel ảnh gốc, đã áp threshold + NMS. */
data class DetectionBox(
    val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val classId: Int,
    val confidence: Float
)

/**
 * Giải mã output theo đúng chuẩn xuất ONNX phổ biến nhất hiện nay cho model
 * detection (họ YOLOv8/v9/v11 khi export qua Ultralytics): shape [1, 4+numClasses, numBoxes],
 * mỗi box gồm [x_center, y_center, width, height, score_class0, score_class1, ...].
 *
 * Đây KHÔNG phải hardcode 1 model cụ thể — đây là định dạng chung của CẢ HỌ model
 * YOLO hiện đại khi xuất ONNX theo cách chuẩn của Ultralytics, được rất nhiều model
 * detection/segmentation người dùng tải về sử dụng. Model thuộc họ khác (SSD,
 * EfficientDet...) có cấu trúc output khác, chưa được hỗ trợ ở bản này — cần bổ
 * sung thêm 1 hàm decode riêng theo đúng nguyên lý này khi cần, không phải viết
 * lại cả pipeline.
 */
object DetectionUtils {

    fun decodeYoloV8Style(
        rawOutput: FloatArray,
        numClasses: Int,
        numBoxes: Int,
        confThreshold: Float,
        origWidth: Int,
        origHeight: Int,
        modelInputSize: Int
    ): List<DetectionBox> {
        val boxes = mutableListOf<DetectionBox>()
        val numFeatures = 4 + numClasses
        if (rawOutput.size < numFeatures * numBoxes) return boxes

        val scaleX = origWidth.toFloat() / modelInputSize
        val scaleY = origHeight.toFloat() / modelInputSize

        for (b in 0 until numBoxes) {
            var bestClass = -1
            var bestScore = 0f
            for (c in 0 until numClasses) {
                val score = rawOutput[(4 + c) * numBoxes + b]
                if (score > bestScore) {
                    bestScore = score
                    bestClass = c
                }
            }
            if (bestScore < confThreshold || bestClass < 0) continue

            val xc = rawOutput[0 * numBoxes + b] * scaleX
            val yc = rawOutput[1 * numBoxes + b] * scaleY
            val w = rawOutput[2 * numBoxes + b] * scaleX
            val h = rawOutput[3 * numBoxes + b] * scaleY

            boxes.add(
                DetectionBox(
                    x1 = (xc - w / 2).coerceIn(0f, origWidth.toFloat()),
                    y1 = (yc - h / 2).coerceIn(0f, origHeight.toFloat()),
                    x2 = (xc + w / 2).coerceIn(0f, origWidth.toFloat()),
                    y2 = (yc + h / 2).coerceIn(0f, origHeight.toFloat()),
                    classId = bestClass,
                    confidence = bestScore
                )
            )
        }
        return boxes
    }

    /** Non-Max Suppression chuẩn: loại các box trùng lặp nhiều, giữ box tự tin nhất. */
    fun nms(boxes: List<DetectionBox>, iouThreshold: Float = 0.45f): List<DetectionBox> {
        val sorted = boxes.sortedByDescending { it.confidence }.toMutableList()
        val result = mutableListOf<DetectionBox>()
        while (sorted.isNotEmpty()) {
            val best = sorted.removeAt(0)
            result.add(best)
            sorted.removeAll { iou(best, it) > iouThreshold && it.classId == best.classId }
        }
        return result
    }

    fun iou(a: DetectionBox, b: DetectionBox): Float {
        val interX1 = max(a.x1, b.x1)
        val interY1 = max(a.y1, b.y1)
        val interX2 = min(a.x2, b.x2)
        val interY2 = min(a.y2, b.y2)
        val interArea = max(0f, interX2 - interX1) * max(0f, interY2 - interY1)
        val areaA = (a.x2 - a.x1) * (a.y2 - a.y1)
        val areaB = (b.x2 - b.x1) * (b.y2 - b.y1)
        val union = areaA + areaB - interArea
        return if (union <= 0f) 0f else interArea / union
    }
}
