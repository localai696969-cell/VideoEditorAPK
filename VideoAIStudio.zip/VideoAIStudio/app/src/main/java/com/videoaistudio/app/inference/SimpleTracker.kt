package com.videoaistudio.app.inference

import android.graphics.Bitmap

/**
 * Theo dõi đơn giản dựa trên IoU (Intersection-over-Union) giữa frame liền kề để
 * gán 1 ID xuyên suốt cho cùng 1 object — KHÔNG phải Re-ID thật (không dùng đặc
 * trưng khuôn mặt/dáng người để nhận diện lại).
 *
 * GIỚI HẠN THÀNH THẬT (đúng như đã trao đổi): cách này chỉ theo dõi được object
 * liên tục xuất hiện qua các frame liền kề. Nếu object bị che khuất hoàn toàn rồi
 * xuất hiện lại, hoặc rời khỏi khung hình rồi quay lại, tracker này sẽ coi đó là
 * 1 ID MỚI — không nhận ra "đây vẫn là người lúc nãy". Muốn giải quyết đúng cần
 * thêm model embedding Re-ID riêng (việc lớn, để ở phase sau).
 */
class SimpleIouTracker(private val iouMatchThreshold: Float = 0.3f, private val maxMissedFrames: Int = 5) {

    private data class Track(val id: Int, var lastBox: DetectionBox, var missedFrames: Int)

    private val tracks = mutableListOf<Track>()
    private var nextId = 1

    /** Gọi cho mỗi frame theo thứ tự thời gian. Trả về danh sách (box, trackId) tương ứng. */
    fun update(detections: List<DetectionBox>): List<Pair<DetectionBox, Int>> {
        val result = mutableListOf<Pair<DetectionBox, Int>>()
        val usedTrackIndexes = mutableSetOf<Int>()

        for (det in detections) {
            var bestTrackIdx = -1
            var bestIou = iouMatchThreshold
            for ((idx, track) in tracks.withIndex()) {
                if (idx in usedTrackIndexes) continue
                if (track.lastBox.classId != det.classId) continue
                val iouVal = DetectionUtils.iou(track.lastBox, det)
                if (iouVal > bestIou) {
                    bestIou = iouVal
                    bestTrackIdx = idx
                }
            }

            if (bestTrackIdx >= 0) {
                tracks[bestTrackIdx].lastBox = det
                tracks[bestTrackIdx].missedFrames = 0
                usedTrackIndexes.add(bestTrackIdx)
                result.add(det to tracks[bestTrackIdx].id)
            } else {
                val newTrack = Track(nextId++, det, 0)
                tracks.add(newTrack)
                result.add(det to newTrack.id)
            }
        }

        // Tăng số frame bị lỡ cho track không khớp được ở frame này, xoá nếu quá hạn
        for ((idx, track) in tracks.withIndex()) {
            if (idx !in usedTrackIndexes) track.missedFrames++
        }
        tracks.removeAll { it.missedFrames > maxMissedFrames }

        return result
    }
}

/**
 * Đo độ nét ảnh bằng phương sai Laplacian xấp xỉ (không dùng OpenCV, tự tính bằng
 * kernel biên đơn giản trên ảnh grayscale). Điểm càng cao = ảnh càng nét.
 * Dùng để lọc bớt các crop mờ (do chuyển động nhanh, out-focus) trước khi lưu.
 */
object ImageSharpness {

    fun computeScore(bitmap: Bitmap): Double {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 3 || h < 3) return 0.0

        val gray = IntArray(w * h)
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            gray[i] = (r + g + b) / 3
        }

        val laplacianValues = mutableListOf<Int>()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val center = gray[y * w + x]
                val up = gray[(y - 1) * w + x]
                val down = gray[(y + 1) * w + x]
                val left = gray[y * w + (x - 1)]
                val right = gray[y * w + (x + 1)]
                val laplacian = (up + down + left + right - 4 * center)
                laplacianValues.add(laplacian)
            }
        }

        val mean = laplacianValues.average()
        val variance = laplacianValues.sumOf { (it - mean) * (it - mean) } / laplacianValues.size
        return variance
    }
}
