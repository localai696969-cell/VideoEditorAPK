package com.videoaistudio.app.ui

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.videoaistudio.app.databinding.ActivityUpscaleBinding
import com.videoaistudio.app.inference.InferenceManager
import com.videoaistudio.app.inference.LocalModelProvider
import com.videoaistudio.app.inference.ModelConfig
import com.videoaistudio.app.inference.ProviderSource
import com.videoaistudio.app.inference.TaskType
import com.videoaistudio.app.inference.UpscaleModelSpec
import com.videoaistudio.app.video.FileUtils
import com.videoaistudio.app.video.VideoEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.ceil
import kotlin.math.min

/**
 * Pipeline upscale XỬ LÝ CUỐN CHIẾU theo từng đoạn ~5 giây:
 * - Tách frame CHỈ của 1 đoạn -> upscale -> nén thành 1 chunk video nhỏ -> XOÁ NGAY
 *   frame thô/đã xử lý của đoạn đó trước khi sang đoạn tiếp theo.
 * - Ghép các chunk lại -> XOÁ NGAY từng chunk lẻ sau khi ghép thành công.
 * - Ghép audio gốc vào -> XOÁ NGAY bản video-only sau khi ghép audio thành công.
 *
 * Nhờ vậy, dung lượng tạm tại bất kỳ thời điểm nào chỉ khoảng: 1 đoạn frame thô/đã xử lý
 * (nhỏ) + tối đa 1 bản sao gần đầy đủ của video đang ghép (không cộng dồn 2-3 bản như
 * thiết kế trước). Dung lượng FILE CUỐI CÙNG vẫn phụ thuộc độ dài + độ phân giải video
 * (vd 1 giờ video 4K ~9GB ở CRF 23) — đây là giới hạn vật lý của video số, xử lý cuốn
 * chiếu không thay đổi được con số này, chỉ tránh lãng phí bản sao dư thừa.
 */
class UpscaleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUpscaleBinding
    private lateinit var inferenceManager: InferenceManager
    private var configs: List<ModelConfig> = emptyList()
    private var selectedVideoPath: String? = null
    private var detectedSpec: UpscaleModelSpec? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { importVideo(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpscaleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inferenceManager = InferenceManager(applicationContext)
        FileUtils.clearVideoInputCache(applicationContext)
        configs = inferenceManager.getAllConfigs().filter {
            it.taskType == TaskType.VIDEO_UPSCALE && it.source == ProviderSource.LOCAL_MODEL
        }

        if (configs.isEmpty()) {
            Toast.makeText(this, "Chưa có model Upscale local nào được cấu hình. Vào 'Cấu hình Model' để thêm.", Toast.LENGTH_LONG).show()
        }

        binding.spinnerModel.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, configs.map { it.displayName }
        )

        binding.btnDetectSpec.setOnClickListener { detectSpec() }
        binding.btnPickVideo.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        binding.btnRunUpscale.setOnClickListener { runUpscale() }

        binding.edtQp.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) = updateSizeEstimate()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun updateSizeEstimate() {
        val videoPath = selectedVideoPath
        val spec = detectedSpec
        val qp = binding.edtQp.text.toString().toIntOrNull()

        if (videoPath == null || spec == null || qp == null) {
            binding.txtSizeEstimate.text = "Ước tính dung lượng: chưa đủ thông tin (cần chọn video + dò model trước)"
            return
        }

        val originalBitrate = FileUtils.calculateActualBitrateBps(videoPath)
        val durationSec = FileUtils.getVideoDurationSec(videoPath)
        if (originalBitrate <= 0 || durationSec <= 0) {
            binding.txtSizeEstimate.text = "Ước tính dung lượng: không đọc được bitrate gốc để tính"
            return
        }

        val estimatedBytes = FileUtils.estimateUpscaledSizeBytes(originalBitrate, spec.detectedScaleFactor, durationSec, qp)
        binding.txtSizeEstimate.text = "Ước tính dung lượng sau upscale: ~${FileUtils.formatBytes(estimatedBytes)} " +
                "(dựa trên bitrate gốc, hệ số x${spec.detectedScaleFactor}, QP $qp — số thực tế có thể lệch tuỳ nội dung)"
    }

    private fun currentConfig(): ModelConfig? = configs.getOrNull(binding.spinnerModel.selectedItemPosition)

    private fun importVideo(uri: Uri) {
        try {
            val name = FileUtils.queryDisplayName(this, uri)
            val file = FileUtils.copyUriToCache(this, uri, name)
            selectedVideoPath = file.absolutePath
            binding.txtSelectedVideo.text = "Đã chọn: $name"
            updateSizeEstimate()
        } catch (e: Exception) {
            Toast.makeText(this, "Không đọc được video: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun detectSpec() {
        val config = currentConfig() ?: run {
            Toast.makeText(this, "Chưa có model nào để dò", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            binding.txtModelSpec.text = "Đang dò thông số model..."
            val provider = LocalModelProvider(applicationContext, config)
            val spec = provider.detectUpscaleModelSpec()
            provider.release()
            detectedSpec = spec
            binding.txtModelSpec.text = if (spec != null) {
                "Model: ${config.displayName}\nBố cục: ${spec.layout}\nHệ số upscale tự dò: x${spec.detectedScaleFactor}\nHỗ trợ độ phân giải linh hoạt: ${if (spec.supportsDynamicResolution) "Có" else "Không (cố định kích thước)"}"
            } else {
                "Không dò được thông số — model có thể không đúng chuẩn input/output ảnh 4 chiều (NCHW/NHWC 3 kênh màu) mà app hỗ trợ."
            }
            if (spec != null) updateSizeEstimate()
        }
    }

    private fun runUpscale() {
        val config = currentConfig()
        val videoPath = selectedVideoPath
        val spec = detectedSpec

        if (config == null || videoPath == null) {
            Toast.makeText(this, "Vui lòng chọn model và video trước", Toast.LENGTH_SHORT).show()
            return
        }
        if (spec == null) {
            Toast.makeText(this, "Vui lòng bấm 'Dò thông số model' trước khi chạy", Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = android.view.View.VISIBLE
        binding.btnRunUpscale.isEnabled = false
        binding.txtResult.text = ""

        lifecycleScope.launch {
            val workDir = File(cacheDir, "upscale_work_${System.currentTimeMillis()}")
            workDir.mkdirs()

            val durationSec = FileUtils.getVideoDurationSec(videoPath)
            if (durationSec <= 0.0) {
                finishWithError("Không đọc được thời lượng video")
                return@launch
            }
            val fps = FileUtils.getVideoFps(videoPath)
            val numChunks = ceil(durationSec / CHUNK_SECONDS).toInt().coerceAtLeast(1)

            val provider = LocalModelProvider(applicationContext, config)
            val chunkVideoPaths = mutableListOf<String>()
            var aborted = false

            for (chunkIndex in 0 until numChunks) {
                val startSec = chunkIndex * CHUNK_SECONDS
                val thisChunkDuration = min(CHUNK_SECONDS, durationSec - startSec)

                withContext(Dispatchers.Main) {
                    binding.progressBar.max = numChunks
                    binding.progressBar.progress = chunkIndex
                    binding.txtProgress.text = "Đang xử lý đoạn ${chunkIndex + 1}/$numChunks (${"%.1f".format(java.util.Locale.US, startSec)}s - ${"%.1f".format(java.util.Locale.US, startSec + thisChunkDuration)}s)"
                }

                val rawFramesDir = File(workDir, "raw_$chunkIndex")
                val processedFramesDir = File(workDir, "proc_$chunkIndex").apply { mkdirs() }

                val extractResult = VideoEngine.extractFrameChunk(videoPath, rawFramesDir, startSec, thisChunkDuration)
                if (!extractResult.success) {
                    finishWithError("Tách frame đoạn ${chunkIndex + 1} thất bại:\n${extractResult.log}")
                    aborted = true
                    break
                }

                val frameFiles = rawFramesDir.listFiles { f -> f.extension == "png" }?.sortedBy { it.name } ?: emptyList()

                var chunkOk = true
                withContext(Dispatchers.Default) {
                    for (frameFile in frameFiles) {
                        val bitmap = BitmapFactory.decodeFile(frameFile.absolutePath) ?: continue
                        val upscaled = provider.upscaleFrame(bitmap, spec.layout)
                        bitmap.recycle()
                        if (upscaled == null) {
                            chunkOk = false
                            break
                        }
                        val outFile = File(processedFramesDir, frameFile.name)
                        outFile.outputStream().use { out -> upscaled.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }
                        upscaled.recycle()
                    }
                }

                // Xoá frame thô NGAY sau khi xử lý xong đoạn này, không đợi tới cuối video
                rawFramesDir.deleteRecursively()

                if (!chunkOk) {
                    processedFramesDir.deleteRecursively()
                    finishWithError("Model xử lý thất bại ở đoạn ${chunkIndex + 1}. Dừng lại để tránh video hỏng.")
                    aborted = true
                    break
                }

                val chunkOutputPath = File(workDir, "chunk_$chunkIndex.mp4").absolutePath
                val qp = binding.edtQp.text.toString().toIntOrNull() ?: 26
                val originalBitrateForChunk = FileUtils.calculateActualBitrateBps(videoPath)
                val bitrateForHw = if (originalBitrateForChunk > 0) {
                    ((originalBitrateForChunk / 1000.0) * spec.detectedScaleFactor * spec.detectedScaleFactor * 0.8).toInt().coerceAtLeast(500)
                } else 4000
                val reassembleChunk = VideoEngine.reassembleChunkVideoOnly(processedFramesDir, fps, chunkOutputPath, qp, bitrateForHw)

                // Xoá frame đã xử lý NGAY sau khi đã nén xong thành chunk video nhỏ
                processedFramesDir.deleteRecursively()

                if (!reassembleChunk.success) {
                    finishWithError("Dựng đoạn ${chunkIndex + 1} thất bại:\n${reassembleChunk.log}")
                    aborted = true
                    break
                }
                chunkVideoPaths.add(chunkOutputPath)
            }

            provider.release()

            if (aborted) {
                workDir.deleteRecursively()
                return@launch
            }

            binding.txtProgress.text = "Đang ghép các đoạn lại..."
            val videoOnlyPath = File(workDir, "video_only.mp4").absolutePath
            val concatResult = VideoEngine.concatVideoOnlyChunks(chunkVideoPaths, videoOnlyPath)

            // Xoá từng chunk lẻ NGAY sau khi ghép thành công — tránh giữ cả chunk lẻ
            // lẫn bản ghép cùng lúc
            if (concatResult.success) {
                chunkVideoPaths.forEach { File(it).delete() }
            } else {
                workDir.deleteRecursively()
                finishWithError("Ghép các đoạn thất bại:\n${concatResult.log}")
                return@launch
            }

            binding.txtProgress.text = "Đang ghép âm thanh gốc..."
            val outputDir = FileUtils.getOutputDir(this@UpscaleActivity).absolutePath
            val muxResult = VideoEngine.muxOriginalAudio(videoOnlyPath, videoPath, outputDir)

            // Xoá bản video-only NGAY sau khi ghép audio thành công — không giữ thêm bản dư
            File(videoOnlyPath).delete()
            workDir.deleteRecursively()

            binding.progressBar.visibility = android.view.View.GONE
            binding.btnRunUpscale.isEnabled = true

            binding.txtResult.text = if (muxResult.success) {
                val actualBytes = muxResult.outputPaths.firstOrNull()?.let { File(it).length() } ?: 0L
                "Hoàn tất! File lưu tại:\n${muxResult.outputPaths.joinToString()}\n\n" +
                        "Dung lượng thật: ${FileUtils.formatBytes(actualBytes)} " +
                        "(ước tính trước đó: ${binding.txtSizeEstimate.text})"
            } else {
                "Ghép âm thanh thất bại:\n${muxResult.log}"
            }
        }
    }

    private fun finishWithError(message: String) {
        binding.progressBar.visibility = android.view.View.GONE
        binding.btnRunUpscale.isEnabled = true
        binding.txtResult.text = message
    }

    companion object {
        private const val CHUNK_SECONDS = 5.0
    }
}
