package com.videoaistudio.app.video

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Kết quả chung cho mọi thao tác video. */
data class VideoOpResult(
    val success: Boolean,
    val outputPaths: List<String> = emptyList(),
    val log: String = ""
)

/**
 * Lớp bọc FFmpeg cho các thao tác video cơ bản.
 * Tất cả hàm đều:
 * - Giữ nguyên định dạng container gốc (lấy đuôi file input làm đuôi file output),
 *   theo đúng yêu cầu "output giống định dạng video gốc".
 * - Dùng "-c copy" (stream copy, không encode lại) cho các thao tác không cần
 *   đổi codec (trim/split/merge/tách audio) — nhanh, giữ nguyên chất lượng tuyệt đối.
 * - Riêng compress bắt buộc phải encode lại (đổi codec/bitrate) vì đó chính là bản chất
 *   của việc giảm dung lượng.
 */
object VideoEngine {

    /**
     * Cắt 1 đoạn video, ĐỒNG THỜI ghép cứng (burn-in) phụ đề — dùng file phụ đề của
     * TOÀN BỘ video gốc (mốc thời gian trong file phụ đề tính theo video GỐC, chưa cắt),
     * vẫn ra đúng đúng câu thoại ở đúng thời điểm trong đoạn ĐÃ CẮT.
     *
     * KỸ THUẬT DÙNG (đã tra cứu kỹ, không đoán — đây là kiểu lỗi cực dễ sai âm thầm):
     * đặt "-ss"/"-to" SAU "-i" (output seeking) — NGƯỢC LẠI với quy ước "-ss trước -i"
     * dùng ở trim()/split() phía trên. Đây là CHỦ Ý, không phải nhầm lẫn — ĐỪNG sửa lại
     * cho "giống" trim() nếu sau này dọn code, sẽ làm HỎNG đúng tính năng này:
     *   - Input seeking (-ss TRƯỚC -i, dùng ở trim()/split()) nhảy thẳng tới gần vị trí
     *     cần cắt trước khi FFmpeg biết gì về các frame trước đó — khi đi qua bộ lọc
     *     (-vf), timestamp các frame ĐÃ BỊ DỊCH tương đối theo điểm seek, không còn khớp
     *     với mốc thời gian TUYỆT ĐỐI trong file phụ đề gốc nữa -> phụ đề ra sai giờ.
     *   - Output seeking (-ss SAU -i, dùng ở đây) bắt FFmpeg giải mã (rồi bỏ) toàn bộ
     *     đoạn từ đầu file tới điểm cắt — CHẬM HƠN — nhưng đổi lại bộ lọc subtitles nhìn
     *     thấy ĐÚNG timestamp tuyệt đối của video gốc, khớp chính xác với mốc thời gian
     *     ghi trong file phụ đề — đây là lý do BẮT BUỘC phải làm vậy cho tính năng này.
     * Trong chuỗi lọc: "subtitles=...,setpts=PTS-STARTPTS" — ĐÚNG THỨ TỰ quan trọng:
     *   1. subtitles=... chạy TRƯỚC, lúc timestamp còn nguyên vẹn (tuyệt đối) -> khớp
     *      đúng phụ đề.
     *   2. setpts=PTS-STARTPTS chạy SAU, làm tròn lại mốc 0 cho video XUẤT RA (nếu không
     *      có bước này, file output sẽ mang timestamp tuyệt đối cũ (vd bắt đầu ở giây thứ
     *      1890) -> 1 số trình phát sẽ hiện màn hình đen/phải tua mới thấy hình khi mở
     *      file output đó, dù bản thân file vẫn cắt đúng đoạn).
     * Không thể dùng "-c copy" (giữ nguyên chất lượng, không encode lại) cho việc này —
     * ghép phụ đề bắt buộc phải VẼ LẠI từng khung hình nên bắt buộc phải encode lại video
     * (audio vẫn copy được, không đụng gì tới audio).
     *
     * ĐƯỜNG DẪN FILE PHỤ ĐỀ: bắt buộc phải là đường dẫn ĐƠN GIẢN, KHÔNG CÓ ký tự đặc biệt
     * (dấu `:`, dấu `'`...) vì đây là 1 phần của cú pháp filter "subtitles=...", không phải
     * chỉ là 1 đường dẫn file bình thường — có ký tự đặc biệt trong đường dẫn sẽ làm sai cú
     * pháp filter, không phải lỗi "file không tồn tại" dễ nhận ra. Vì lý do này,
     * VideoToolsActivity PHẢI copy file phụ đề người dùng chọn vào cache với tên CỐ ĐỊNH
     * đơn giản (xem `FileUtils.copySubtitleToCache`) trước khi gọi hàm này — KHÔNG được
     * truyền thẳng đường dẫn gốc do người dùng chọn (có thể có dấu cách, ký tự lạ tuỳ tên
     * file gốc).
     *
     * 🔴 CHƯA TEST THẬT TRÊN MÁY — tính năng mới hoàn toàn, cần xác nhận: (1) phụ đề đúng
     * giờ trong đoạn đã cắt, (2) file output phát được bình thường ngay từ đầu (không đen
     * màn hình/phải tua), (3) tốc độ xử lý chấp nhận được (sẽ CHẬM hơn trim thường vì phải
     * giải mã từ đầu file tới điểm cắt, xem giải thích ở trên — càng cắt xa đầu video càng
     * chậm, đây là đánh đổi CHỦ Ý ưu tiên đúng thay vì nhanh).
     */
    suspend fun trimWithBurnedSubtitles(
        inputPath: String,
        subtitlePath: String,
        outputDir: String,
        startSec: Double,
        endSec: Double,
        onProgress: (Int) -> Unit = {}
    ): VideoOpResult = withContext(Dispatchers.IO) {
        val ext = File(inputPath).extension
        val outputPath = File(outputDir, "trim_sub_${System.currentTimeMillis()}.$ext").absolutePath
        val duration = endSec - startSec
        val cmd = "-y -i \"$inputPath\" -ss $startSec -to $endSec " +
            "-vf \"subtitles=$subtitlePath,setpts=PTS-STARTPTS\" " +
            "-c:v libx264 -preset veryfast -crf 20 -c:a copy -avoid_negative_ts make_zero \"$outputPath\""
        // Tiến độ dùng "endSec" (không phải "duration") làm tổng — vì FFmpeg phải giải mã
        // từ đầu file tới hết điểm cắt (xem giải thích ở trên), % hiển thị nếu dùng đúng
        // "duration" sẽ đứng yên rất lâu ở gần 0% trong lúc giải mã đoạn bỏ đi, GÂY HIỂU
        // LẦM là bị treo. Dùng "endSec" cho % tăng dần ngay từ đầu, phản ánh đúng tiến trình
        // thật hơn — CHƯA đo thật trên máy để biết % có khớp chính xác tuyệt đối không.
        runFfmpegWithProgress(cmd, listOf(outputPath), endSec, onProgress)
    }

    /**
     * Như trên nhưng cho NHIỀU đoạn cùng lúc (Split + ghép phụ đề) — mỗi đoạn dùng ĐÚNG
     * file phụ đề gốc (mốc thời gian tuyệt đối), tự cắt đúng câu thoại cho đúng đoạn đó.
     */
    suspend fun splitWithBurnedSubtitles(
        inputPath: String,
        subtitlePath: String,
        outputDir: String,
        segments: List<Pair<Double, Double>>,
        onProgress: (Int) -> Unit = {}
    ): VideoOpResult = withContext(Dispatchers.IO) {
        val outputs = mutableListOf<String>()
        val logs = StringBuilder()
        for ((index, seg) in segments.withIndex()) {
            val r = trimWithBurnedSubtitles(inputPath, subtitlePath, outputDir, seg.first, seg.second) { segPercent ->
                val overall = ((index * 100 + segPercent).toDouble() / segments.size).toInt()
                onProgress(overall.coerceIn(0, 100))
            }
            logs.appendLine("Đoạn ${index + 1}: ${if (r.success) "OK" else "Lỗi — ${r.log.takeLast(200)}"}")
            if (r.success) {
                outputs.addAll(r.outputPaths)
            } else {
                return@withContext VideoOpResult(false, outputs, logs.toString())
            }
        }
        VideoOpResult(true, outputs, logs.toString())
    }

    /**
     * Ghép cứng phụ đề vào 1 video ĐÃ LÀ ĐÚNG ĐOẠN CẦN DÙNG (đã cắt sẵn từ trước, không cần
     * FFmpeg cắt gì thêm ở đây) — dùng cho đúng bài toán thật: "có phụ đề của video gốc,
     * KHÔNG CÒN video gốc, chỉ còn video đã cắt sẵn". File phụ đề truyền vào ĐÃ PHẢI được
     * cắt/dịch giờ khớp với video này từ trước (xem `SubtitleUtils.shiftSubtitleFile()`) —
     * hàm này chỉ overlay, không tự dịch giờ gì cả.
     *
     * Đơn giản hơn `trimWithBurnedSubtitles()` ở trên NHIỀU: không cần "-ss"/"-to" gì cả
     * (không cắt video), nên không có chuyện input-seeking/output-seeking gì phải lo — xử lý
     * nguyên vẹn từ đầu tới cuối video đưa vào, tốc độ tỉ lệ đúng với độ dài video đó (không
     * bị "chậm hơn vì phải giải mã bỏ đoạn đầu" như hàm kia).
     */
    suspend fun burnSubtitlesOntoAlreadyCutVideo(
        inputPath: String,
        subtitlePath: String,
        outputDir: String,
        onProgress: (Int) -> Unit = {}
    ): VideoOpResult = withContext(Dispatchers.IO) {
        val ext = File(inputPath).extension
        val outputPath = File(outputDir, "sub_burned_${System.currentTimeMillis()}.$ext").absolutePath
        val durationSec = FileUtils.getVideoDurationSec(inputPath)
        val cmd = "-y -i \"$inputPath\" -vf \"subtitles=$subtitlePath\" " +
            "-c:v libx264 -preset veryfast -crf 20 -c:a copy \"$outputPath\""
        runFfmpegWithProgress(cmd, listOf(outputPath), durationSec, onProgress)
    }

    /** Khoảng cách khung hình khoá (giây) ép khi convert — xem giải thích đầy đủ ở
     *  convertToMp4WithKnownBackend() bên dưới. 2 giây là lựa chọn phổ biến trong ngành
     *  (đủ ngắn để tua mượt, không quá ngắn làm phình dung lượng đáng kể). */
    private const val CONVERT_KEYFRAME_INTERVAL_SEC = 2

    /**
     * Convert video từ ĐỊNH DẠNG BẤT KỲ FFmpeg đọc được sang MP4 — LUÔN encode lại cả
     * hình ảnh LẪN âm thanh, KHÁC VỚI MỌI HÀM KHÁC trong file này (tất cả đều ưu tiên
     * "-c copy" để nhanh/giữ nguyên chất lượng). Đây là CHỦ Ý, không phải chưa tối ưu:
     *
     * (1) TẠI SAO PHẢI ENCODE LẠI HÌNH ẢNH — đây là cách DUY NHẤT đáp ứng đúng yêu cầu
     * "tua tới bất kỳ đâu trong video KHÔNG bị đứng hình vài giây": hiện tượng này xảy ra
     * vì trình phát KHÔNG THỂ vẽ ra 1 khung hình bất kỳ ngay lập tức — nó phải tìm khung
     * hình KHOÁ (keyframe) gần nhất TRƯỚC điểm tua rồi giải mã liên tục từ đó tới đúng
     * điểm cần — ĐÚNG cơ chế `FileUtils.findPrecedingKeyframeSec()` đã dùng ở nơi khác
     * trong app (khác chỗ dùng, cùng 1 loại giới hạn vật lý của video nén). 2 khung hình
     * khoá CÀNG CÁCH XA nhau (GOP dài) — hiện tượng đứng hình khi tua CÀNG RÕ. Định dạng
     * HLS/m3u8 ĐẶC BIỆT hay dính lỗi này vì GOP thường bị set khớp với độ dài segment
     * (thường 2-10 giây, có nguồn tệ hơn) — nếu convert kiểu chỉ đổi vỏ container
     * ("-c copy", nhanh hơn RẤT NHIỀU) mà không encode lại, file MP4 xuất ra vẫn giữ
     * NGUYÊN GOP dài đó, tua vẫn đứng y hệt như trước khi convert — KHÔNG giải quyết
     * được đúng vấn đề người dùng cần. Encode lại cho phép CHỦ ĐỘNG ép GOP ngắn
     * (CONVERT_KEYFRAME_INTERVAL_SEC giây) bất kể GOP gốc dài bao nhiêu.
     *
     * (2) TẠI SAO PHẢI ENCODE LẠI ÂM THANH (khác Trim/Split/Merge — luôn "-c:a copy"):
     * input ở đây có thể là BẤT KỲ định dạng nào (avi/mkv/mov/webm/flv/wmv/ts/m3u8...),
     * mỗi định dạng có thể mang codec audio khác nhau (mp3/ac3/opus/vorbis/pcm...) —
     * không phải codec nào cũng chơi được trong container MP4 trên mọi trình phát. Ép
     * cứng về AAC (tương thích rộng nhất với MP4) cho MỌI trường hợp — đơn giản và AN
     * TOÀN hơn nhiều so với viết thêm 1 lớp dò codec gốc rồi quyết định copy hay không
     * (đánh đổi: video vốn đã là AAC sẵn cũng bị encode lại tốn thêm chút thời gian,
     * chấp nhận được so với rủi ro ra file lỗi âm thanh trên 1 số trình phát).
     *
     * (3) CÁCH ÉP KHUNG HÌNH KHOÁ ĐỀU ĐẶN (đã tra cứu kỹ trước khi chọn — KHÔNG đoán,
     * xem PROJECT_SPEC.md mục 6 ngày 16/09/2026 để biết nguồn đã tra):
     *   - "-g <fps*giây>": tham số GOP CHUNG của FFmpeg (AVCodecContext.gop_size) — xác
     *     nhận qua ví dụ thực tế dùng ĐÚNG họ wrapper mediacodec (không phải đoán).
     *   - "-force_key_frames expr:gte(t,n_forced*N)": LỚP AN TOÀN THỨ 2, ĐỘC LẬP với
     *     "-g" — cơ chế ép khung hình khoá THEO THỜI GIAN THẬT nằm ở TẦNG CHUNG của
     *     FFmpeg (không phụ thuộc riêng bộ mã hoá nào), phòng trường hợp bộ mã hoá phần
     *     cứng của 1 số máy không tuân thủ đúng "-g" — ĐÃ CÓ TIỀN LỆ THẬT về việc bộ mã
     *     hoá phần cứng không tuân thủ đúng tham số đặt ra (xem "-bitrate_mode 2" ở
     *     compressInternal()) — dùng 2 LỚP ĐỘC LẬP thay vì tin tưởng tuyệt đối 1 lớp.
     *   - Riêng đường phần mềm (libkvazaar): "-g" KHÔNG CHẮC được kvazaar tôn trọng qua
     *     wrapper FFmpeg (wrapper của libkvazaar CHỈ định nghĩa đúng 1 tham số riêng là
     *     "-kvazaar-params", không map avctx->gop_size vào cấu hình kvazaar) — BẮT BUỘC
     *     dùng ĐÚNG tên tham số riêng của kvazaar: "period=<fps*giây>" (tài liệu kvazaar
     *     gốc: "-p, --period <integer>: Period of intra pictures — 2-N: every Nth
     *     picture is intra"). "-force_key_frames" vẫn giữ nguyên vì đây là cơ chế tầng
     *     chung, áp dụng cho MỌI bộ mã hoá kể cả kvazaar.
     *
     * (4) ĐÁNH ĐỔI CHỦ Ý: CHẬM HƠN NHIỀU so với đổi vỏ thuần tuý ("-c copy") vì phải
     * giải mã + mã hoá lại TOÀN BỘ hình ảnh — chấp nhận được vì đây là ĐÁNH ĐỔI đúng
     * yêu cầu (giống hệt cách trimWithBurnedSubtitles() đã chấp nhận chậm hơn để đúng
     * yêu cầu ghép phụ đề, xem giải thích ở đó). Bitrate mục tiêu (đường phần cứng) dùng
     * ĐÚNG bitrate thật của input (nhân hệ số 1.0, KHÔNG giảm như Compress) — giữ chất
     * lượng gần nguyên bản, đây là tính năng CONVERT ĐỊNH DẠNG chứ không phải NÉN dung
     * lượng (muốn giảm dung lượng, dùng tính năng Nén sau khi convert).
     *
     * "sourceBitrateBps" PHẢI được tính đúng ở TẦNG GỌI (VideoToolsActivity), dùng
     * `FileUtils.calculateActualBitrateBpsSmart()` — KHÔNG tự tính lại bằng
     * `File(inputPath).length()` bên trong hàm này, vì với input m3u8, "inputPath" chỉ
     * là file PLAYLIST (văn bản, gần 0 byte) — đo trực tiếp sẽ ra bitrate SAI GẦN NHƯ
     * BẰNG 0 (xem giải thích đầy đủ ở `calculateActualBitrateBpsSmart()`).
     *
     * 🔴 CHƯA TEST THẬT TRÊN MÁY — đặc biệt CHƯA xác nhận: (1) "-g" có thật sự được
     * "h264_mediacodec" tôn trọng ĐÚNG trên các dòng máy khác nhau không — đặt 1 tham số
     * không có nghĩa chip nào cũng tuân thủ đúng (đã có tiền lệ với "-bitrate_mode" ở
     * Compress, xem trên); (2) "duration"/"fps" đọc bằng MediaMetadataRetriever/
     * MediaExtractor (API GỐC ANDROID, KHÔNG PHẢI FFmpeg tự đọc) — CHƯA xác nhận 2 API
     * này đọc ĐÚNG file .m3u8 cục bộ hay không (khác hẳn cách FFmpeg tự đọc file này khi
     * thật sự convert) — nếu đọc sai/lỗi, 2 hàm đó đã có sẵn giá trị mặc định AN TOÀN
     * (duration→0.0 nghĩa là % tiến độ không hiện đúng nhưng KHÔNG treo app, fps→30.0
     * mặc định) — chỉ có thể làm GOP ép ra không đúng chính xác N giây như kỳ vọng, KHÔNG
     * làm hỏng cả tính năng; (3) input m3u8 có nhiều track audio/video hoặc các đoạn
     * .ts mã hoá không đồng nhất (đổi codec/độ phân giải giữa các đoạn — có thật trên 1
     * số nguồn HLS) có convert đúng không — chưa có input thật dạng này để thử.
     *
     * "useHardware" PHẢI được quyết định TRƯỚC ở tầng gọi bằng
     * `probeHardwareEncodeSupport()` (hàm CÓ SẴN, TÁI SỬ DỤNG nguyên — không viết hàm
     * probe riêng cho convert) — GIỐNG HỆT pattern đã dùng cho Compress
     * (`compressWithKnownBackend`), KHÔNG tự thử phần cứng trên NGUYÊN VIDEO DÀI rồi mới
     * biết fail để fallback — probe chỉ mất vài giây (thử trên đoạn 2 giây), trong khi
     * thử thẳng trên video dài rồi fail mới biết có thể phí vài phút cho MỖI lần convert
     * thất bại phần cứng.
     */
    suspend fun convertToMp4WithKnownBackend(
        inputPath: String,
        outputDir: String,
        sourceBitrateBps: Long,
        useHardware: Boolean,
        onProgress: (Int) -> Unit = {}
    ): VideoOpResult = withContext(Dispatchers.IO) {
        val outputPath = File(outputDir, "converted_${System.currentTimeMillis()}.mp4").absolutePath
        val durationSec = FileUtils.getVideoDurationSec(inputPath)
        val fps = FileUtils.getVideoFps(inputPath)
        val gopFrames = (fps * CONVERT_KEYFRAME_INTERVAL_SEC).toInt().coerceAtLeast(1)
        val forceKeyframesExpr = "expr:gte(t,n_forced*$CONVERT_KEYFRAME_INTERVAL_SEC)"

        // [THÊM 17/09/2026] "-fflags +genpts" (đặt TRƯỚC "-i", vì là cờ demuxer/đọc input,
        // không phải cờ encode) + "-avoid_negative_ts make_zero" (cờ output) — xử lý đúng
        // vấn đề THỨ 2, KHÁC với "GOP dài": file mp4 đã bị người dùng/công cụ khác (IDM,
        // hoặc bất kỳ tool nào tải HLS rồi tự ráp các đoạn .ts thành 1 file) RÁP THÔ —
        // không re-encode, chỉ nối/mux — nên có thể mang theo timestamp (PTS/DTS) không
        // liền mạch giữa các đoạn (mỗi đoạn .ts gốc vốn có timestamp nối tiếp đồng hồ
        // TUYỆT ĐỐI của stream gốc, không phải lúc nào công cụ ráp cũng reset về 0 đúng
        // cách) — dù input đã LÀ mp4 (không phải m3u8 nữa), lỗi này vẫn có thể còn NẰM
        // SẴN trong file, và encode lại theo GOP ngắn (phần phía trên) không tự sửa được
        // timestamp gốc nếu không có 2 cờ này. ĐÃ TRA CỨU (không đoán): "-avoid_negative_ts
        // make_zero" được nhiều nguồn độc lập xác nhận dùng đúng để sửa lỗi timestamp do
        // ráp/concat; "-fflags +genpts" dùng để tái tạo PTS cho stream có PTS thiếu/hỏng
        // (thường gặp ở nguồn ráp từ MPEG-TS/HLS). Áp dụng cho MỌI lần convert (không chỉ
        // khi phát hiện là m3u8) vì không hại gì cho input bình thường vốn đã có timestamp
        // đúng — 2 cờ này chỉ có tác dụng khi cần, im lặng bỏ qua nếu input đã sạch.
        // 🔴 CHƯA test thật với 1 file mp4 THẬT bị lỗi kiểu IDM — thử tái hiện bằng
        // "concat" demuxer trong phiên này KHÔNG lộ ra được lỗi rõ ràng (bản thân concat
        // demuxer của FFmpeg đã tự xử lý timestamp khá tốt, không đại diện đúng cho cách
        // IDM/các tool khác ráp file) — cơ sở của 2 cờ này là TÀI LIỆU/tiền lệ đã tra cứu,
        // KHÔNG phải thực nghiệm đã tự tái hiện và xác nhận sửa được trong phiên này.
        val cmd = if (useHardware) {
            val targetBitrateKbps = if (sourceBitrateBps > 0) (sourceBitrateBps / 1000).toInt().coerceAtLeast(500) else 3000
            "-y -fflags +genpts -i \"$inputPath\" " +
                "-c:v h264_mediacodec -bitrate_mode 2 -b:v ${targetBitrateKbps}k " +
                "-g $gopFrames -force_key_frames \"$forceKeyframesExpr\" " +
                "-avoid_negative_ts make_zero " +
                "-pix_fmt yuv420p -c:a aac -b:a 128k \"$outputPath\""
        } else {
            "-y -fflags +genpts -i \"$inputPath\" " +
                "-c:v libkvazaar -kvazaar-params qp=26,period=$gopFrames " +
                "-force_key_frames \"$forceKeyframesExpr\" " +
                "-avoid_negative_ts make_zero " +
                "-pix_fmt yuv420p -c:a aac -b:a 128k \"$outputPath\""
        }
        runFfmpegWithProgress(cmd, listOf(outputPath), durationSec, onProgress)
    }

    /** Cắt 1 đoạn video từ startSec tới endSec (giây), giữ nguyên định dạng gốc. */
    suspend fun trim(inputPath: String, outputDir: String, startSec: Double, endSec: Double, onProgress: (Int) -> Unit = {}): VideoOpResult =
        withContext(Dispatchers.IO) {
            val ext = File(inputPath).extension
            val outputPath = File(outputDir, "trim_${System.currentTimeMillis()}.$ext").absolutePath
            // QUAN TRỌNG: đặt "-ss" TRƯỚC "-i" (input seeking) thay vì sau "-i" (output
            // seeking) như trước. Với "-c copy", output seeking giữ nguyên mốc thời gian
            // gốc trong file (không reset về 0) -> khi phát, player phải "chờ" tới đúng mốc
            // thời gian gốc đó rồi mới hiển thị hình chuyển động, gây cảm giác video bị
            // đứng hình vài giây rồi mới chạy. Input seeking sẽ tự reset timestamp bắt đầu
            // về 0 nên phát mượt ngay từ khung hình đầu. "-avoid_negative_ts make_zero"
            // thêm 1 lớp an toàn cho các container dễ lệch timestamp (mp4/mov).
            val duration = endSec - startSec
            val cmd = "-y -ss $startSec -i \"$inputPath\" -t $duration -c copy -avoid_negative_ts make_zero \"$outputPath\""
            // FIX: trước đây dùng runFfmpeg() (chạy đồng bộ, KHÔNG có callback tiến độ) nên
            // progress bar trên UI chỉ đứng yên ở 0% suốt quá trình rồi biến mất khi xong —
            // tiến độ hiển thị là "giả", không phản ánh thật. Đổi sang runFfmpegWithProgress()
            // (đã có sẵn, dùng cho Compress) để progress bar chạy đúng theo % thời gian
            // ffmpeg đã xử lý thật.
            runFfmpegWithProgress(cmd, listOf(outputPath), duration, onProgress)
        }

    /**
     * Tách video thành nhiều đoạn theo danh sách mốc thời gian (giây) do người dùng nhập.
     * Ví dụ segments = [(0.0, 30.0), (30.0, 90.0)] -> tách thành 2 file.
     */
    suspend fun split(inputPath: String, outputDir: String, segments: List<Pair<Double, Double>>, onProgress: (Int) -> Unit = {}): VideoOpResult =
        withContext(Dispatchers.IO) {
            val ext = File(inputPath).extension
            val outputs = mutableListOf<String>()
            val logs = StringBuilder()
            for ((index, seg) in segments.withIndex()) {
                val outputPath = File(outputDir, "split_${index + 1}_${System.currentTimeMillis()}.$ext").absolutePath
                // Input seeking (-ss trước -i) + reset timestamp -> tránh lỗi đứng hình vài
                // giây đầu khi phát file đã tách (xem giải thích chi tiết ở hàm trim()).
                val segDuration = seg.second - seg.first
                val cmd = "-y -ss ${seg.first} -i \"$inputPath\" -t $segDuration -c copy -avoid_negative_ts make_zero \"$outputPath\""
                // Tiến độ tổng = (số đoạn đã xong + % đoạn hiện tại) / tổng số đoạn — để
                // progress bar chạy thật thay vì đứng yên (xem giải thích ở hàm trim()).
                val session = runFfmpegWithProgress(cmd, listOf(outputPath), segDuration) { segPercent ->
                    val overall = ((index * 100 + segPercent).toDouble() / segments.size).toInt()
                    onProgress(overall.coerceIn(0, 100))
                }
                logs.appendLine("Đoạn ${index + 1}: ${if (session.success) "OK" else "Lỗi"}")
                if (session.success) {
                    outputs.add(outputPath)
                } else {
                    return@withContext VideoOpResult(false, outputs, logs.toString())
                }
            }
            VideoOpResult(true, outputs, logs.toString())
        }

    /**
     * Ghép nhiều video thành 1. Yêu cầu các video đầu vào có cùng codec/độ phân giải
     * để dùng được stream copy (nhanh, không mất chất lượng) — đây là giới hạn tự nhiên
     * của FFmpeg concat demuxer, không phải hạn chế riêng của app.
     */
    suspend fun merge(inputPaths: List<String>, outputDir: String, onProgress: (Int) -> Unit = {}): VideoOpResult = withContext(Dispatchers.IO) {
        if (inputPaths.isEmpty()) return@withContext VideoOpResult(false, log = "Chưa chọn video nào để ghép")

        val ext = File(inputPaths.first()).extension
        val listFile = File(outputDir, "concat_list_${System.currentTimeMillis()}.txt")
        listFile.writeText(inputPaths.joinToString("\n") { "file '${it.replace("'", "'\\''")}'" })

        val totalDurationSec = inputPaths.sumOf { FileUtils.getVideoDurationSec(it) }
        val outputPath = File(outputDir, "merged_${System.currentTimeMillis()}.$ext").absolutePath
        val cmd = "-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"$outputPath\""
        val result = runFfmpegWithProgress(cmd, listOf(outputPath), totalDurationSec, onProgress)
        listFile.delete()
        result
    }

    /** Tách âm thanh toàn bộ video, giữ nguyên codec audio gốc. */
    suspend fun extractAudio(inputPath: String, outputDir: String, onProgress: (Int) -> Unit = {}): VideoOpResult = withContext(Dispatchers.IO) {
        val outputPath = File(outputDir, "audio_${System.currentTimeMillis()}.m4a").absolutePath
        val totalDurationSec = FileUtils.getVideoDurationSec(inputPath)
        val cmd = "-y -i \"$inputPath\" -vn -acodec copy \"$outputPath\""
        runFfmpegWithProgress(cmd, listOf(outputPath), totalDurationSec, onProgress)
    }

    /** Tách âm thanh CHỈ trong 1 đoạn thời gian cụ thể, thay vì toàn bộ video. */
    suspend fun extractAudioSegment(inputPath: String, outputDir: String, startSec: Double, endSec: Double, onProgress: (Int) -> Unit = {}): VideoOpResult =
        withContext(Dispatchers.IO) {
            val outputPath = File(outputDir, "audio_${System.currentTimeMillis()}.m4a").absolutePath
            val duration = endSec - startSec
            val cmd = "-y -ss $startSec -i \"$inputPath\" -t $duration -vn -acodec copy -avoid_negative_ts make_zero \"$outputPath\""
            runFfmpegWithProgress(cmd, listOf(outputPath), duration, onProgress)
        }

    /** Tách âm thanh theo NHIỀU đoạn cùng lúc, ra nhiều file riêng — sửa lỗi trước đây
     *  chỉ lấy đúng đoạn đầu tiên dù người dùng nhập nhiều đoạn. */
    suspend fun extractAudioMultipleSegments(inputPath: String, outputDir: String, segments: List<Pair<Double, Double>>, onProgress: (Int) -> Unit = {}): VideoOpResult =
        withContext(Dispatchers.IO) {
            val outputs = mutableListOf<String>()
            for ((index, seg) in segments.withIndex()) {
                val outputPath = File(outputDir, "audio_${index + 1}_${System.currentTimeMillis()}.m4a").absolutePath
                val segDuration = seg.second - seg.first
                val cmd = "-y -ss ${seg.first} -i \"$inputPath\" -t $segDuration -vn -acodec copy -avoid_negative_ts make_zero \"$outputPath\""
                val r = runFfmpegWithProgress(cmd, listOf(outputPath), segDuration) { segPercent ->
                    val overall = ((index * 100 + segPercent).toDouble() / segments.size).toInt()
                    onProgress(overall.coerceIn(0, 100))
                }
                if (!r.success) return@withContext VideoOpResult(false, outputs, "Đoạn ${index + 1} thất bại: ${r.log}")
                outputs.add(outputPath)
            }
            VideoOpResult(true, outputs)
        }

    /** Mức nén theo cấp độ dễ hiểu, ánh xạ sang cả QP (đường phần mềm) lẫn tỉ lệ bitrate
     *  (đường phần cứng) — người dùng không cần biết khái niệm QP/bitrate là gì. */
    enum class CompressPreset(val qp: Int, val bitrateMultiplier: Double) {
        NHE(32, 0.35),   // Nhẹ nhất, nén nhiều nhất
        VUA(26, 0.6),    // Cân bằng
        NET(20, 1.0)     // Ít nén nhất, giữ nét nhất
    }

    /**
     * Nén video — ƯU TIÊN dùng bộ mã hoá PHẦN CỨNG của máy (qua Android MediaCodec,
     * chip xử lý video chuyên dụng) thay vì phần mềm chạy CPU thuần. Lợi ích: nhanh
     * hơn nhiều, KHÔNG làm nóng máy hay treo giữa chừng như khi ép CPU chạy liên tục.
     *
     * Vì bộ mã hoá phần cứng trên hầu hết điện thoại (kể cả Snapdragon 888) KHÔNG hỗ
     * trợ chế độ "chất lượng cố định" (CQ) kiểu CRF/QP — chỉ nhận bitrate mục tiêu —
     * nên khi dùng đường phần cứng, mình quy đổi mức nén (Nhẹ/Vừa/Nét) sang bitrate
     * tương ứng dựa trên bitrate gốc của chính video đó.
     *
     * AN TOÀN: nếu máy/bản FFmpeg này không hỗ trợ mã hoá phần cứng (tuỳ dòng máy,
     * tuỳ chip), lệnh sẽ thất bại và app TỰ ĐỘNG chuyển sang đường phần mềm
     * (libkvazaar + QP) để đảm bảo luôn ra được kết quả, dù chậm hơn.
     */
    /**
     * Dò nhanh xem máy có hỗ trợ mã hoá phần cứng không, bằng cách thử trên 1 đoạn
     * NGẮN (2 giây) thay vì cả video dài — để biết kết quả trong vài giây, không phải
     * đợi hết cả video rồi mới biết thất bại (đúng vấn đề người dùng phản ánh).
     */
    suspend fun probeHardwareEncodeSupport(inputPath: String, cacheDir: File): Boolean = withContext(Dispatchers.IO) {
        val probeDir = File(cacheDir, "hw_probe_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val probeClip = File(probeDir, "probe.mp4").absolutePath
            val trimResult = runFfmpeg("-y -i \"$inputPath\" -ss 0 -t 2 -c copy \"$probeClip\"", listOf(probeClip))
            if (!trimResult.success) return@withContext false

            val probeOutput = File(probeDir, "probe_out.mp4").absolutePath
            // FIX GỐC RỄ (08/07/2026): đổi bitrate_mode từ 1 (VBR) sang 2 (CBR).
            // VBR (Variable Bitrate) CHO PHÉP vượt bitrate mục tiêu khi cảnh quay phức
            // tạp (nhiều chuyển động, chi tiết) — đây rất có thể là nguyên nhân THẬT của
            // hiện tượng "nén phình to hơn gốc" đã gặp nhiều lần, không phải do chip yếu
            // hay driver lỗi. CBR (Constant Bitrate) ép cứng bitrate đều suốt video, đúng
            // mục tiêu "không phình dung lượng" cần có — đánh đổi: chất lượng có thể kém
            // hơn 1 chút ở cảnh phức tạp (bù bằng cảnh đơn giản), nhưng dung lượng đoán
            // trước được, đúng cách chip video engine được thiết kế để dùng cho việc này.
            val hwTest = runFfmpeg(
                "-y -i \"$probeClip\" -c:v h264_mediacodec -bitrate_mode 2 -b:v 1000k -c:a copy \"$probeOutput\"",
                listOf(probeOutput)
            )
            hwTest.success
        } finally {
            probeDir.deleteRecursively()
        }
    }

    /** Chạy nén với phần cứng/phần mềm ĐÃ ĐƯỢC XÁC ĐỊNH TRƯỚC (từ probeHardwareEncodeSupport),
     *  không thử lại từ đầu, tránh lãng phí thời gian chạy 2 lần trên video dài. */
    /**
     * Nén video kèm LƯỚI KIỂM TRA CUỐI CÙNG: sau khi nén xong, so sánh dung lượng
     * output thật với input thật. Nếu output vẫn to hơn/gần bằng input dù đã có các
     * lưới an toàn khác (chặn bitrate mục tiêu, giới hạn maxrate/bufsize) — nghĩa là
     * bộ mã hoá phần cứng của máy này không tuân thủ đúng các tham số mình đặt ra
     * (hiện tượng đã xác nhận qua thực tế, không phải suy đoán) — TỰ ĐỘNG làm lại
     * bằng đường phần mềm (libkvazaar QP, đã có bằng chứng log thật cho ra file nhỏ
     * hơn đúng cách) thay vì trả về 1 kết quả tệ hơn cả không nén.
     */
    suspend fun compressWithKnownBackend(
        inputPath: String,
        outputDir: String,
        preset: CompressPreset,
        useHardware: Boolean,
        onProgress: (Int) -> Unit = {}
    ): VideoOpResult = withContext(Dispatchers.IO) {
        val originalSize = File(inputPath).length()

        val firstAttempt = compressInternal(inputPath, outputDir, preset, useHardware, onProgress)
        if (!firstAttempt.success) return@withContext firstAttempt

        val resultPath = firstAttempt.outputPaths.firstOrNull()
        val resultSize = resultPath?.let { File(it).length() } ?: Long.MAX_VALUE

        // Chấp nhận nếu nhỏ hơn gốc ít nhất 5% (chừa biên sai số đo đạc) — nếu không,
        // coi là thất bại thực chất dù FFmpeg báo "thành công".
        val genuinelyShrunk = resultSize < originalSize * 0.95

        if (genuinelyShrunk || !useHardware) {
            // Đã dùng phần mềm mà vẫn không nhỏ hơn thì cũng không còn đường nào khác
            // tốt hơn để tự động thử lại — trả về kết quả kèm cảnh báo rõ ràng.
            return@withContext if (genuinelyShrunk) firstAttempt else firstAttempt.copy(
                log = "${firstAttempt.log}\n\nCẢNH BÁO: dung lượng sau nén (${resultSize} bytes) không nhỏ hơn đáng kể so với gốc (${originalSize} bytes)."
            )
        }

        // Phần cứng cho kết quả không thật sự nhỏ hơn -> xoá bản lỗi, tự làm lại bằng phần mềm
        resultPath?.let { File(it).delete() }
        val softwareRetry = compressInternal(inputPath, outputDir, preset, useHardware = false, onProgress)
        return@withContext softwareRetry.copy(
            log = "Phần cứng cho ra file không nhỏ hơn gốc (bất thường) — đã tự động chuyển sang PHẦN MỀM.\n${softwareRetry.log}"
        )
    }

    private suspend fun compressInternal(
        inputPath: String,
        outputDir: String,
        preset: CompressPreset,
        useHardware: Boolean,
        onProgress: (Int) -> Unit
    ): VideoOpResult = withContext(Dispatchers.IO) {
        val ext = File(inputPath).extension
        val outputPath = File(outputDir, "compressed_${System.currentTimeMillis()}.$ext").absolutePath
        val durationSec = FileUtils.getVideoDurationSec(inputPath)
        val originalFps = FileUtils.getVideoFps(inputPath)

        if (useHardware) {
            // Dùng bitrate tính từ dung lượng file thật / thời lượng — LUÔN đúng, không
            // phụ thuộc metadata có thể sai (nguyên nhân gây lỗi "nén ra nặng hơn gốc").
            val actualOriginalBitrate = FileUtils.calculateActualBitrateBps(inputPath)
            var targetBitrateKbps = if (actualOriginalBitrate > 0) {
                ((actualOriginalBitrate / 1000.0) * preset.bitrateMultiplier).toInt().coerceAtLeast(200)
            } else 2000

            // Lưới an toàn: dù tính sai kiểu gì, TUYỆT ĐỐI không đặt mục tiêu cao hơn
            // bitrate gốc thật — nén mà ra nặng hơn là vô lý, phải chặn cứng ở đây.
            if (actualOriginalBitrate > 0) {
                targetBitrateKbps = targetBitrateKbps.coerceAtMost((actualOriginalBitrate / 1000).toInt())
            }

            // -maxrate/-bufsize: giữ lại làm lớp chặn trần bổ sung dù đã chuyển sang CBR
            // (một số chip vẫn có thể vượt nhẹ dù ở chế độ CBR, đây là lớp phòng hờ thêm).
            val maxrateKbps = (targetBitrateKbps * 1.5).toInt()
            val bufsizeKbps = targetBitrateKbps * 2

            // -r + -vsync cfr: ép khung hình/giây đầu ra đúng bằng khung hình/giây gốc,
            // tránh lỗi "video chạy nhanh hơn" khi nguồn có tốc độ khung hình không đều
            // (VFR) mà bộ mã hoá phần cứng xử lý sai thành hằng số khác gốc.
            //
            // FIX GỐC RỄ (08/07/2026): đổi bitrate_mode từ 1 (VBR) sang 2 (CBR). VBR
            // (Variable Bitrate) CHO PHÉP bộ mã hoá vượt bitrate mục tiêu khi cảnh quay
            // phức tạp (nhiều chuyển động/chi tiết) để giữ chất lượng — đây rất có thể là
            // NGUYÊN NHÂN THẬT của hiện tượng "nén phình to hơn gốc" đã gặp nhiều lần,
            // KHÔNG PHẢI do chip yếu hay driver lỗi như từng nghi ngờ. CBR (Constant
            // Bitrate) ép cứng bitrate đều suốt video — đúng mục tiêu "không phình dung
            // lượng", đánh đổi chất lượng có thể giảm nhẹ ở cảnh phức tạp (bù lại bằng
            // cảnh đơn giản) để đổi lấy dung lượng đoán trước được — đúng cách chip video
            // engine được thiết kế để vận hành cho mục đích nén ổn định.
            val cmd = "-y -i \"$inputPath\" -c:v h264_mediacodec -bitrate_mode 2 " +
                    "-b:v ${targetBitrateKbps}k -maxrate ${maxrateKbps}k -bufsize ${bufsizeKbps}k " +
                    "-r $originalFps -vsync cfr -pix_fmt yuv420p -c:a copy \"$outputPath\""

            val hwResult = runFfmpegWithProgress(cmd, listOf(outputPath), durationSec, onProgress)

            // TÍNH NĂNG MỚI: nhúng thông tin SO SÁNH bitrate mục tiêu vs bitrate thật đạt
            // được vào log trả về (VideoEngine không có Context để tự ghi DebugLog — log
            // này sẽ tiếp tục chảy lên CompressService, nơi CÓ Context, để ghi/lưu lại).
            // Đây là bằng chứng CỤ THỂ để biết CBR có thực sự khắc phục được vấn đề
            // "phình dung lượng" hay không, thay vì chỉ đoán qua dung lượng file cuối.
            val diagnosticLine = if (hwResult.success && hwResult.outputPaths.isNotEmpty()) {
                try {
                    val actualOutputBitrateBps = FileUtils.calculateActualBitrateBps(hwResult.outputPaths.first())
                    val ratio = if (targetBitrateKbps > 0) (actualOutputBitrateBps / 1000.0 / targetBitrateKbps) else -1.0
                    "[CHẨN ĐOÁN CBR] target=${targetBitrateKbps}kbps, thật đạt được=${(actualOutputBitrateBps / 1000)}kbps, " +
                    "tỉ lệ=${"%.2f".format(java.util.Locale.US, ratio)}x " +
                    (if (ratio > 1.1) "— VƯỢT MỤC TIÊU ĐÁNG KỂ, CBR CHƯA GIẢI QUYẾT HẾT" else "— ĐẠT MỤC TIÊU TỐT")
                } catch (e: Exception) {
                    "[CHẨN ĐOÁN CBR] không tính được bitrate thật: ${e.message}"
                }
            } else null

            if (diagnosticLine != null) hwResult.copy(log = "${hwResult.log}\n$diagnosticLine") else hwResult
        } else {
            // FIX: nhánh phần mềm trước đây THIẾU "-pix_fmt yuv420p" (nhánh phần cứng bên
            // trên đã có). libkvazaar (HEVC) có thể từ chối mã hoá thẳng nếu định dạng màu
            // gốc không phải yuv420p chuẩn (vd nv12, yuvj420p — khá phổ biến ở video quay
            // bằng điện thoại) và BÁO LỖI THẲNG (không nén được gì) thay vì tự chuyển đổi.
            // Đây là một khả năng gây ra "nén thất bại hẳn" khi máy phải rơi về đường phần
            // mềm (vd sau khi phần cứng bị lưới an toàn phát hiện cho ra file nặng hơn 3 lần).
            val cmd = "-y -i \"$inputPath\" -c:v libkvazaar -kvazaar-params qp=${preset.qp} " +
                    "-pix_fmt yuv420p -r $originalFps -vsync cfr -c:a copy \"$outputPath\""
            runFfmpegWithProgress(cmd, listOf(outputPath), durationSec, onProgress)
        }
    }

    /** Mức nén theo cấp độ dễ hiểu — định nghĩa đặt phía dưới, dùng chung cho các hàm trên. */

    /** Tách toàn bộ frame của video ra ảnh PNG (dùng cho pipeline upscale frame-by-frame). */
    suspend fun extractFrames(inputPath: String, framesDir: File): VideoOpResult = withContext(Dispatchers.IO) {
        framesDir.mkdirs()
        val pattern = File(framesDir, "frame_%06d.png").absolutePath
        val cmd = "-y -i \"$inputPath\" -vsync 0 \"$pattern\""
        runFfmpeg(cmd, listOf(framesDir.absolutePath))
    }

    /**
     * Dựng lại video từ thư mục frame đã xử lý (vd đã upscale), ghép lại audio gốc.
     * Container output giữ theo đuôi file gốc; codec hình ảnh dùng H.264 vì đây là
     * bước encode lại bắt buộc (frame đã thay đổi nội dung, không thể stream-copy).
     */
    suspend fun reassembleFromFrames(
        processedFramesDir: File,
        fps: Double,
        originalInputPath: String,
        outputDir: String
    ): VideoOpResult = withContext(Dispatchers.IO) {
        val ext = File(originalInputPath).extension
        val outputPath = File(outputDir, "upscaled_${System.currentTimeMillis()}.$ext").absolutePath
        val pattern = File(processedFramesDir, "frame_%06d.png").absolutePath
        val cmd = "-y -framerate $fps -i \"$pattern\" -i \"$originalInputPath\" " +
                "-map 0:v -map 1:a? -c:v libkvazaar -kvazaar-params qp=26 -c:a copy \"$outputPath\""
        runFfmpeg(cmd, listOf(outputPath))
    }

    /** Tách frame CHỈ trong 1 khoảng thời gian (chunk), không phải toàn bộ video. */
    suspend fun extractFrameChunk(inputPath: String, framesDir: File, startSec: Double, durationSec: Double): VideoOpResult =
        withContext(Dispatchers.IO) {
            framesDir.mkdirs()
            val pattern = File(framesDir, "frame_%06d.png").absolutePath
            val cmd = "-y -ss $startSec -t $durationSec -i \"$inputPath\" -vsync 0 \"$pattern\""
            runFfmpeg(cmd, listOf(framesDir.absolutePath))
        }

    /** Dựng video CHỈ PHẦN HÌNH ẢNH (không audio) từ 1 chunk frame đã xử lý, dùng để ghép lại sau. */
    /** Dựng chunk video sau upscale — ưu tiên mã hoá PHẦN CỨNG (nhanh, mát máy),
     *  tự động rớt về phần mềm (libkvazaar QP) nếu thiết bị không hỗ trợ. Đặc biệt
     *  quan trọng cho Upscale vì phải lặp lại rất nhiều lần (mỗi chunk 1 lần encode). */
    suspend fun reassembleChunkVideoOnly(processedFramesDir: File, fps: Double, outputPath: String, qp: Int = 26, bitrateKbps: Int = 4000): VideoOpResult =
        withContext(Dispatchers.IO) {
            val pattern = File(processedFramesDir, "frame_%06d.png").absolutePath

            // Áp dụng cùng fix CBR (xem giải thích chi tiết ở compressInternal()) — nhất
            // quán bitrate_mode giữa mọi đường dùng h264_mediacodec trong toàn bộ app.
            val hwCmd = "-y -framerate $fps -i \"$pattern\" -c:v h264_mediacodec -bitrate_mode 2 -b:v ${bitrateKbps}k -an \"$outputPath\""
            val hwResult = runFfmpeg(hwCmd, listOf(outputPath))
            if (hwResult.success) return@withContext hwResult

            val safeQp = qp.coerceIn(0, 51)
            val swCmd = "-y -framerate $fps -i \"$pattern\" -c:v libkvazaar -kvazaar-params qp=$safeQp -pix_fmt yuv420p -an \"$outputPath\""
            runFfmpeg(swCmd, listOf(outputPath))
        }

    /** Ghép các chunk video (đã cùng codec/thông số) lại thành 1 video hình ảnh liền mạch. */
    suspend fun concatVideoOnlyChunks(chunkPaths: List<String>, outputPath: String): VideoOpResult =
        withContext(Dispatchers.IO) {
            val listFile = File(File(outputPath).parent, "concat_chunks_${System.currentTimeMillis()}.txt")
            listFile.writeText(chunkPaths.joinToString("\n") { "file '${it.replace("'", "'\\''")}'" })
            val cmd = "-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"$outputPath\""
            val result = runFfmpeg(cmd, listOf(outputPath))
            listFile.delete()
            result
        }

    /** Ghép audio gốc vào video hình ảnh đã xử lý xong (bước cuối cùng của pipeline upscale). */
    suspend fun muxOriginalAudio(videoOnlyPath: String, originalInputPath: String, outputDir: String): VideoOpResult =
        withContext(Dispatchers.IO) {
            val ext = File(originalInputPath).extension
            val outputPath = File(outputDir, "upscaled_${System.currentTimeMillis()}.$ext").absolutePath
            val cmd = "-y -i \"$videoOnlyPath\" -i \"$originalInputPath\" " +
                    "-map 0:v -map 1:a? -c:v copy -c:a copy -shortest \"$outputPath\""
            runFfmpeg(cmd, listOf(outputPath))
        }

    // FIX/TÍNH NĂNG MỚI: lưu lại session FFmpeg đang chạy để có thể huỷ THẬT SỰ theo yêu
    // cầu người dùng (trước đây `session.cancel()` chỉ được gọi tự động khi coroutine bị
    // huỷ ngang — không có cách nào để người dùng CHỦ ĐỘNG bấm "Huỷ" giữa chừng). Dùng
    // @Volatile vì Activity (đọc) và Service (ghi) tuy khác thread nhưng CÙNG 1 tiến
    // trình (process) — object Kotlin này được chia sẻ trực tiếp, không cần IPC.
    @Volatile private var currentSessionId: Long? = null

    /** Huỷ tác vụ FFmpeg đang chạy (nếu có). Trả về true nếu có tác vụ để huỷ. */
    fun cancelCurrentSession(): Boolean {
        val id = currentSessionId ?: return false
        com.arthenica.ffmpegkit.FFmpegKit.cancel(id)
        return true
    }

    /**
     * Chạy FFmpeg bất đồng bộ, báo tiến độ (%) theo thời gian đã xử lý so với tổng
     * thời lượng video — để UI hiện thanh tiến độ thật thay vì chỉ quay vòng vô định.
     */
    private suspend fun runFfmpegWithProgress(
        command: String,
        expectedOutputs: List<String>,
        totalDurationSec: Double,
        onProgress: (Int) -> Unit
    ): VideoOpResult = kotlinx.coroutines.suspendCancellableCoroutine { cont ->
        val session = com.arthenica.ffmpegkit.FFmpegKit.executeAsync(
            command,
            { session ->
                currentSessionId = null
                val result = if (ReturnCode.isSuccess(session.returnCode)) {
                    VideoOpResult(true, expectedOutputs, session.allLogsAsString ?: "")
                } else if (ReturnCode.isCancel(session.returnCode)) {
                    VideoOpResult(false, emptyList(), "Đã huỷ theo yêu cầu người dùng.")
                } else {
                    VideoOpResult(false, emptyList(), session.allLogsAsString ?: "FFmpeg thất bại, mã lỗi: ${session.returnCode}")
                }
                if (cont.isActive) cont.resumeWith(Result.success(result))
            },
            { /* log callback, không cần xử lý */ },
            { stats ->
                if (totalDurationSec > 0) {
                    val processedSec = stats.time / 1000.0
                    val percent = ((processedSec / totalDurationSec) * 100).toInt().coerceIn(0, 100)
                    onProgress(percent)
                }
            }
        )
        currentSessionId = session.sessionId
        cont.invokeOnCancellation { session.cancel() }
    }

    /**
     * Xoá 1 đoạn ở giữa video [removeStart, removeEnd], ghép 2 phần còn lại
     * (đầu video + cuối video) thành 1 file liền mạch.
     */
    suspend fun removeSegmentAndJoin(inputPath: String, outputDir: String, removeStart: Double, removeEnd: Double, totalDurationSec: Double, onProgress: (Int) -> Unit = {}): VideoOpResult =
        withContext(Dispatchers.IO) {
            val ext = File(inputPath).extension
            val tempDir = File(outputDir, "remove_temp_${System.currentTimeMillis()}").apply { mkdirs() }

            // 3 bước có thể chạy: cắt phần A, cắt phần B, ghép lại — dùng để chia đều
            // thanh tiến độ tổng cho thật thay vì đứng yên (xem giải thích ở hàm trim()).
            val hasPartA = removeStart > 0.1
            val hasPartB = removeEnd < totalDurationSec - 0.1
            val totalSteps = (if (hasPartA) 1 else 0) + (if (hasPartB) 1 else 0) + 1 // +1 cho bước ghép
            var stepsDone = 0
            fun stepProgress(stepPercent: Int) {
                val overall = ((stepsDone * 100 + stepPercent).toDouble() / totalSteps).toInt()
                onProgress(overall.coerceIn(0, 100))
            }

            val results = mutableListOf<String>()
            if (hasPartA) {
                val partA = File(tempDir, "part_a.$ext").absolutePath
                val r = runFfmpegWithProgress("-y -ss 0 -i \"$inputPath\" -t $removeStart -c copy -avoid_negative_ts make_zero \"$partA\"", listOf(partA), removeStart, ::stepProgress)
                if (!r.success) { tempDir.deleteRecursively(); return@withContext r }
                results.add(partA)
                stepsDone++
            }
            if (hasPartB) {
                val partB = File(tempDir, "part_b.$ext").absolutePath
                val partBDuration = totalDurationSec - removeEnd
                val r = runFfmpegWithProgress("-y -ss $removeEnd -i \"$inputPath\" -t $partBDuration -c copy -avoid_negative_ts make_zero \"$partB\"", listOf(partB), partBDuration, ::stepProgress)
                if (!r.success) { tempDir.deleteRecursively(); return@withContext r }
                results.add(partB)
                stepsDone++
            }

            if (results.isEmpty()) {
                tempDir.deleteRecursively()
                return@withContext VideoOpResult(false, log = "Đoạn xoá trùng toàn bộ video, không còn gì để ghép")
            }
            if (results.size == 1) {
                // Chỉ còn 1 phần -> copy thẳng ra làm kết quả, không cần ghép
                val finalPath = File(outputDir, "removed_segment_${System.currentTimeMillis()}.$ext").absolutePath
                File(results[0]).copyTo(File(finalPath), overwrite = true)
                tempDir.deleteRecursively()
                onProgress(100)
                return@withContext VideoOpResult(true, listOf(finalPath))
            }

            val mergeResult = merge(results, outputDir, ::stepProgress)
            tempDir.deleteRecursively()
            mergeResult
        }

    private fun runFfmpeg(command: String, expectedOutputs: List<String>): VideoOpResult {
        val session = FFmpegKit.execute(command)
        return if (ReturnCode.isSuccess(session.returnCode)) {
            VideoOpResult(true, expectedOutputs, session.allLogsAsString ?: "")
        } else {
            VideoOpResult(false, emptyList(), session.allLogsAsString ?: "FFmpeg thất bại, mã lỗi: ${session.returnCode}")
        }
    }
}
