package com.videoaistudio.app.ui

import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.videoaistudio.app.databinding.ActivityModelSettingsBinding
import com.videoaistudio.app.inference.HardwareTarget
import com.videoaistudio.app.inference.InferenceManager
import com.videoaistudio.app.inference.LocalModelProvider
import com.videoaistudio.app.inference.ModelConfig
import com.videoaistudio.app.inference.ProviderSource
import com.videoaistudio.app.inference.TaskType
import com.videoaistudio.app.video.FileUtils
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Đây là màn hình hiện thực hoá yêu cầu "không hardcode model/API":
 * người dùng tự chọn tác vụ, tự chọn nguồn (local file hay API),
 * tự nhập đường dẫn/endpoint/key. App không gắn cứng bất kỳ giá trị nào.
 *
 * Luồng "Kiểm tra model" hiện thực đúng yêu cầu: thử lớp nâng cao (NPU_QNN_FORCED)
 * trước -> nếu fail, hỏi người dùng có muốn fallback về lớp nền (GPU_NPU_AUTO) không,
 * kèm báo cáo % phép tính chạy GPU/NPU vs CPU để người dùng tự quyết định.
 */
class ModelSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityModelSettingsBinding
    private lateinit var inferenceManager: InferenceManager

    private val pickModelFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { importModelFile(it) }
    }

    private val pickLabelsFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { importLabelsFile(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityModelSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inferenceManager = InferenceManager(applicationContext)

        binding.spinnerTaskType.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, TaskType.values()
        )
        binding.spinnerSource.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, ProviderSource.values()
        )
        binding.spinnerHardware.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, HardwareTarget.values()
        )

        binding.btnPickModelFile.setOnClickListener {
            pickModelFile.launch(arrayOf("*/*"))
        }
        binding.btnPickLabelsFile.setOnClickListener {
            pickLabelsFile.launch(arrayOf("text/plain", "*/*"))
        }
        binding.btnSaveConfig.setOnClickListener { saveConfig() }
        binding.btnTestModel.setOnClickListener { testCurrentModel() }

        refreshSavedList()
    }

    private var pickedModelDisplayName: String? = null

    private fun importLabelsFile(uri: Uri) {
        try {
            val name = FileUtils.queryDisplayName(this, uri)
            val file = FileUtils.copyUriToPermanentStorage(this, uri, "labels", name)
            val lineCount = file.readLines().filter { it.isNotBlank() }.size
            binding.edtLabelsPath.setText("$name ($lineCount nhãn)")
            binding.edtLabelsPath.tag = file.absolutePath
        } catch (e: Exception) {
            Toast.makeText(this, "Không đọc được file labels: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importModelFile(uri: Uri) {
        try {
            val name = FileUtils.queryDisplayName(this, uri)
            if (!name.endsWith(".onnx", ignoreCase = true)) {
                Toast.makeText(this, "Cảnh báo: file không có đuôi .onnx — app chỉ chạy được model định dạng ONNX.", Toast.LENGTH_LONG).show()
            }
            // Giữ quyền truy cập lâu dài tới URI này (không copy file ra đĩa, tránh
            // chiếm gấp đôi dung lượng máy). LocalModelProvider sẽ đọc thẳng nội dung
            // vào RAM mỗi lần cần chạy, dùng xong giải phóng ngay.
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            pickedModelDisplayName = name
            binding.edtLocalPath.setText("$name  (đã cấp quyền đọc, không copy file)")
            binding.edtLocalPath.tag = uri.toString()
        } catch (e: Exception) {
            Toast.makeText(this, "Không đọc được file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun buildConfigFromForm(hardwareOverride: HardwareTarget? = null): ModelConfig {
        val taskType = binding.spinnerTaskType.selectedItem as TaskType
        val source = binding.spinnerSource.selectedItem as ProviderSource
        val hardware = hardwareOverride ?: (binding.spinnerHardware.selectedItem as HardwareTarget)
        val name = binding.edtDisplayName.text.toString().ifBlank { taskType.name }

        return ModelConfig(
            id = UUID.randomUUID().toString(),
            displayName = name,
            taskType = taskType,
            source = source,
            hardwareTarget = hardware,
            localFilePath = binding.edtLocalPath.tag as? String, // content:// URI, không phải path ổ đĩa
            apiEndpoint = binding.edtApiEndpoint.text.toString().ifBlank { null },
            apiKey = binding.edtApiKey.text.toString().ifBlank { null },
            labelsFilePath = binding.edtLabelsPath.tag as? String
        )
    }

    private fun saveConfig() {
        val config = buildConfigFromForm()

        if (config.source == ProviderSource.LOCAL_MODEL && config.localFilePath == null) {
            Toast.makeText(this, "Vui lòng nhập đường dẫn file model local", Toast.LENGTH_SHORT).show()
            return
        }
        if (config.source == ProviderSource.REMOTE_API && config.apiEndpoint == null) {
            Toast.makeText(this, "Vui lòng nhập API endpoint", Toast.LENGTH_SHORT).show()
            return
        }

        inferenceManager.saveConfig(config)
        Toast.makeText(this, "Đã lưu cấu hình cho ${config.taskType.name}", Toast.LENGTH_SHORT).show()
        refreshSavedList()
    }

    /**
     * Thử nạp model theo đúng lựa chọn phần cứng hiện tại trên form.
     * Nếu người dùng đang chọn lớp nâng cao (NPU_QNN_FORCED) và nó fail,
     * hỏi có muốn fallback về lớp nền (GPU_NPU_AUTO) kèm báo cáo % accelerator/CPU.
     */
    private fun testCurrentModel() {
        val config = buildConfigFromForm()

        if (config.source != ProviderSource.LOCAL_MODEL || config.localFilePath == null) {
            Toast.makeText(this, "Chức năng kiểm tra hiện chỉ áp dụng cho model local đã nhập đường dẫn", Toast.LENGTH_LONG).show()
            return
        }

        lifecycleScope.launch {
            val provider = LocalModelProvider(applicationContext, config)
            val report = provider.checkCompatibility()
            provider.release()

            if (report.loadSucceeded) {
                showResultDialog(config.hardwareTarget.name, report.message, null)
            } else if (config.hardwareTarget == HardwareTarget.NPU_QNN_FORCED) {
                // Đúng luồng yêu cầu: lớp nâng cao fail -> hỏi có muốn fallback lớp nền không
                offerFallbackToBaseLayer(config, report.message)
            } else {
                showResultDialog(config.hardwareTarget.name, report.message, null)
            }
        }
    }

    private fun offerFallbackToBaseLayer(config: ModelConfig, failMessage: String) {
        AlertDialog.Builder(this)
            .setTitle("Lớp nâng cao (NPU ép buộc) không chạy được")
            .setMessage("$failMessage\n\nBạn có muốn thử chạy ở lớp nền (GPU/NPU tự động, phần không hỗ trợ sẽ rớt CPU) không?")
            .setPositiveButton("Thử lớp nền") { _, _ ->
                lifecycleScope.launch {
                    val fallbackConfig = config.copy(hardwareTarget = HardwareTarget.GPU_NPU_AUTO)
                    val provider = LocalModelProvider(applicationContext, fallbackConfig)
                    val report = provider.checkCompatibility()
                    provider.release()
                    showResultDialog(
                        "Lớp nền (fallback)",
                        report.message,
                        "Bạn có thể chấp nhận hiệu suất này, hoặc tìm model khác đã được quantize đúng chuẩn QNN để dùng lớp nâng cao."
                    )
                }
            }
            .setNegativeButton("Huỷ, tôi sẽ tìm model khác", null)
            .show()
    }

    private fun showResultDialog(hardwareLabel: String, message: String, extraNote: String?) {
        val fullMessage = if (extraNote != null) "$message\n\n$extraNote" else message
        AlertDialog.Builder(this)
            .setTitle("Kết quả kiểm tra ($hardwareLabel)")
            .setMessage(fullMessage)
            .setPositiveButton("Đóng", null)
            .show()
    }

    private fun refreshSavedList() {
        val configs = inferenceManager.getAllConfigs()
        val text = if (configs.isEmpty()) {
            "Chưa có model nào được cấu hình."
        } else {
            configs.joinToString("\n\n") {
                "• ${it.displayName}\n  Tác vụ: ${it.taskType}\n  Nguồn: ${it.source}\n  Phần cứng: ${it.hardwareTarget}"
            }
        }
        binding.txtSavedConfigs.text = "Các model đã lưu:\n\n$text"
    }
}
