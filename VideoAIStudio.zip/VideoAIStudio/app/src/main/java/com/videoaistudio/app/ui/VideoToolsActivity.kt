package com.videoaistudio.app.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.DragEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import com.videoaistudio.app.databinding.ActivityVideoToolsBinding
import com.videoaistudio.app.debug.DebugLog
import com.videoaistudio.app.video.CompressService
import com.videoaistudio.app.video.FileUtils
import com.videoaistudio.app.video.VideoEngine
import com.videoaistudio.app.video.VideoOpResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class VideoToolMode(val label: String) {
    TRIM_SPLIT("Cắt / Tách video"),
    REMOVE_MIDDLE("Xoá đoạn giữa, ghép phần còn lại"),
    MERGE("Ghép video"),
    EXTRACT_AUDIO("Tách âm thanh"),
    COMPRESS("Nén dung lượng");

    override fun toString(): String = label
}

/**
 * Màn hình gộp Trim/Cut + Split thành 1, cộng Merge/Extract Audio/Compress.
 * Trim/Split có preview video thật (Media3 ExoPlayer) + RangeSlider để chọn đoạn
 * trực quan, kèm ô nhập giờ:phút:giây cho video dài (dễ theo dõi hơn số giây thô).
 */
class VideoToolsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideoToolsBinding
    private val selectedFilePaths = mutableListOf<String>()
    private var currentMode: VideoToolMode = VideoToolMode.TRIM_SPLIT
    private var player: ExoPlayer? = null
    private var videoDurationSec: Float = 100f

    private val pickSingleVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { importUri(it) }
    }

    private val pickMultipleVideos = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        uris.forEach { importUri(it) }
    }

    private var lastSingleOutputPath: String? = null
    private var lastMultiOutputPaths: List<String>? = null

    private val saveAsLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? ->
        uri?.let { destUri ->
            val sourcePath = lastSingleOutputPath ?: return@let
            try {
                contentResolver.openOutputStream(destUri)?.use { out ->
                    File(sourcePath).inputStream().use { input -> input.copyTo(out) }
                }
                // Hỏi có muốn xoá bản trong app không, tránh chiếm gấp đôi dung lượng
                AlertDialog.Builder(this)
                    .setTitle("Đã lưu thành công")
                    .setMessage("File đã được lưu vào vị trí bạn chọn. Xoá bản sao trong bộ nhớ app để tránh chiếm gấp đôi dung lượng?")
                    .setPositiveButton("Xoá bản trong app") { _, _ ->
                        File(sourcePath).delete()
                        binding.btnSaveAs.visibility = View.GONE
                        Toast.makeText(this, "Đã xoá bản trong app", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Giữ cả 2 bản", null)
                    .show()
            } catch (e: Exception) {
                Toast.makeText(this, "Lưu thất bại: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * FIX: trước đây khi có NHIỀU file kết quả (vd tách audio nhiều đoạn), app chỉ
     * lưu chúng trong thư mục riêng của app (Android/data/com.videoaistudio.app/...)
     * và không có cách nào để người dùng chuyển chúng ra vị trí công khai (Tải xuống,
     * Nhạc, thư mục tự chọn...) — nếu gỡ app, xoá cache, hoặc dùng trình quản lý file
     * không thấy được thư mục "Android/data" (bị Android giới hạn từ Android 11), coi
     * như MẤT file. Đây chính là "lỗi lưu file" khi tách được nhiều đoạn audio.
     *
     * Dùng ACTION_OPEN_DOCUMENT_TREE để người dùng chọn 1 thư mục (vd Tải xuống, hoặc
     * tự tạo thư mục mới), rồi copy TOÀN BỘ các file kết quả vào đó bằng DocumentFile.
     */
    private val saveAllAsLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri: Uri? ->
        treeUri?.let { uri ->
            val paths = lastMultiOutputPaths ?: return@let
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            val destTree = androidx.documentfile.provider.DocumentFile.fromTreeUri(this, uri)
            if (destTree == null) {
                Toast.makeText(this, "Không mở được thư mục đã chọn.", Toast.LENGTH_LONG).show()
                return@let
            }
            var savedCount = 0
            var failedCount = 0
            for (path in paths) {
                try {
                    val srcFile = File(path)
                    val mime = contentResolver.let { android.webkit.MimeTypeMap.getSingleton() }
                        .getMimeTypeFromExtension(srcFile.extension) ?: "application/octet-stream"
                    val destDoc = destTree.createFile(mime, srcFile.name)
                    if (destDoc != null) {
                        contentResolver.openOutputStream(destDoc.uri)?.use { out ->
                            srcFile.inputStream().use { input -> input.copyTo(out) }
                        }
                        savedCount++
                    } else {
                        failedCount++
                    }
                } catch (e: Exception) {
                    failedCount++
                }
            }
            val summary = if (failedCount == 0) {
                "Đã lưu $savedCount/$savedCount file vào thư mục đã chọn."
            } else {
                "Đã lưu $savedCount file, LỖI $failedCount file — thử lại nếu cần."
            }
            AlertDialog.Builder(this)
                .setTitle("Kết quả lưu")
                .setMessage("$summary\n\nXoá các bản sao trong bộ nhớ app để tránh chiếm gấp đôi dung lượng?")
                .setPositiveButton("Xoá bản trong app") { _, _ ->
                    paths.forEach { File(it).delete() }
                    binding.btnSaveAllAs.visibility = View.GONE
                    Toast.makeText(this, "Đã xoá bản trong app", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Giữ cả 2 bản", null)
                .show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLog.log(this, "VideoToolsActivity", "onCreate() — Activity instance MỚI được tạo (savedInstanceState=${savedInstanceState != null})")
        binding = ActivityVideoToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val requestedModeName = intent.getStringExtra(EXTRA_MODE)
        currentMode = VideoToolMode.values().firstOrNull { it.name == requestedModeName } ?: VideoToolMode.TRIM_SPLIT

        FileUtils.clearVideoInputCache(applicationContext)

        binding.spinnerMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, VideoToolMode.values())
        binding.spinnerMode.setSelection(VideoToolMode.values().indexOf(currentMode))
        binding.spinnerMode.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentMode = VideoToolMode.values()[position]
                onModeChanged()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        binding.spinnerCompressPreset.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Nhẹ (nén nhiều, nhỏ nhất)", "Vừa (cân bằng)", "Nét (nén ít, giữ chất lượng)")
        )
        binding.spinnerCompressPreset.setSelection(1) // mặc định "Vừa"
        binding.spinnerCompressPreset.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = updateCompressEstimate()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        binding.btnPickVideo.setOnClickListener {
            selectedFilePaths.clear()
            updateSelectedFilesText()
            if (currentMode == VideoToolMode.MERGE || currentMode == VideoToolMode.COMPRESS) {
                pickMultipleVideos.launch(arrayOf("video/*"))
            } else {
                pickSingleVideo.launch(arrayOf("video/*"))
            }
        }

        binding.btnAddMoreVideo.setOnClickListener {
            pickMultipleVideos.launch(arrayOf("video/*"))
        }

        binding.btnAddSelectedRange.setOnClickListener { addSelectedRangeToList() }
        binding.btnRun.setOnClickListener { runCurrentAction() }
        binding.btnViewDebugLog.setOnClickListener { showDebugLogDialog() }
        // Lối tắt gần khu Trim, xem giải thích ở layout XML (chỗ khai báo nút này) — cùng
        // gọi thẳng 1 hàm showDebugLogDialog() y hệt nút gốc, không phải luồng riêng.
        binding.btnViewDebugLogShortcut.setOnClickListener { showDebugLogDialog() }
        binding.btnCancelRunning.setOnClickListener {
            val cancelled = VideoEngine.cancelCurrentSession()
            if (cancelled) {
                Toast.makeText(this, "Đã gửi yêu cầu huỷ — chờ vài giây để dừng hẳn.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Không có tác vụ nào đang chạy để huỷ.", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnSaveAs.setOnClickListener {
            val path = lastSingleOutputPath ?: return@setOnClickListener
            saveAsLauncher.launch(File(path).name)
        }
        binding.btnSaveAllAs.setOnClickListener {
            saveAllAsLauncher.launch(null)
        }

        setupDragAndDrop()

        onModeChanged()
    }

    /**
     * Cho phép kéo file trực tiếp từ File Manager (chế độ chia đôi màn hình / cửa sổ
     * thu nhỏ — Android multi-window drag-and-drop) thả thẳng vào màn hình này, THAY
     * VÌ bắt buộc phải bấm nút "Chọn video" rồi duyệt thư mục thủ công trước. Gắn vào
     * `binding.root` (toàn màn hình) để thả ở bất kỳ chỗ nào cũng nhận được, không
     * cần nhắm chính xác vào 1 nút nhỏ.
     *
     * Tái sử dụng đúng `importUri()` đã có sẵn (dùng chung với luồng bấm nút chọn
     * file) — nhờ vậy hành vi sau khi thả (copy vào cache, cập nhật danh sách, load
     * preview...) giống hệt như chọn file qua nút bấm, không viết logic riêng dễ lệch.
     */
    private fun setupDragAndDrop() {
        val originalBackground = binding.root.background
        binding.root.setOnDragListener { view, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> {
                    // Chấp nhận rộng rãi, không lọc gắt theo MIME "video/*" ở bước này
                    // — nhiều app File Manager không luôn khai báo đúng MIME khi bắt
                    // đầu kéo. Định dạng sai sẽ tự bị ExoPlayer/FFmpeg báo lỗi ở bước xử
                    // lý sau, không cần chặn sớm ở đây.
                    true
                }
                DragEvent.ACTION_DRAG_ENTERED -> {
                    view.setBackgroundColor(0x332196F3) // xanh dương mờ — gợi ý đang ở đúng vùng thả
                    true
                }
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> {
                    view.background = originalBackground
                    true
                }
                DragEvent.ACTION_DROP -> {
                    view.background = originalBackground
                    val clipData = event.clipData
                    if (clipData == null || clipData.itemCount == 0) {
                        Toast.makeText(this, "Không nhận được file từ thao tác kéo-thả", Toast.LENGTH_SHORT).show()
                        return@setOnDragListener true
                    }
                    // BẮT BUỘC xin quyền đọc URI đến từ app khác qua kéo-thả — khác với
                    // URI trả về từ file picker (OpenDocument) vốn đã tự động có quyền,
                    // URI từ kéo-thả liên-app cần xin quyền tường minh kiểu này, nếu
                    // không đọc file sẽ bị SecurityException.
                    val permissions = requestDragAndDropPermissions(event)
                    val isMultiMode = currentMode == VideoToolMode.MERGE || currentMode == VideoToolMode.COMPRESS
                    if (!isMultiMode) {
                        // Chế độ chỉ nhận 1 file: thả file mới = THAY THẾ file đang chọn,
                        // giống hệt hành vi nút "Chọn video" (không phải "Thêm video").
                        selectedFilePaths.clear()
                        updateSelectedFilesText()
                    }
                    var addedCount = 0
                    for (i in 0 until clipData.itemCount) {
                        if (!isMultiMode && addedCount >= 1) break // chế độ 1 file: chỉ lấy file đầu tiên nếu lỡ kéo nhiều file cùng lúc
                        val uri = clipData.getItemAt(i).uri ?: continue
                        importUri(uri)
                        addedCount++
                    }
                    permissions?.release()
                    if (addedCount > 0) {
                        Toast.makeText(this, "Đã thêm $addedCount file từ kéo-thả", Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun currentPreset(): VideoEngine.CompressPreset = when (binding.spinnerCompressPreset.selectedItemPosition) {
        0 -> VideoEngine.CompressPreset.NHE
        2 -> VideoEngine.CompressPreset.NET
        else -> VideoEngine.CompressPreset.VUA
    }

    private fun updateCompressEstimate() {
        if (selectedFilePaths.isEmpty()) {
            binding.txtCompressEstimate.text = "Chọn video để xem ước tính dung lượng"
            return
        }
        val preset = currentPreset()
        var totalOriginal = 0L
        var totalEstimated = 0L
        var validCount = 0
        for (path in selectedFilePaths) {
            val originalBitrate = FileUtils.calculateActualBitrateBps(path)
            val durationSec = FileUtils.getVideoDurationSec(path)
            if (originalBitrate <= 0 || durationSec <= 0) continue
            validCount++
            totalOriginal += File(path).length()
            val estimatedBitrate = (originalBitrate * preset.bitrateMultiplier).toLong()
            totalEstimated += (estimatedBitrate * durationSec / 8).toLong()
        }
        binding.txtCompressEstimate.text = if (validCount == 0) {
            "Không đọc được thông tin video để ước tính"
        } else {
            val prefix = if (selectedFilePaths.size > 1) "Tổng ${selectedFilePaths.size} file — " else ""
            "${prefix}Dung lượng gốc: ${FileUtils.formatBytes(totalOriginal)} → Ước tính sau nén: ~${FileUtils.formatBytes(totalEstimated)}"
        }
    }

    private fun importUri(uri: Uri) {
        try {
            val name = FileUtils.queryDisplayName(this, uri)
            val file = FileUtils.copyUriToCache(this, uri, name)
            selectedFilePaths.add(file.absolutePath)
            updateSelectedFilesText()

            if ((currentMode == VideoToolMode.TRIM_SPLIT || currentMode == VideoToolMode.EXTRACT_AUDIO || currentMode == VideoToolMode.REMOVE_MIDDLE) && selectedFilePaths.size == 1) {
                loadPreview(file)
            }
            if (currentMode == VideoToolMode.COMPRESS) updateCompressEstimate()
        } catch (e: Exception) {
            Toast.makeText(this, "Không đọc được file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Định dạng giây -> "H:MM:SS" để dễ theo dõi với video dài. */
    private fun secondsToHms(totalSec: Float): String {
        val total = totalSec.toInt()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    /** Đọc "H:MM:SS" hoặc "MM:SS" hoặc chỉ số giây -> tổng số giây (float). Trả null nếu sai định dạng. */
    private fun hmsToSeconds(text: String): Float? {
        val parts = text.trim().split(":")
        return try {
            when (parts.size) {
                1 -> parts[0].toFloat()
                2 -> parts[0].toInt() * 60f + parts[1].toFloat()
                3 -> parts[0].toInt() * 3600f + parts[1].toInt() * 60f + parts[2].toFloat()
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Nạp video vào player xem trước + đọc thời lượng thật để đặt giới hạn RangeSlider. */
    // @OptIn(UnstableApi::class): cần cho SeekParameters bên dưới. LƯU Ý quan trọng (rút
    // kinh nghiệm từ lần nâng media3 lên 1.10.1 bị lỗi build compileSdk 36): `SeekParameters`
    // được đánh dấu @UnstableApi nhưng đây KHÔNG phải API mới — nó tồn tại từ những bản
    // ExoPlayer/Media3 đầu tiên (Media3 gắn @UnstableApi cho rất nhiều API tầng thấp ngay từ
    // 1.0.0, không đồng nghĩa "mới ra"). KHÔNG cần đổi version media3 (vẫn 1.4.1 như cũ) —
    // `androidx.media3.common.util.UnstableApi` đã có sẵn từ `media3-common` (dependency có
    // sẵn từ trước), không kéo theo yêu cầu compileSdk nào mới.
    @OptIn(UnstableApi::class)
    private fun loadPreview(file: File) {
        releasePlayer()

        try {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(file.absolutePath)
                val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                videoDurationSec = (durationMs / 1000f).coerceAtLeast(1f)
            } finally {
                retriever.release()
            }

            binding.rangeSlider.valueFrom = 0f
            binding.rangeSlider.valueTo = videoDurationSec
            binding.rangeSlider.values = listOf(0f, videoDurationSec)
            binding.txtRangeLabel.text = "Kéo 2 đầu để chọn đoạn (0:00 - ${secondsToHms(videoDurationSec)})"
            binding.edtStartSec.setText(secondsToHms(0f))
            binding.edtEndSec.setText(secondsToHms(videoDurationSec))

            val exoPlayer = ExoPlayer.Builder(this).build()
            // FIX QUAN TRỌNG (báo qua chat, LẦN THỨ 3 cho đúng 1 bug — đọc hết trước khi
            // đụng vào đoạn này lần nữa): "kéo slider thì frame KHÔNG di chuyển, thả tay ra
            // mới nhảy tới đúng chỗ".
            //
            // Nguyên nhân gốc (phần này đúng, không đổi): RangeSlider bắn addOnChangeListener
            // RẤT NHIỀU LẦN trong 1 lần kéo (gần như mỗi pixel), mỗi lần gọi thẳng
            // exoPlayer.seekTo() mới -> ExoPlayer huỷ seek đang xử lý dở mỗi khi nhận seek
            // mới -> nếu gọi nhanh hơn tốc độ decode+render, không khung hình nào kịp hiển
            // thị cho tới khi luồng seekTo dừng lại (= lúc thả tay).
            //
            // [SỬA LẦN 1 — 02/09/2026 — ĐÃ GIAO NHƯNG SAI, GHI LẠI LÝ DO ĐỂ KHÔNG LẶP LẠI]
            // Bản trước dựng cơ chế "tối đa 1 seek đang bay" + đợi
            // onPositionDiscontinuity(reason=SEEK) báo "xong" mới bắn lệnh tiếp theo. Test
            // tay thật báo lại NGUYÊN VĂN triệu chứng cũ — cơ chế "đợi" không có tác dụng
            // gì. Tra tài liệu chính thức Media3
            // (developer.android.com/media/media3/exoplayer/listening-to-player-events) mới
            // rõ lý do: onPositionDiscontinuity(SEEK) được bắn ra NGAY LẬP TỨC như hệ quả
            // trực tiếp của lời gọi seekTo() (cơ chế "position masking" — ExoPlayer cập nhật
            // vị trí báo cáo ra ngoài tức thì để currentPosition đúng ngay, KHÔNG chờ khung
            // hình thật sự được decode+render lên Surface). Nghĩa là tín hiệu mình dùng để
            // "biết khi nào an toàn bắn seek tiếp theo" thật ra không hề tương ứng với việc
            // nặng (render hình) — nó tương ứng với việc nhẹ (cập nhật con số vị trí) — nên
            // lệnh seekTo() thứ 2 vẫn được bắn đi gần như ngay sau lệnh thứ nhất, y hệt lúc
            // chưa sửa gì. Bài học: dùng 1 callback để suy luận "việc nặng xong chưa" thì
            // phải xác minh đúng là callback đó gắn với việc nặng, không phải chỉ tình cờ đi
            // kèm.
            //
            // [SỬA LẦN 2 — 04/09/2026, ĐÃ THỬ, TỰ HUỶ TRONG PHIÊN NÀY — GHI LẠI ĐỂ KHÔNG AI
            // LẶP LẠI] Ban đầu định dùng "Scrubbing Mode" chính thức của ExoPlayer
            // (setScrubbingModeEnabled(), Media3 >= 1.8.0) — API CHÍNH XÁC cho use-case này
            // (nguồn: android-developers.googleblog.com/2025/08/media3-180-whats-new.html).
            // ĐÃ nâng media3 lên 1.10.1 và đẩy build qua GitHub Actions để thử — build LỖI
            // BIÊN DỊCH (không phải lỗi runtime): media3 1.10.1 yêu cầu compileSdk >= 36,
            // mà project đang compileSdk 34 với AGP 8.5.0 (chỉ hỗ trợ tối đa 34). Tra tiếp
            // thì AGP hỗ trợ compileSdk 36 sớm nhất là bản 9.0 — nhưng AGP 9.0/9.1 là BẢN
            // MAJOR, đổi hẳn kiến trúc DSL nội bộ, MẶC ĐỊNH bật "Built-in Kotlin" đòi hỏi
            // Kotlin Gradle Plugin >= 2.2.10 (project đang khai 1.9.24 — cách nhau rất xa),
            // bỏ hẳn nhiều API cũ (variantFilter, sdkDirectory/ndkDirectory/adbExecutable...).
            // Đây không còn là "tăng 1 số version thư viện" nữa mà là nâng cấp lớn cả toolchain
            // — không có mạng để build-thử trong môi trường sửa code này, nên KHÔNG đánh cược
            // tiếp bằng 1 lần build thật nữa của bạn. ĐÃ HUỶ hướng này, quay về media3 1.4.1
            // như cũ (xem app/build.gradle.kts) — nếu sau này chủ động muốn nâng cả AGP lên
            // 9.x (việc đáng làm về lâu dài, nhưng cần làm RIÊNG, có kiểm tra kỹ riêng,
            // không lồng vào 1 bug fix nhỏ thế này), thì lúc đó mở lại API scrubbing mode.
            //
            // [SỬA LẦN 3 — CƠ CHẾ TỰ VIẾT, KHÔNG PHỤ THUỘC VERSION/CALLBACK NÀO CỦA EXOPLAYER]
            // Thay vì suy luận "ExoPlayer báo xong seek chưa" (2 lần trước đều sai vì chọn
            // nhầm tín hiệu, hoặc tín hiệu đúng nhưng kéo theo nâng cấp quá rủi ro), đổi hẳn
            // cách tiếp cận: dùng 1 "nhịp" (ticker) cố định bằng Handler.postDelayed(), CHỈ
            // chạy trong lúc đang kéo — mỗi 90ms bắn seekTo() ĐÚNG 1 LẦN tới vị trí ngón tay
            // MỚI NHẤT tại thời điểm đó (không quan tâm ExoPlayer đã "xử lý xong" seek trước
            // hay chưa). Bản chất: tự giới hạn cứng tốc độ gọi seekTo() bằng đồng hồ, KHÔNG
            // dựa vào bất kỳ callback/trạng thái nội bộ nào của ExoPlayer — nên không thể tái
            // diễn kiểu lỗi "chọn nhầm tín hiệu" như 2 lần trước, và không cần thư viện nào
            // mới. Đánh đổi: preview lúc kéo cập nhật theo nhịp cố định bên dưới (mượt vừa đủ
            // để mắt thấy hình di chuyển theo tay, không phải mọi frame), thay vì "mượt tuyệt
            // đối" như scrubbing mode thật sự — chấp nhận được để đổi lấy KHÔNG rủi ro build vỡ.
            //
            // [BỔ SUNG — phản hồi "vẫn trễ hơn hồi trước"] Ticker chỉ trị được 1 trong 2 nguồn
            // trễ: tốc độ GỌI seekTo(). Nguồn trễ còn lại là tốc độ MỖI LẦN seek tự nó chạy
            // bao lâu — mặc định ExoPlayer seek chính xác tuyệt đối (`SeekParameters.EXACT`),
            // với video nén phải decode tuần tự từ keyframe gần nhất tới đúng vị trí, có thể
            // tốn hàng chục-hàng trăm ms/lần tuỳ khoảng cách tới keyframe. Đã thêm
            // `exoPlayer.setSeekParameters(SeekParameters.CLOSEST_SYNC)` lúc bắt đầu kéo (xem
            // `addOnSliderTouchListener` bên dưới) — nhảy thẳng tới keyframe gần nhất, gần như
            // tức thời, đổi lấy hình có thể lệch chút so với đúng mili-giây (chấp nhận được
            // khi đang xem trước, trả lại `EXACT` ngay khi thả tay cho lần seek chốt cuối).
            //
            // [ĐIỀU CHỈNH 04/09/2026, phản hồi hộp thoại đòi đóng app xuất hiện liên tục khi
            // test] Log debug thật (người dùng gửi) cho thấy nhiều lần kéo kéo dài LIÊN TỤC
            // 8-14 GIÂY, mỗi lần bắn 100-211 lệnh seekTo() THẬT (không phải giả định — đếm
            // được), tức là chỉ trong 1 lần kéo tay đã yêu cầu ExoPlayer decode+hiển thị
            // 100-200 khung hình khác nhau liên tiếp — nặng hơn nhiều so với 1 cú vuốt ngắn
            // thông thường. CHƯA CHẮC đây là nguyên nhân của hộp thoại đòi đóng app (cần biết
            // ĐÚNG chữ trong hộp thoại đó mới kết luận được — có thể là ANR thật của Android,
            // cũng có thể là tính năng "tự đóng app tốn pin" riêng của hãng máy, không liên
            // quan gì tới đoạn code này) — nhưng tăng nhịp lên 100ms (giảm ~40% tổng số lệnh
            // seek cho cùng 1 thời lượng kéo) là biện pháp giảm tải hợp lý trong lúc chờ xác
            // định đúng nguyên nhân, không cần đợi biết chắc mới hành động.
            var scrubTicker: Runnable? = null
            var latestDragValueSec: Float? = null
            val scrubTickHandler = android.os.Handler(android.os.Looper.getMainLooper())
            val scrubTickIntervalMs = 100L
            exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    Toast.makeText(
                        this@VideoToolsActivity,
                        "Không xem trước được video này (có thể do định dạng/codec lạ), nhưng vẫn có thể nhập giờ:phút:giây để xử lý.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
            exoPlayer.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            exoPlayer.playWhenReady = false
            exoPlayer.prepare()
            // [SỬA 02/09/2026] BỎ HẲN controller mặc định của Media3 (use_controller=false
            // trong layout) — controller đó đi kèm 1 thanh tiến độ (TimeBar) nội bộ. Thay
            // vào đó: tự làm 1 nút play/pause riêng (`btnPlayPause`, ảnh hệ thống Android có
            // sẵn, không cần drawable riêng) — bấm vào khung preview để hiện/ẩn nút, bấm vào
            // nút để play/pause thật.
            // [GHI CHÚ THÊM — phiên sửa scrubbing mode]: người dùng báo "thanh trượt trên
            // preview player không phản ứng nữa" — ĐÃ KIỂM TRA layout
            // (activity_video_tools.xml): `use_controller="false"` nghĩa là KHÔNG có TimeBar
            // nội bộ nào tồn tại trên màn hình này cả — RangeSlider (ngay bên dưới khung
            // preview) là thanh kéo DUY NHẤT. Nhiều khả năng "thanh trượt trên preview
            // player" người dùng nói tới CHÍNH LÀ RangeSlider (nó nằm sát preview) — nên bản
            // sửa scrubbing mode áp cho RangeSlider ở dưới đây nhắm đúng vào phản hồi này.
            // Nếu build lại rồi vẫn thấy có 1 thanh trượt KHÁC không phản ứng (không phải
            // RangeSlider) thì đó là điều CHƯA ai xác nhận lại — cần chụp màn hình rõ chỗ đó
            // để xác định chính xác, đừng đoán tiếp.
            // (Media3 >= 1.8.0 cũng hỗ trợ scrubbing mode ngay trong TimeBar mặc định của
            // PlayerControlView qua `time_bar_scrubbing_enabled="true"` — nhưng dùng được nó
            // cũng cần đúng bản media3 đó, tức là dính đúng bức tường compileSdk 36 / AGP 9.x
            // đã gặp và lùi lại ở trên. Nên hiện tại việc bật lại controller mặc định KHÔNG
            // khả thi hơn gì so với lúc quyết định bỏ nó ở mục 02/09/2026 — giữ nguyên quyết
            // định "chỉ 1 chỗ kéo-thả duy nhất" (RangeSlider) cho tới khi có đợt nâng cấp
            // AGP/Kotlin riêng, làm cẩn thận, không lồng vào bug fix nhỏ thế này.)
            binding.playerView.player = exoPlayer
            player = exoPlayer

            fun updatePlayPauseIcon() {
                binding.btnPlayPause.setImageResource(
                    if (exoPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            }
            // [THÊM 04/09/2026] Cập nhật chữ "hiện tại / tổng" trong khung preview — xem giải
            // thích đầy đủ ở khai báo layout (txtCurrentPreviewTime). currentSec lấy từ NGOÀI
            // truyền vào (không tự đọc exoPlayer.currentPosition ở đây) vì lúc đang kéo,
            // exoPlayer.currentPosition có thể chưa kịp cập nhật đúng bằng giá trị ngón tay
            // mới nhất (đang xử lý CLOSEST_SYNC) — dùng thẳng giá trị slider/nút bấm cho khớp
            // với những gì người dùng đang thao tác, không lệch 1 nhịp.
            fun updateCurrentTimeText(currentSec: Float) {
                binding.txtCurrentPreviewTime.text =
                    "${secondsToHms(currentSec.coerceIn(0f, videoDurationSec))} / ${secondsToHms(videoDurationSec)}"
            }
            updateCurrentTimeText(0f) // giá trị ban đầu khi vừa nạp preview
            // [THÊM 04/09/2026, sửa bug "kéo nút 2 (điểm cuối) rồi bấm nút tua thì lại nhảy
            // về nút 1 (điểm đầu)"] Nhớ THUMB NÀO (đầu hay cuối) người dùng vừa thao tác gần
            // nhất trên RangeSlider — xem chỗ gán giá trị này trong addOnChangeListener bên
            // dưới để rõ cách suy luận. Phải khai báo Ở ĐÂY (trước các nút tua bên dưới) vì
            // biến local trong Kotlin phải khai báo trước mới dùng được trong closure, dù
            // closure đó chỉ thực sự chạy sau này.
            var lastActiveThumbIsEnd = false
            // Cập nhật đúng thumb đang thao tác (không phải lúc nào cũng thumb đầu — đó
            // chính là bug vừa báo) rồi đồng bộ lại chữ thời gian. Dùng chung cho cả 4 nút
            // tua (5s/15s/1s) bên dưới để khỏi lặp lại 4 lần.
            fun seekAndSyncActiveThumb(targetMs: Long) {
                exoPlayer.seekTo(targetMs)
                val targetSec = targetMs / 1000f
                updateCurrentTimeText(targetSec)
                val values = binding.rangeSlider.values
                if (values.size >= 2) {
                    binding.rangeSlider.values = if (lastActiveThumbIsEnd) {
                        listOf(values.first(), targetSec.coerceIn(values.first(), videoDurationSec))
                    } else {
                        listOf(targetSec.coerceIn(0f, values.last()), values.last())
                    }
                }
            }
            exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { updatePlayPauseIcon() }
            })
            binding.playerView.setOnClickListener {
                // Bấm vào khung preview -> hiện/ẩn CẢ HÀNG nút play/pause + tua lùi/tới cùng
                // lúc (giống hành vi controller mặc định trước đây: bấm vào preview mới thấy
                // nút, bấm ra ngoài thì ẩn). Chữ thời gian KHÔNG nằm trong nhóm này — hiện
                // liên tục, không cần bấm mới thấy (giống TimeBar cũ).
                binding.groupPlaybackButtons.visibility =
                    if (binding.groupPlaybackButtons.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                if (binding.groupPlaybackButtons.visibility == View.VISIBLE) updatePlayPauseIcon()
            }
            binding.btnPlayPause.setOnClickListener {
                try {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }
            // [THÊM 04/09/2026 — khôi phục lại, xem giải thích ở layout XML] 2 nút này TỪNG
            // có sẵn trong controller mặc định của Media3 (rewind_increment=5000,
            // fastforward_increment=15000) — bị mất khi gỡ hẳn controller ở 02/09/2026, không
            // ai chủ ý bỏ. Cập nhật cả RangeSlider (để không bị lệch với vị trí preview thật)
            // lẫn chữ thời gian sau khi tua.
            binding.btnRewind5s.setOnClickListener {
                try {
                    seekAndSyncActiveThumb((exoPlayer.currentPosition - 5000L).coerceAtLeast(0L))
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }
            binding.btnForward15s.setOnClickListener {
                try {
                    seekAndSyncActiveThumb((exoPlayer.currentPosition + 15000L).coerceAtMost((videoDurationSec * 1000).toLong()))
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }
            // [THÊM 04/09/2026] Cặp nút -1s/+1s NGOÀI khung preview — xem giải thích ở layout
            // XML (chỗ khai báo btnStep1sBack/btnStep1sForward). Dùng chung logic với 2 nút
            // tua trong preview ở trên, chỉ khác bước nhảy (1000ms thay vì 5000/15000ms).
            binding.btnStep1sBack.setOnClickListener {
                try {
                    seekAndSyncActiveThumb((exoPlayer.currentPosition - 1000L).coerceAtLeast(0L))
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }
            binding.btnStep1sForward.setOnClickListener {
                try {
                    seekAndSyncActiveThumb((exoPlayer.currentPosition + 1000L).coerceAtMost((videoDurationSec * 1000).toLong()))
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }

            var syncingFromCode = false
            // Chỉ dùng để ghi log debug (xem addOnSliderTouchListener bên dưới) — đếm số
            // lần seekTo() THẬT SỰ đã bắn (do ticker, không phải số lần addOnChangeListener
            // bắn ra — 2 con số này khác nhau nhiều, addOnChangeListener bắn dồn dập theo
            // pixel, ticker chỉ bắn tối đa 1 lần mỗi scrubTickIntervalMs) + thời điểm bắt đầu
            // kéo, để nếu người dùng test tay thật vẫn thấy chưa mượt thì có SỐ LIỆU THẬT gửi
            // kèm log, thay vì phải mô tả cảm giác bằng lời.
            var scrubMoveCount = 0
            var scrubStartAtMs = 0L
            // (lastActiveThumbIsEnd đã khai báo phía trên, trước các nút tua — dùng lại ở
            // đây, không khai báo lần 2)

            binding.rangeSlider.addOnChangeListener { slider, value, fromUser ->
                if (syncingFromCode) return@addOnChangeListener
                val values = slider.values
                if (values.size >= 2) {
                    syncingFromCode = true
                    binding.edtStartSec.setText(secondsToHms(values.first()))
                    binding.edtEndSec.setText(secondsToHms(values.last()))
                    syncingFromCode = false
                    if (fromUser) {
                        // CHỈ ghi lại vị trí mới nhất của NÚT VỪA KÉO (value), không phải
                        // luôn luôn là điểm cuối — đây là lỗi khiến kéo nút đầu không xem
                        // trước được, chỉ kéo nút sau mới thấy hình (đã sửa từ trước).
                        // KHÔNG gọi seekTo() trực tiếp ở đây nữa — addOnChangeListener bắn ra
                        // quá nhiều lần trong 1 lần kéo (gần như mỗi pixel), gọi seekTo()
                        // ngay tại đây là NGUYÊN NHÂN GỐC của bug này. Việc bắn seekTo() thật
                        // sự do scrubTicker (Handler.postDelayed cố định nhịp, xem khai báo
                        // exoPlayer phía trên) đảm nhiệm — ở đây chỉ cập nhật biến nhớ vị trí.
                        latestDragValueSec = value
                        lastActiveThumbIsEnd = (value == values.last())
                        // Seek sắp tới đến từ NGOÀI khung preview (kéo slider) -> ẩn CẢ HÀNG
                        // nút (không che khung hình). BUG ĐÃ SỬA (04/09/2026, báo "nút play
                        // pause bị nuốt"): trước đây dòng này set riêng
                        // `btnPlayPause.visibility = GONE` — nhưng từ khi btnPlayPause nằm
                        // TRONG `groupPlaybackButtons` (thêm cùng đợt với nút tua 5s/15s),
                        // set visibility RIÊNG cho nó sẽ làm nó bị "kẹt ẩn" mãi mãi độc lập
                        // với trạng thái của cả nhóm — lần đầu kéo RangeSlider là nút play/
                        // pause biến mất vĩnh viễn (dù bấm vào preview vẫn hiện lại được 2 nút
                        // tua vì chúng không bị đụng tới). Phải ẩn đúng View cha
                        // (groupPlaybackButtons), không phải từng nút con riêng lẻ.
                        binding.groupPlaybackButtons.visibility = View.GONE
                    }
                }
            }

            // QUAN TRỌNG: khi cắt bằng "-c copy" (không encode lại), FFmpeg BẮT BUỘC bắt
            // đầu file output đúng tại 1 khung hình khoá — không thể cắt giữa chừng vì
            // không giải mã lại được. Trong lúc kéo, preview tua chính xác tới đúng giây
            // bạn thả tay, NHƯNG video output thật có thể lùi về khung hình khoá gần nhất
            // trước đó -> đây là nguyên nhân số giây/preview "khớp lúc xem nhưng ra file
            // lại lệch". Để loại bỏ hẳn sự lệch này: ngay khi THẢ TAY khỏi slider, làm
            // tròn điểm bắt đầu về ĐÚNG khung hình khoá đó luôn (cùng cơ chế FFmpeg dùng
            // bên trong) — từ lúc này, số giây + khung hình xem trước hiển thị chính là
            // những gì sẽ có trong file output, không còn khác biệt.
            // [THÊM 04/09/2026, ĐANG NGHI VẤN LÀ NGUYÊN NHÂN THẬT CỦA ANR] Biến này lưu lại
            // coroutine (Job) của lần tìm-keyframe GẦN NHẤT — xem lý do ngay tại chỗ dùng nó
            // trong onStopTrackingTouch bên dưới.
            var keyframeSnapJob: Job? = null
            binding.rangeSlider.addOnSliderTouchListener(object :
                com.google.android.material.slider.RangeSlider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: com.google.android.material.slider.RangeSlider) {
                    // Khởi động ticker NGAY KHI bắt đầu kéo — xem giải thích đầy đủ (và lý do
                    // 2 bản sửa trước đó KHÔNG dùng được) ở khai báo exoPlayer phía trên.
                    // Dừng lại ở onStopTrackingTouch bên dưới.
                    scrubMoveCount = 0
                    scrubStartAtMs = System.currentTimeMillis()
                    latestDragValueSec = null
                    // THÊM (04/09/2026, phản hồi "vẫn trễ hơn trước"): mặc định ExoPlayer seek
                    // CHÍNH XÁC tuyệt đối (SeekParameters.EXACT) — với video nén, muốn seek
                    // chính xác tới đúng 1 mili-giây thì phải DECODE TUẦN TỰ từ keyframe gần
                    // nhất TỚI đúng vị trí đó, có thể tốn hàng chục-hàng trăm ms MỖI LẦN seek
                    // tuỳ khoảng cách tới keyframe — đây là nguồn trễ THỨ 2, khác hẳn và CỘNG
                    // DỒN với việc "gọi seekTo() dồn dập" (ticker ở trên chỉ trị nguồn trễ thứ
                    // 1). Trong lúc đang kéo, đổi sang SeekParameters.CLOSEST_SYNC — nhảy thẳng
                    // tới keyframe GẦN NHẤT (không cần decode gì thêm, gần như tức thời), đổi
                    // lấy việc hình hiển thị có thể lệch chút so với đúng mili-giây yêu cầu
                    // (chấp nhận được khi CHỈ đang xem trước lúc kéo, chưa phải kết quả cuối).
                    // Trả lại EXACT ngay khi thả tay (xem onStopTrackingTouch) để lần seek cuối
                    // (chốt vị trí) vẫn chính xác như trước.
                    try {
                        exoPlayer.setSeekParameters(SeekParameters.CLOSEST_SYNC)
                    } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                    val ticker = object : Runnable {
                        override fun run() {
                            val target = latestDragValueSec
                            if (target != null) {
                                try {
                                    exoPlayer.seekTo((target * 1000).toLong())
                                    scrubMoveCount++
                                    updateCurrentTimeText(target)
                                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                            }
                            scrubTickHandler.postDelayed(this, scrubTickIntervalMs)
                        }
                    }
                    scrubTicker = ticker
                    scrubTickHandler.postDelayed(ticker, scrubTickIntervalMs)
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "RangeSlider.onStartTrackingTouch — bật scrubTicker (${scrubTickIntervalMs}ms/lần) + SeekParameters.CLOSEST_SYNC, values=${slider.values}"
                    )
                }
                override fun onStopTrackingTouch(slider: com.google.android.material.slider.RangeSlider) {
                    val elapsedMs = System.currentTimeMillis() - scrubStartAtMs
                    // Ghi số liệu THẬT (không phải cảm giác) ngay khi thả tay: bao nhiêu lệnh
                    // seek đã bắn trong bao nhiêu ms. Nếu sau khi build lại vẫn thấy chưa
                    // mượt, bấm "Xem/Gửi log debug" và gửi đúng dòng này thay vì mô tả lại
                    // bằng lời — đỡ phải đoán lần 4 cho cùng 1 bug.
                    DebugLog.log(
                        this@VideoToolsActivity, "VideoToolsActivity",
                        "RangeSlider.onStopTrackingTouch — tắt scrubTicker, $scrubMoveCount lần seekTo() thật trong ${elapsedMs}ms, values=${slider.values}"
                    )
                    try {
                        exoPlayer.setSeekParameters(SeekParameters.EXACT) // trả lại chính xác tuyệt đối cho lần seek chốt cuối cùng bên dưới
                    } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                    scrubTicker?.let { scrubTickHandler.removeCallbacks(it) }
                    scrubTicker = null
                    val values = slider.values
                    if (values.size < 2) return
                    val requestedStart = values.first().toDouble()
                    val currentEnd = values.last()
                    val safeMax = (currentEnd - 0.1f).coerceAtLeast(slider.valueFrom)
                    // LỖI ĐÃ SỬA (báo qua chat): "kéo thì đồng bộ mượt, nhưng THẢ TAY RA
                    // thì khựng 1 nhịp rồi frame mới nhảy tới chỗ kéo". Nguyên nhân: gọi
                    // findPrecedingKeyframeSec() (MediaExtractor đọc file) TRỰC TIẾP trên
                    // main thread ngay trong callback này — thao tác đọc file có thể mất
                    // vài chục-vài trăm ms, đủ để đứng hình UI đúng lúc thả tay. Phần kéo
                    // mượt lúc đang rê tay (addOnChangeListener ở trên) KHÔNG bị ảnh hưởng
                    // vì không đụng tới đoạn đó — chỉ đúng khoảnh khắc thả tay bị khựng do
                    // lệnh đọc file này. Sửa: đẩy việc đọc file ra thread nền (IO), chỉ
                    // quay lại main thread để cập nhật UI/seek sau khi có kết quả.
                    //
                    // [SỬA THÊM 04/09/2026 — NGHI VẤN CHÍNH của hộp thoại ANR "không phản
                    // hồi"] Log debug thật cho thấy người dùng thả tay/kéo lại RẤT NHANH,
                    // nhiều lần liên tiếp trong vài giây (test kỹ, không phải dùng thường).
                    // Mỗi lần thả tay là 1 `lifecycleScope.launch` MỚI được tạo, nhưng job CŨ
                    // (nếu vẫn còn đang đọc file dở, MediaExtractor có thể mất vài chục-vài
                    // trăm ms) KHÔNG hề bị huỷ — thả tay/kéo lại nhanh 10-20 lần liên tục có
                    // thể khiến 10-20 `MediaExtractor` (tài nguyên gốc, tốn bộ nhớ + file
                    // descriptor) cùng mở trên CÙNG 1 file MỘT LÚC, không cái nào được giải
                    // phóng kịp — đây là ứng viên hợp lý nhất cho cả 2 triệu chứng: ANR (dồn
                    // việc/tranh chấp I/O) VÀ bộ nhớ đệm phình to bất thường dù đã đóng app
                    // (tài nguyên gốc không được `MediaExtractor.release()` giải phóng đúng
                    // lúc). Sửa: huỷ hẳn job CŨ (nếu còn) trước khi tạo job mới — đảm bảo tại
                    // 1 thời điểm chỉ có TỐI ĐA 1 lần đọc file đang chạy, y hệt nguyên tắc đã
                    // áp cho ticker seekTo() ở trên.
                    keyframeSnapJob?.cancel()
                    keyframeSnapJob = lifecycleScope.launch {
                        val snappedStart = withContext(Dispatchers.IO) {
                            FileUtils.findPrecedingKeyframeSec(file.absolutePath, requestedStart)
                        }.toFloat().coerceIn(slider.valueFrom, safeMax)
                        if (kotlin.math.abs(snappedStart - requestedStart.toFloat()) > 0.03f) {
                            syncingFromCode = true
                            slider.values = listOf(snappedStart, currentEnd)
                            binding.edtStartSec.setText(secondsToHms(snappedStart))
                            syncingFromCode = false
                            try {
                                // Chỉ 1 lệnh seek duy nhất ở đây (ngón tay đã thả ra rồi,
                                // không còn dồn dập nữa) -> gọi seekTo() thẳng, không cần
                                // qua cơ chế scrubbing mode (cái đó chỉ cần khi có NHIỀU
                                // lệnh liên tiếp lúc đang kéo).
                                exoPlayer.seekTo((snappedStart * 1000).toLong())
                                binding.groupPlaybackButtons.visibility = View.GONE // xem giải thích lỗi "nút play/pause bị nuốt" ở addOnChangeListener phía trên
                            } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                        }
                    }
                }
            })

            val textWatcher = object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) {
                    if (syncingFromCode) return
                    val start = hmsToSeconds(binding.edtStartSec.text.toString()) ?: return
                    val end = hmsToSeconds(binding.edtEndSec.text.toString()) ?: return
                    // Ép giới hạn an toàn trong [valueFrom, valueTo] — RangeSlider sẽ
                    // âm thầm bỏ qua (không di chuyển) nếu giá trị nằm ngoài khoảng
                    // hoặc start >= end, đây là nguyên nhân "gõ số nhưng slider không nhích".
                    val safeStart = start.coerceIn(0f, videoDurationSec)
                    val safeEnd = end.coerceIn(0f, videoDurationSec)
                    if (safeStart >= safeEnd) return
                    syncingFromCode = true
                    try {
                        binding.rangeSlider.values = listOf(safeStart, safeEnd)
                        binding.rangeSlider.invalidate()
                    } catch (e: Exception) { /* giá trị tạm thời không hợp lệ khi đang gõ dở, bỏ qua */ }
                    syncingFromCode = false
                }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            }
            binding.edtStartSec.addTextChangedListener(textWatcher)
            binding.edtEndSec.addTextChangedListener(textWatcher)
        } catch (e: Exception) {
            Toast.makeText(this, "Không nạp được video xem trước: ${e.message}. Vẫn có thể nhập giờ:phút:giây thủ công.", Toast.LENGTH_LONG).show()
        }
    }

    private fun addSelectedRangeToList() {
        val values = binding.rangeSlider.values
        if (values.size < 2) return
        val end = values.last()
        val requestedStart = values.first().toDouble()
        val currentFile = selectedFilePaths.firstOrNull()
        // Làm tròn lần cuối về khung hình khoá gần nhất trước khi ghi vào danh sách —
        // phòng trường hợp giá trị đang có chưa được làm tròn (vd người dùng gõ tay số
        // giây rồi bấm "Thêm đoạn" luôn, chưa từng chạm/thả slider để kích hoạt làm tròn
        // ở addOnSliderTouchListener). Nhờ vậy con số ghi vào danh sách LUÔN khớp đúng
        // với điểm bắt đầu thật của file output (xem giải thích chi tiết ở loadPreview()).
        // Đọc file (MediaExtractor) tốn thời gian -> đẩy ra thread nền, tránh khựng UI
        // ngay lúc bấm nút (cùng nguyên nhân/cách sửa như addOnSliderTouchListener).
        lifecycleScope.launch {
            val start = if (currentFile != null) {
                withContext(Dispatchers.IO) {
                    FileUtils.findPrecedingKeyframeSec(currentFile, requestedStart)
                }.toFloat()
            } else requestedStart.toFloat()
            val currentText = binding.edtSegments.text.toString()
            // Vẫn lưu nội bộ theo giây (để lệnh FFmpeg dùng), chỉ hiển thị cho người dùng theo giờ:phút:giây
            // FIX QUAN TRỌNG: "%.1f".format() không có Locale sẽ dùng Locale mặc định của máy.
            // Ở Locale Tiếng Việt (vi_VN), dấu thập phân là DẤU PHẨY (vd 10.5 -> "10,5"), khiến
            // dòng ghi ra thành "10,5,20,3" thay vì "10.5,20.3" — dấu "," ngăn cách giây bị LẪN
            // với dấu "," thập phân. parseSegments() tách theo "," sẽ ra 4 phần thay vì 2, dòng
            // bị coi là KHÔNG HỢP LỆ và bị bỏ qua -> segments rỗng -> app tưởng người dùng
            // "không chọn đoạn nào" -> tự động tách/lấy audio TOÀN BỘ video dù đã chọn đoạn.
            // Đây chính là nguyên nhân lỗi "lấy audio toàn bộ video khi chỉ muốn lấy vài đoạn"
            // trên máy để Locale Tiếng Việt. Ép Locale.US để luôn ra dấu chấm.
            val newLine = "${"%.1f".format(java.util.Locale.US, start)},${"%.1f".format(java.util.Locale.US, end)}"
            binding.edtSegments.setText(if (currentText.isBlank()) newLine else "$currentText\n$newLine")
        }
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }

    private fun updateSelectedFilesText() {
        binding.txtSelectedFiles.text = if (selectedFilePaths.isEmpty()) {
            "Chưa chọn video nào"
        } else {
            "Đã chọn ${selectedFilePaths.size} file (bấm 'Xoá' nếu chọn nhầm):"
        }

        binding.containerFileList.removeAllViews()
        for (path in selectedFilePaths.toList()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = 4 }
            }
            val nameView = TextView(this).apply {
                text = path.substringAfterLast("/")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(0, 8, 8, 8)
            }
            val removeBtn = Button(this).apply {
                text = "Xoá"
                setOnClickListener {
                    selectedFilePaths.remove(path)
                    updateSelectedFilesText()
                    if (currentMode == VideoToolMode.COMPRESS) updateCompressEstimate()
                    if (selectedFilePaths.isEmpty()) releasePlayer()
                }
            }
            row.addView(nameView)
            row.addView(removeBtn)
            binding.containerFileList.addView(row)
        }
    }

    private fun onModeChanged() {
        val showTrimGroup = currentMode == VideoToolMode.TRIM_SPLIT || currentMode == VideoToolMode.EXTRACT_AUDIO || currentMode == VideoToolMode.REMOVE_MIDDLE
        binding.groupTrimSplit.visibility = if (showTrimGroup) View.VISIBLE else View.GONE
        binding.groupCompress.visibility = if (currentMode == VideoToolMode.COMPRESS) View.VISIBLE else View.GONE
        binding.btnAddMoreVideo.visibility = if (currentMode == VideoToolMode.MERGE || currentMode == VideoToolMode.COMPRESS) View.VISIBLE else View.GONE
        binding.txtResult.text = ""
        binding.txtProgress.text = ""
        binding.btnSaveAs.visibility = View.GONE
        binding.btnSaveAllAs.visibility = View.GONE
        if (!showTrimGroup) releasePlayer()
        if (currentMode == VideoToolMode.COMPRESS) updateCompressEstimate()
        binding.edtSegments.hint = if (currentMode == VideoToolMode.REMOVE_MIDDLE)
            "Đoạn muốn XOÁ (bắt_đầu,kết_thúc theo giây)" else "0,30\n30,90"
        binding.txtSegmentsHelp.text = when (currentMode) {
            VideoToolMode.REMOVE_MIDDLE -> "Đoạn nhập vào sẽ bị XOÁ khỏi video, 2 phần còn lại (đầu + cuối) sẽ được ghép lại thành 1 file."
            VideoToolMode.EXTRACT_AUDIO -> "Để trống = tách toàn bộ audio. Nhập 1 đoạn = chỉ tách audio trong đoạn đó."
            else -> "1 dòng = Cắt lấy 1 đoạn (Trim). Nhiều dòng = Tách thành nhiều file (Split)."
        }
    }

    /**
     * Nếu người dùng đã kéo thanh trượt chọn 1 đoạn nhưng QUÊN bấm "Thêm đoạn đã chọn
     * vào danh sách" (dễ xảy ra, đúng lỗi đã báo: "chọn đoạn nhưng vẫn tách toàn bộ"),
     * tự động dùng đúng vị trí thanh trượt hiện tại làm đoạn xử lý — thay vì im lặng
     * coi là "không chọn gì" rồi xử lý toàn bộ video.
     */
    private fun getEffectiveSegments(): List<Pair<Double, Double>> {
        val rawText = binding.edtSegments.text.toString()
        if (rawText.isNotBlank()) return parseSegments(rawText)

        val values = binding.rangeSlider.values
        if (values.size < 2) return emptyList()
        val start = values.first()
        val end = values.last()
        // Chỉ coi là "có chọn đoạn" nếu khác biệt rõ so với toàn bộ video (tránh việc
        // slider ở đúng [0, duration] mặc định bị hiểu nhầm thành "có chọn đoạn").
        val isFullRange = start <= 0.05f && end >= videoDurationSec - 0.05f
        return if (isFullRange) emptyList() else listOf(start.toDouble() to end.toDouble())
    }

    /**
     * Callback tiến độ dùng cho trim/split/merge/tách audio/xoá đoạn giữa. FFmpegKit gọi
     * callback thống kê từ THREAD NỀN (không phải main thread), nên phải post qua
     * runOnUiThread trước khi đụng vào View, nếu không sẽ crash
     * (CalledFromWrongThreadException).
     */
    private fun updateRunProgress(percent: Int) {
        runOnUiThread {
            binding.progressBar.progress = percent
            binding.txtProgress.text = "Đang xử lý... $percent%"
        }
    }

    private fun runCurrentAction() {
        if (selectedFilePaths.isEmpty()) {
            Toast.makeText(this, "Vui lòng chọn video trước", Toast.LENGTH_SHORT).show()
            return
        }

        if (currentMode == VideoToolMode.COMPRESS) {
            runCompressBatch()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.progressBar.progress = 0
        binding.btnRun.isEnabled = false
        binding.txtResult.text = ""
        binding.txtProgress.text = "Đang xử lý..."

        lifecycleScope.launch {
            val outputDir = FileUtils.getOutputDir(this@VideoToolsActivity).absolutePath

            val result: VideoOpResult = when (currentMode) {
                VideoToolMode.TRIM_SPLIT -> {
                    val segments = getEffectiveSegments()
                    if (segments.isEmpty()) {
                        VideoOpResult(false, log = "Vui lòng kéo thanh trượt chọn 1 đoạn khác toàn bộ video (hoặc bấm 'Thêm đoạn' để tách nhiều đoạn)")
                    } else if (segments.size == 1) {
                        VideoEngine.trim(selectedFilePaths.first(), outputDir, segments[0].first, segments[0].second, ::updateRunProgress)
                    } else {
                        VideoEngine.split(selectedFilePaths.first(), outputDir, segments, ::updateRunProgress)
                    }
                }
                VideoToolMode.REMOVE_MIDDLE -> {
                    val segments = getEffectiveSegments()
                    if (segments.isEmpty()) {
                        VideoOpResult(false, log = "Vui lòng kéo thanh trượt chọn đoạn muốn xoá (khác toàn bộ video)")
                    } else {
                        VideoEngine.removeSegmentAndJoin(selectedFilePaths.first(), outputDir, segments[0].first, segments[0].second, videoDurationSec.toDouble(), ::updateRunProgress)
                    }
                }
                VideoToolMode.MERGE -> VideoEngine.merge(selectedFilePaths, outputDir, ::updateRunProgress)
                VideoToolMode.EXTRACT_AUDIO -> {
                    val segments = getEffectiveSegments()
                    when {
                        segments.isEmpty() -> VideoEngine.extractAudio(selectedFilePaths.first(), outputDir, ::updateRunProgress)
                        segments.size == 1 -> VideoEngine.extractAudioSegment(selectedFilePaths.first(), outputDir, segments[0].first, segments[0].second, ::updateRunProgress)
                        else -> VideoEngine.extractAudioMultipleSegments(selectedFilePaths.first(), outputDir, segments, ::updateRunProgress)
                    }
                }
                VideoToolMode.COMPRESS -> throw IllegalStateException("Đã xử lý riêng ở nhánh trên")
            }

            finishRun(result)
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val compressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                CompressService.ACTION_PROGRESS -> {
                    val fileIndex = intent.getIntExtra("fileIndex", 0)
                    val totalFiles = intent.getIntExtra("totalFiles", 1)
                    val percent = intent.getIntExtra("percent", 0)
                    val useHardware = intent.getBooleanExtra("useHardware", true)
                    val prefix = if (totalFiles > 1) "File ${fileIndex + 1}/$totalFiles: " else ""
                    binding.progressBar.progress = percent
                    binding.txtProgress.text = "$prefix$percent% (${if (useHardware) "phần cứng" else "phần mềm"})"
                }
                CompressService.ACTION_COMPLETE -> {
                    val success = intent.getBooleanExtra("success", false)
                    val outputPaths = intent.getStringArrayListExtra("outputPaths") ?: arrayListOf()
                    val log = intent.getStringExtra("log") ?: ""
                    finishRun(VideoOpResult(success, outputPaths, log))
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        DebugLog.log(this, "VideoToolsActivity", "onStart() — isRunning=${CompressService.CompressResultHolder.isRunning}, lastResult=${if (CompressService.CompressResultHolder.lastResult != null) "có" else "null"}")
        val filter = IntentFilter().apply {
            addAction(CompressService.ACTION_PROGRESS)
            addAction(CompressService.ACTION_COMPLETE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(compressReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(compressReceiver, filter)
        }

        // Đồng bộ lại UI nếu Service đã chạy xong (hoặc đang chạy) trong lúc app ở nền
        if (CompressService.CompressResultHolder.isRunning) {
            binding.progressBar.visibility = View.VISIBLE
            binding.btnRun.isEnabled = false
            binding.btnCancelRunning.visibility = View.VISIBLE
            binding.txtProgress.text = "Đang nén ở chế độ nền... (mở thông báo để xem chi tiết)"
            // FIX: trước đây dòng "Chưa chọn video nào" (do selectedFilePaths bị reset
            // khi Activity tạo lại) khiến người dùng tưởng NHẦM là file đã mất, dù
            // Service vẫn đang xử lý đúng file đó — giờ hiện rõ tên file thật đang nén.
            val runningNames = CompressService.CompressResultHolder.runningFileNames
            if (runningNames.isNotEmpty()) {
                binding.txtSelectedFiles.text = "Đang nén (chạy nền): " + runningNames.joinToString(", ")
            }
        } else {
            binding.btnCancelRunning.visibility = View.GONE
            val inMemoryResult = CompressService.CompressResultHolder.lastResult
            if (inMemoryResult != null) {
                finishRun(inMemoryResult)
                CompressService.CompressResultHolder.lastResult = null
            } else {
                // FIX QUAN TRỌNG: nếu bản trong bộ nhớ (lastResult) đã bị Android xoá do
                // tiến trình app bị tắt SAU KHI compress xong (đúng lúc Service vừa
                // stopForeground() nên mất bảo vệ, rồi hệ thống thu hồi RAM) — bản trong
                // bộ nhớ mất, nhưng bản lưu trên đĩa (SharedPreferences) vẫn còn. Đây là
                // nguyên nhân của hiện tượng "thấy thông báo Nén thất bại/xong nhưng mở
                // app ra chả thấy gì" — giờ đọc từ đây như phương án dự phòng.
                CompressService.CompressResultStore.consumePending(applicationContext)?.let { persistedResult ->
                    finishRun(persistedResult)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        DebugLog.log(this, "VideoToolsActivity", "onStop()")
        try { unregisterReceiver(compressReceiver) } catch (e: Exception) { /* chưa đăng ký, bỏ qua */ }
    }

    /**
     * Luồng riêng cho Compress: dò phần cứng NHANH trên 1 đoạn ngắn trước (vài giây,
     * vẫn chạy trên lifecycleScope vì đây là thao tác nhanh) — sau đó GIAO VIỆC NÉN
     * THẬT cho Foreground Service, để tiến trình không bị huỷ khi rời app (đúng lỗi
     * đã gặp: "chuyển app khác thì nén dừng, không báo lỗi, quay lại thấy file hỏng").
     */
    private fun runCompressBatch() {
        // FIX: chặn từ phía UI luôn (không chỉ ở Service) — nếu đã có 1 tác vụ nén
        // đang chạy nền, báo rõ cho người dùng thay vì để họ tưởng nút "Chạy" không
        // phản ứng gì (Service giờ cũng tự chặn ở tầng dưới, xem CompressService,
        // nhưng chặn sớm ở đây giúp người dùng hiểu ngay lý do).
        if (CompressService.CompressResultHolder.isRunning) {
            Toast.makeText(this, "Đang có 1 tác vụ nén khác chạy nền — đợi xong rồi hẵng chạy tiếp.", Toast.LENGTH_LONG).show()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.progressBar.progress = 0
        binding.btnRun.isEnabled = false
        binding.txtResult.text = ""

        // QUYẾT ĐỊNH CẬP NHẬT (08/07/2026): bản đầu phiên này từng đổi mặc định sang
        // CHỈ dùng phần mềm để né vấn đề phình dung lượng — nhưng đó là né tránh, không
        // giải quyết yêu cầu gốc "phải chạy trên đúng chip video engine". Đã tìm ra và
        // sửa ĐÚNG GỐC RỄ trong VideoEngine.compressInternal(): đổi bitrate_mode từ 1
        // (VBR — được phép vượt bitrate mục tiêu ở cảnh phức tạp) sang 2 (CBR — ép cứng
        // bitrate đều suốt video). Giờ PHỤC HỒI phần cứng làm mặc định (đúng yêu cầu ban
        // đầu), phần mềm chỉ là lựa chọn thủ công dự phòng nếu người dùng tự bỏ tick.
        // Có thêm log chẩn đoán so sánh bitrate mục tiêu vs thật đạt được (xem
        // VideoEngine, tìm "[CHẨN ĐOÁN CBR]") để xác nhận CBR có thực sự khắc phục được
        // vấn đề hay chưa — xem qua nút "Xem / Gửi log debug".
        val useHardwareRequested = binding.checkboxUseHardware.isChecked

        lifecycleScope.launch {
            val preset = currentPreset()

            val useHardware = if (useHardwareRequested) {
                binding.txtProgress.text = "Đang kiểm tra khả năng mã hoá phần cứng..."
                val supported = VideoEngine.probeHardwareEncodeSupport(selectedFilePaths.first(), cacheDir)
                if (!supported) {
                    // Người dùng CHỦ ĐỘNG chọn phần cứng nhưng máy không hỗ trợ thật —
                    // đây là bất ngờ, nên vẫn cần hỏi xác nhận trước khi chạy phần mềm
                    // chậm hơn, khác với trường hợp mặc định (họ đã biết trước là chậm).
                    val totalDurationSec = selectedFilePaths.sumOf { FileUtils.getVideoDurationSec(it) }
                    val etaMinutes = (totalDurationSec / SOFTWARE_SPEED_FACTOR / 60).toInt().coerceAtLeast(1)
                    val proceed = confirmSoftwareFallback(etaMinutes)
                    if (!proceed) {
                        binding.progressBar.visibility = View.GONE
                        binding.btnRun.isEnabled = true
                        binding.txtProgress.text = ""
                        binding.txtResult.text = "Đã huỷ — máy không hỗ trợ phần cứng thật sự, chạy phần mềm sẽ mất khoảng $etaMinutes phút."
                        return@launch
                    }
                }
                supported
            } else {
                // Mặc định: phần mềm — người dùng đã biết trước qua checkbox và ước tính
                // dung lượng hiển thị sẵn trên màn hình, không cần hỏi xác nhận lại nữa.
                false
            }

            binding.txtProgress.text = "Đang chạy ở chế độ nền (${if (useHardware) "phần cứng" else "phần mềm"})... có thể rời app, sẽ có thông báo khi xong."
            binding.btnCancelRunning.visibility = View.VISIBLE

            // FIX: ghi lại tên file đang gửi đi nén nền — để nếu Activity bị tạo lại
            // (màn hình tắt/bật, rời app...) và selectedFilePaths bị reset về rỗng,
            // UI vẫn có thể hiện đúng "Đang nén: X" thay vì "Chưa chọn video nào".
            CompressService.CompressResultHolder.runningFileNames = selectedFilePaths.map { File(it).name }

            val serviceIntent = Intent(this@VideoToolsActivity, CompressService::class.java).apply {
                putStringArrayListExtra(CompressService.EXTRA_INPUT_PATHS, ArrayList(selectedFilePaths))
                putExtra(CompressService.EXTRA_PRESET_ORDINAL, preset.ordinal)
                putExtra(CompressService.EXTRA_USE_HARDWARE, useHardware)
            }
            ContextCompat.startForegroundService(this@VideoToolsActivity, serviceIntent)
        }
    }

    private suspend fun confirmSoftwareFallback(etaMinutes: Int): Boolean = kotlinx.coroutines.suspendCancellableCoroutine { cont ->
        AlertDialog.Builder(this)
            .setTitle("Máy không hỗ trợ mã hoá phần cứng")
            .setMessage("Sẽ chạy bằng phần mềm (CPU) — ước tính mất khoảng $etaMinutes phút, có thể làm nóng máy. Bạn có muốn tiếp tục không?")
            .setPositiveButton("Tiếp tục") { _, _ -> cont.resumeWith(Result.success(true)) }
            .setNegativeButton("Huỷ") { _, _ -> cont.resumeWith(Result.success(false)) }
            .setCancelable(false)
            .show()
    }

    /**
     * Hiện toàn bộ nội dung log debug đã ghi (xem `DebugLog.kt`) trong 1 hộp thoại, kèm
     * nút "Chia sẻ" để gửi thẳng qua Messenger/Zalo/Gmail/... — thay thế việc phải chụp
     * màn hình nhiều lần (dễ thiếu thông tin, dễ đoán sai nguyên nhân lỗi).
     */
    private fun showDebugLogDialog() {
        val logContent = DebugLog.readAll(applicationContext)
        AlertDialog.Builder(this)
            .setTitle("Log debug (${logContent.lines().size} dòng)")
            .setMessage(if (logContent.length > 6000) "...(cắt bớt, xem đầy đủ khi Chia sẻ)...\n" + logContent.takeLast(6000) else logContent)
            .setPositiveButton("Chia sẻ") { _, _ ->
                try {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, logContent)
                        putExtra(Intent.EXTRA_SUBJECT, "VideoAIStudio debug log")
                    }
                    startActivity(Intent.createChooser(shareIntent, "Gửi log debug"))
                } catch (e: Exception) {
                    Toast.makeText(this, "Không chia sẻ được: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNeutralButton("Xoá log") { _, _ ->
                DebugLog.clear(applicationContext)
                Toast.makeText(this, "Đã xoá log debug", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun finishRun(result: VideoOpResult) {
        binding.progressBar.visibility = View.GONE
        binding.btnRun.isEnabled = true
        binding.txtProgress.text = ""

        // FIX QUAN TRỌNG: trước đây khi result.success == true, result.log bị BỎ QUA
        // HOÀN TOÀN dù VideoEngine.compressWithKnownBackend có thể trả về success=true
        // KÈM cảnh báo "CẢNH BÁO: dung lượng sau nén không nhỏ hơn đáng kể so với gốc"
        // (trường hợp cả 2 đường phần cứng lẫn phần mềm đều không nén nhỏ đi được).
        // Vì UI chỉ hiện "Thành công!" nên người dùng không hề biết file gần như không
        // đổi dung lượng — đúng hiện tượng "chọn nén Vừa nhưng không có bất kỳ thay đổi
        // nào" mà không thấy báo lỗi gì. Giờ luôn hiện cảnh báo nếu log có chứa nó.
        val hasWarning = result.success && result.log.contains("CẢNH BÁO", ignoreCase = true)
        binding.txtResult.text = when {
            !result.success -> "Thất bại:\n${result.log}"
            hasWarning -> "Hoàn tất, NHƯNG CÓ CẢNH BÁO:\n${result.log}\n\nFile lưu tại:\n" + result.outputPaths.joinToString("\n")
            else -> "Thành công!\nFile lưu tại:\n" + result.outputPaths.joinToString("\n")
        }

        if (result.success && result.outputPaths.size == 1) {
            lastSingleOutputPath = result.outputPaths.first()
            binding.btnSaveAs.visibility = View.VISIBLE
            lastMultiOutputPaths = null
            binding.btnSaveAllAs.visibility = View.GONE
        } else if (result.success && result.outputPaths.size > 1) {
            // FIX: trước đây nhánh này chỉ hiện dòng disclaimer "chưa hỗ trợ Lưu vào tuỳ
            // chọn cho nhiều file" — đây chính là "lỗi lưu file" người dùng gặp khi tách
            // audio ra nhiều đoạn: file chỉ nằm trong thư mục riêng của app
            // (Android/data/com.videoaistudio.app/...), không có cách nào đưa ra ngoài.
            // Giờ hiện nút "Lưu TẤT CẢ file vào 1 thư mục..." để copy hết ra vị trí do
            // người dùng chọn (xem saveAllAsLauncher).
            lastSingleOutputPath = null
            binding.btnSaveAs.visibility = View.GONE
            lastMultiOutputPaths = result.outputPaths
            binding.btnSaveAllAs.visibility = View.VISIBLE
        } else {
            lastSingleOutputPath = null
            binding.btnSaveAs.visibility = View.GONE
            lastMultiOutputPaths = null
            binding.btnSaveAllAs.visibility = View.GONE
        }
    }

    /**
     * Parse "start,end" mỗi dòng thành cặp (giây, giây).
     *
     * FIX: chịu được trường hợp người dùng tự gõ tay số thập phân bằng DẤU PHẨY
     * (thói quen bàn phím tiếng Việt, vd "10,5,20,3" nghĩa là 10.5 và 20.3) thay vì
     * dùng nút "Thêm đoạn đã chọn" (nút đó đã ép Locale.US ra dấu chấm, xem
     * addSelectedRangeToList). Trước đây parts.size != 2 thì BỎ QUA CẢ DÒNG một cách
     * im lặng — khiến segments trống rỗng và app coi như "không chọn đoạn", dẫn tới
     * lấy nhầm toàn bộ video/audio. Giờ nếu tách theo dấu chấm ra đúng 2 phần thì dùng
     * luôn (chuẩn); nếu không, thử lại coi dấu phẩy đầu tiên trong mỗi số là thập phân.
     */
    private fun parseSegments(raw: String): List<Pair<Double, Double>> {
        return raw.lines()
            .mapNotNull { line ->
                val trimmedLine = line.trim()
                if (trimmedLine.isBlank()) return@mapNotNull null

                // Thử chuẩn trước: đúng 2 phần, mỗi phần là số hợp lệ (dấu chấm thập phân).
                val standardParts = trimmedLine.split(",")
                if (standardParts.size == 2) {
                    val start = standardParts[0].trim().toDoubleOrNull()
                    val end = standardParts[1].trim().toDoubleOrNull()
                    if (start != null && end != null && end > start) return@mapNotNull start to end
                }

                // Rớt về đây nghĩa là split(",") không cho đúng 2 số hợp lệ — khả năng cao
                // là số thập phân dùng dấu phẩy (vd 4 phần "10,5,20,3"). Thử ghép lại theo
                // quy tắc: có đúng 4 phần và tất cả đều là số nguyên -> ghép phần 1-2 thành
                // 1 số thập phân (start), phần 3-4 thành 1 số thập phân (end).
                if (standardParts.size == 4 && standardParts.all { it.trim().toIntOrNull() != null }) {
                    val start = "${standardParts[0].trim()}.${standardParts[1].trim()}".toDoubleOrNull()
                    val end = "${standardParts[2].trim()}.${standardParts[3].trim()}".toDoubleOrNull()
                    if (start != null && end != null && end > start) return@mapNotNull start to end
                }

                null
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
        FileUtils.clearVideoInputCache(applicationContext)
    }

    companion object {
        const val EXTRA_MODE = "extra_mode"
        // Tốc độ mã hoá phần mềm quan sát được thực tế (speed=0.3x trong log FFmpeg
        // của chính người dùng) — dùng để ước tính thời gian trước khi chạy.
        private const val SOFTWARE_SPEED_FACTOR = 0.3
    }
}
