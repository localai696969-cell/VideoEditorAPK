package com.videoaistudio.app.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.DragEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.videoaistudio.app.databinding.ActivityVideoToolsBinding
import com.videoaistudio.app.debug.DebugLog
import com.videoaistudio.app.video.CompressService
import com.videoaistudio.app.video.FileUtils
import com.videoaistudio.app.video.VideoEngine
import com.videoaistudio.app.video.VideoOpResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class VideoToolMode(val label: String) {
    TRIM_SPLIT("Cắt / Tách video"),
    REMOVE_MIDDLE("Xoá đoạn giữa, ghép phần còn lại"),
    MERGE("Ghép video"),
    EXTRACT_AUDIO("Tách âm thanh"),
    COMPRESS("Nén dung lượng");

    override fun toString(): String = label
}

/**
 * Màn hình gộp Trim/Cut + Split thành 1, cộng Merge/Extract Audio/Compress.
 * Trim/Split có preview video thật (Media3 ExoPlayer) + RangeSlider để chọn đoạn
 * trực quan, kèm ô nhập giờ:phút:giây cho video dài (dễ theo dõi hơn số giây thô).
 */
class VideoToolsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideoToolsBinding
    private val selectedFilePaths = mutableListOf<String>()
    private var currentMode: VideoToolMode = VideoToolMode.TRIM_SPLIT
    private var player: ExoPlayer? = null
    private var videoDurationSec: Float = 100f

    private val pickSingleVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { importUri(it) }
    }

    private val pickMultipleVideos = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        uris.forEach { importUri(it) }
    }

    private var lastSingleOutputPath: String? = null
    private var lastMultiOutputPaths: List<String>? = null

    private val saveAsLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? ->
        uri?.let { destUri ->
            val sourcePath = lastSingleOutputPath ?: return@let
            try {
                contentResolver.openOutputStream(destUri)?.use { out ->
                    File(sourcePath).inputStream().use { input -> input.copyTo(out) }
                }
                // Hỏi có muốn xoá bản trong app không, tránh chiếm gấp đôi dung lượng
                AlertDialog.Builder(this)
                    .setTitle("Đã lưu thành công")
                    .setMessage("File đã được lưu vào vị trí bạn chọn. Xoá bản sao trong bộ nhớ app để tránh chiếm gấp đôi dung lượng?")
                    .setPositiveButton("Xoá bản trong app") { _, _ ->
                        File(sourcePath).delete()
                        binding.btnSaveAs.visibility = View.GONE
                        Toast.makeText(this, "Đã xoá bản trong app", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Giữ cả 2 bản", null)
                    .show()
            } catch (e: Exception) {
                Toast.makeText(this, "Lưu thất bại: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * FIX: trước đây khi có NHIỀU file kết quả (vd tách audio nhiều đoạn), app chỉ
     * lưu chúng trong thư mục riêng của app (Android/data/com.videoaistudio.app/...)
     * và không có cách nào để người dùng chuyển chúng ra vị trí công khai (Tải xuống,
     * Nhạc, thư mục tự chọn...) — nếu gỡ app, xoá cache, hoặc dùng trình quản lý file
     * không thấy được thư mục "Android/data" (bị Android giới hạn từ Android 11), coi
     * như MẤT file. Đây chính là "lỗi lưu file" khi tách được nhiều đoạn audio.
     *
     * Dùng ACTION_OPEN_DOCUMENT_TREE để người dùng chọn 1 thư mục (vd Tải xuống, hoặc
     * tự tạo thư mục mới), rồi copy TOÀN BỘ các file kết quả vào đó bằng DocumentFile.
     */
    private val saveAllAsLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri: Uri? ->
        treeUri?.let { uri ->
            val paths = lastMultiOutputPaths ?: return@let
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            val destTree = androidx.documentfile.provider.DocumentFile.fromTreeUri(this, uri)
            if (destTree == null) {
                Toast.makeText(this, "Không mở được thư mục đã chọn.", Toast.LENGTH_LONG).show()
                return@let
            }
            var savedCount = 0
            var failedCount = 0
            for (path in paths) {
                try {
                    val srcFile = File(path)
                    val mime = contentResolver.let { android.webkit.MimeTypeMap.getSingleton() }
                        .getMimeTypeFromExtension(srcFile.extension) ?: "application/octet-stream"
                    val destDoc = destTree.createFile(mime, srcFile.name)
                    if (destDoc != null) {
                        contentResolver.openOutputStream(destDoc.uri)?.use { out ->
                            srcFile.inputStream().use { input -> input.copyTo(out) }
                        }
                        savedCount++
                    } else {
                        failedCount++
                    }
                } catch (e: Exception) {
                    failedCount++
                }
            }
            val summary = if (failedCount == 0) {
                "Đã lưu $savedCount/$savedCount file vào thư mục đã chọn."
            } else {
                "Đã lưu $savedCount file, LỖI $failedCount file — thử lại nếu cần."
            }
            AlertDialog.Builder(this)
                .setTitle("Kết quả lưu")
                .setMessage("$summary\n\nXoá các bản sao trong bộ nhớ app để tránh chiếm gấp đôi dung lượng?")
                .setPositiveButton("Xoá bản trong app") { _, _ ->
                    paths.forEach { File(it).delete() }
                    binding.btnSaveAllAs.visibility = View.GONE
                    Toast.makeText(this, "Đã xoá bản trong app", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Giữ cả 2 bản", null)
                .show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLog.log(this, "VideoToolsActivity", "onCreate() — Activity instance MỚI được tạo (savedInstanceState=${savedInstanceState != null})")
        binding = ActivityVideoToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val requestedModeName = intent.getStringExtra(EXTRA_MODE)
        currentMode = VideoToolMode.values().firstOrNull { it.name == requestedModeName } ?: VideoToolMode.TRIM_SPLIT

        FileUtils.clearVideoInputCache(applicationContext)

        binding.spinnerMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, VideoToolMode.values())
        binding.spinnerMode.setSelection(VideoToolMode.values().indexOf(currentMode))
        binding.spinnerMode.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentMode = VideoToolMode.values()[position]
                onModeChanged()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        binding.spinnerCompressPreset.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Nhẹ (nén nhiều, nhỏ nhất)", "Vừa (cân bằng)", "Nét (nén ít, giữ chất lượng)")
        )
        binding.spinnerCompressPreset.setSelection(1) // mặc định "Vừa"
        binding.spinnerCompressPreset.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = updateCompressEstimate()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        binding.btnPickVideo.setOnClickListener {
            selectedFilePaths.clear()
            updateSelectedFilesText()
            if (currentMode == VideoToolMode.MERGE || currentMode == VideoToolMode.COMPRESS) {
                pickMultipleVideos.launch(arrayOf("video/*"))
            } else {
                pickSingleVideo.launch(arrayOf("video/*"))
            }
        }

        binding.btnAddMoreVideo.setOnClickListener {
            pickMultipleVideos.launch(arrayOf("video/*"))
        }

        binding.btnAddSelectedRange.setOnClickListener { addSelectedRangeToList() }
        binding.btnRun.setOnClickListener { runCurrentAction() }
        binding.btnViewDebugLog.setOnClickListener { showDebugLogDialog() }
        binding.btnCancelRunning.setOnClickListener {
            val cancelled = VideoEngine.cancelCurrentSession()
            if (cancelled) {
                Toast.makeText(this, "Đã gửi yêu cầu huỷ — chờ vài giây để dừng hẳn.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Không có tác vụ nào đang chạy để huỷ.", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnSaveAs.setOnClickListener {
            val path = lastSingleOutputPath ?: return@setOnClickListener
            saveAsLauncher.launch(File(path).name)
        }
        binding.btnSaveAllAs.setOnClickListener {
            saveAllAsLauncher.launch(null)
        }

        setupDragAndDrop()

        onModeChanged()
    }

    /**
     * Cho phép kéo file trực tiếp từ File Manager (chế độ chia đôi màn hình / cửa sổ
     * thu nhỏ — Android multi-window drag-and-drop) thả thẳng vào màn hình này, THAY
     * VÌ bắt buộc phải bấm nút "Chọn video" rồi duyệt thư mục thủ công trước. Gắn vào
     * `binding.root` (toàn màn hình) để thả ở bất kỳ chỗ nào cũng nhận được, không
     * cần nhắm chính xác vào 1 nút nhỏ.
     *
     * Tái sử dụng đúng `importUri()` đã có sẵn (dùng chung với luồng bấm nút chọn
     * file) — nhờ vậy hành vi sau khi thả (copy vào cache, cập nhật danh sách, load
     * preview...) giống hệt như chọn file qua nút bấm, không viết logic riêng dễ lệch.
     */
    private fun setupDragAndDrop() {
        val originalBackground = binding.root.background
        binding.root.setOnDragListener { view, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> {
                    // Chấp nhận rộng rãi, không lọc gắt theo MIME "video/*" ở bước này
                    // — nhiều app File Manager không luôn khai báo đúng MIME khi bắt
                    // đầu kéo. Định dạng sai sẽ tự bị ExoPlayer/FFmpeg báo lỗi ở bước xử
                    // lý sau, không cần chặn sớm ở đây.
                    true
                }
                DragEvent.ACTION_DRAG_ENTERED -> {
                    view.setBackgroundColor(0x332196F3) // xanh dương mờ — gợi ý đang ở đúng vùng thả
                    true
                }
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> {
                    view.background = originalBackground
                    true
                }
                DragEvent.ACTION_DROP -> {
                    view.background = originalBackground
                    val clipData = event.clipData
                    if (clipData == null || clipData.itemCount == 0) {
                        Toast.makeText(this, "Không nhận được file từ thao tác kéo-thả", Toast.LENGTH_SHORT).show()
                        return@setOnDragListener true
                    }
                    // BẮT BUỘC xin quyền đọc URI đến từ app khác qua kéo-thả — khác với
                    // URI trả về từ file picker (OpenDocument) vốn đã tự động có quyền,
                    // URI từ kéo-thả liên-app cần xin quyền tường minh kiểu này, nếu
                    // không đọc file sẽ bị SecurityException.
                    val permissions = requestDragAndDropPermissions(event)
                    val isMultiMode = currentMode == VideoToolMode.MERGE || currentMode == VideoToolMode.COMPRESS
                    if (!isMultiMode) {
                        // Chế độ chỉ nhận 1 file: thả file mới = THAY THẾ file đang chọn,
                        // giống hệt hành vi nút "Chọn video" (không phải "Thêm video").
                        selectedFilePaths.clear()
                        updateSelectedFilesText()
                    }
                    var addedCount = 0
                    for (i in 0 until clipData.itemCount) {
                        if (!isMultiMode && addedCount >= 1) break // chế độ 1 file: chỉ lấy file đầu tiên nếu lỡ kéo nhiều file cùng lúc
                        val uri = clipData.getItemAt(i).uri ?: continue
                        importUri(uri)
                        addedCount++
                    }
                    permissions?.release()
                    if (addedCount > 0) {
                        Toast.makeText(this, "Đã thêm $addedCount file từ kéo-thả", Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun currentPreset(): VideoEngine.CompressPreset = when (binding.spinnerCompressPreset.selectedItemPosition) {
        0 -> VideoEngine.CompressPreset.NHE
        2 -> VideoEngine.CompressPreset.NET
        else -> VideoEngine.CompressPreset.VUA
    }

    private fun updateCompressEstimate() {
        if (selectedFilePaths.isEmpty()) {
            binding.txtCompressEstimate.text = "Chọn video để xem ước tính dung lượng"
            return
        }
        val preset = currentPreset()
        var totalOriginal = 0L
        var totalEstimated = 0L
        var validCount = 0
        for (path in selectedFilePaths) {
            val originalBitrate = FileUtils.calculateActualBitrateBps(path)
            val durationSec = FileUtils.getVideoDurationSec(path)
            if (originalBitrate <= 0 || durationSec <= 0) continue
            validCount++
            totalOriginal += File(path).length()
            val estimatedBitrate = (originalBitrate * preset.bitrateMultiplier).toLong()
            totalEstimated += (estimatedBitrate * durationSec / 8).toLong()
        }
        binding.txtCompressEstimate.text = if (validCount == 0) {
            "Không đọc được thông tin video để ước tính"
        } else {
            val prefix = if (selectedFilePaths.size > 1) "Tổng ${selectedFilePaths.size} file — " else ""
            "${prefix}Dung lượng gốc: ${FileUtils.formatBytes(totalOriginal)} → Ước tính sau nén: ~${FileUtils.formatBytes(totalEstimated)}"
        }
    }

    private fun importUri(uri: Uri) {
        try {
            val name = FileUtils.queryDisplayName(this, uri)
            val file = FileUtils.copyUriToCache(this, uri, name)
            selectedFilePaths.add(file.absolutePath)
            updateSelectedFilesText()

            if ((currentMode == VideoToolMode.TRIM_SPLIT || currentMode == VideoToolMode.EXTRACT_AUDIO || currentMode == VideoToolMode.REMOVE_MIDDLE) && selectedFilePaths.size == 1) {
                loadPreview(file)
            }
            if (currentMode == VideoToolMode.COMPRESS) updateCompressEstimate()
        } catch (e: Exception) {
            Toast.makeText(this, "Không đọc được file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Định dạng giây -> "H:MM:SS" để dễ theo dõi với video dài. */
    private fun secondsToHms(totalSec: Float): String {
        val total = totalSec.toInt()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    /** Đọc "H:MM:SS" hoặc "MM:SS" hoặc chỉ số giây -> tổng số giây (float). Trả null nếu sai định dạng. */
    private fun hmsToSeconds(text: String): Float? {
        val parts = text.trim().split(":")
        return try {
            when (parts.size) {
                1 -> parts[0].toFloat()
                2 -> parts[0].toInt() * 60f + parts[1].toFloat()
                3 -> parts[0].toInt() * 3600f + parts[1].toInt() * 60f + parts[2].toFloat()
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Nạp video vào player xem trước + đọc thời lượng thật để đặt giới hạn RangeSlider. */
    private fun loadPreview(file: File) {
        releasePlayer()

        try {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(file.absolutePath)
                val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                videoDurationSec = (durationMs / 1000f).coerceAtLeast(1f)
            } finally {
                retriever.release()
            }

            binding.rangeSlider.valueFrom = 0f
            binding.rangeSlider.valueTo = videoDurationSec
            binding.rangeSlider.values = listOf(0f, videoDurationSec)
            binding.txtRangeLabel.text = "Kéo 2 đầu để chọn đoạn (0:00 - ${secondsToHms(videoDurationSec)})"
            binding.edtStartSec.setText(secondsToHms(0f))
            binding.edtEndSec.setText(secondsToHms(videoDurationSec))

            val exoPlayer = ExoPlayer.Builder(this).build()
            // FIX QUAN TRỌNG (báo qua chat): "kéo slider thì frame KHÔNG di chuyển, thả
            // tay ra mới nhảy tới đúng chỗ". Nguyên nhân THẬT: RangeSlider bắn sự kiện
            // addOnChangeListener RẤT NHIỀU LẦN trong 1 lần kéo (gần như mỗi pixel di
            // chuyển), và trước đây mỗi lần đều gọi thẳng exoPlayer.seekTo() mới. ExoPlayer
            // huỷ seek đang xử lý dở để nhận seek mới mỗi khi seekTo() được gọi lại — nên
            // nếu tốc độ gọi nhanh hơn tốc độ decode+render 1 khung hình (rất dễ xảy ra khi
            // kéo nhanh), KHÔNG có khung hình nào kịp hiển thị cho tới khi luồng seekTo dồn
            // dập này dừng lại (tức là tới khi thả tay) — đúng y hệt triệu chứng báo.
            // Đây là hạn chế đã tồn tại từ trước (không phải do các fix trước đó gây ra),
            // chỉ là chưa từng bị lộ ra vì trước giờ chưa test thật trên máy — bản ghi cũ
            // trong tài liệu chỉ xác nhận ĐÚNG LOGIC CODE (seekTo dùng đúng giá trị thumb
            // đang kéo, không hardcode values.last()), CHƯA từng xác nhận mượt thật trên
            // máy.
            //
            // Cách sửa: chỉ cho phép TỐI ĐA 1 lệnh seek đang "bay" tới player tại 1 thời
            // điểm. Nếu có yêu cầu seek mới tới trong lúc đang chờ, chỉ NHỚ vị trí mới nhất
            // (đè lên vị trí cũ, không xếp hàng đợi từng cái) — rồi khi ExoPlayer báo đã
            // xong seek hiện tại (onPositionDiscontinuity, reason = SEEK), mới bắn tiếp
            // đúng 1 lệnh seek tới vị trí mới nhất đó. Nhờ vậy player luôn bận rộn decode
            // ra hình càng nhanh càng tốt, và LUÔN hội tụ về đúng vị trí ngón tay đang ở,
            // thay vì bị chôn dưới hàng chục lệnh seek đến vị trí đã cũ.
            var seekInFlight = false
            var pendingSeekMs: Long? = null
            val seekWatchdogHandler = android.os.Handler(android.os.Looper.getMainLooper())
            // VAN AN TOÀN — LỖI ĐÃ TỪNG XẢY RA Ở CHÍNH BẢN SỬA TRƯỚC ĐÓ TRONG PHIÊN NÀY:
            // onPositionDiscontinuity(reason=SEEK) KHÔNG được ExoPlayer đảm bảo bắn ra cho
            // MỌI lệnh seekTo() — ví dụ khi vị trí seek tới rất gần vị trí hiện tại, có thể
            // không có discontinuity nào được xem là xảy ra. Nếu thiếu van an toàn này, 1
            // lần "im lặng" như vậy sẽ làm seekInFlight kẹt ở true MÃI MÃI — mọi lệnh kéo
            // sau đó chỉ ghi đè pendingSeekMs mà KHÔNG BAO GIỜ thực sự gọi seekTo() nữa =
            // đứng hình hẳn, kể cả sau khi thả tay (còn tệ hơn triệu chứng gốc). Van này tự
            // giải phóng sau 350ms không thấy ExoPlayer phản hồi, đảm bảo cơ chế không bao
            // giờ bị kẹt vĩnh viễn dù onPositionDiscontinuity có bắn ra hay không.
            val seekWatchdogRunnable = object : Runnable {
                override fun run() {
                    if (!seekInFlight) return
                    val next = pendingSeekMs
                    pendingSeekMs = null
                    if (next != null) {
                        try {
                            exoPlayer.seekTo(next)
                            seekWatchdogHandler.postDelayed(this, 350)
                        } catch (e: Exception) {
                            seekInFlight = false
                        }
                    } else {
                        seekInFlight = false
                    }
                }
            }
            fun scrubToPosition(targetMs: Long) {
                if (seekInFlight) {
                    pendingSeekMs = targetMs
                } else {
                    seekInFlight = true
                    try {
                        exoPlayer.seekTo(targetMs)
                        seekWatchdogHandler.removeCallbacks(seekWatchdogRunnable)
                        seekWatchdogHandler.postDelayed(seekWatchdogRunnable, 350)
                    } catch (e: Exception) {
                        seekInFlight = false
                    }
                }
            }
            exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    Toast.makeText(
                        this@VideoToolsActivity,
                        "Không xem trước được video này (có thể do định dạng/codec lạ), nhưng vẫn có thể nhập giờ:phút:giây để xử lý.",
                        Toast.LENGTH_LONG
                    ).show()
                }

                override fun onPositionDiscontinuity(
                    oldPosition: androidx.media3.common.Player.PositionInfo,
                    newPosition: androidx.media3.common.Player.PositionInfo,
                    reason: Int
                ) {
                    if (reason != androidx.media3.common.Player.DISCONTINUITY_REASON_SEEK) return
                    seekWatchdogHandler.removeCallbacks(seekWatchdogRunnable) // đã có phản hồi thật -> không cần van an toàn nữa cho lệnh này
                    val next = pendingSeekMs
                    if (next != null) {
                        pendingSeekMs = null
                        try {
                            exoPlayer.seekTo(next) // seekInFlight vẫn true — nối tiếp luôn, không cần đặt lại
                            seekWatchdogHandler.postDelayed(seekWatchdogRunnable, 350)
                        } catch (e: Exception) {
                            seekInFlight = false
                        }
                    } else {
                        seekInFlight = false
                    }
                }
            })
            exoPlayer.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            exoPlayer.playWhenReady = false
            exoPlayer.prepare()
            // [SỬA 02/09/2026] BỎ HẲN controller mặc định của Media3 (use_controller=false
            // trong layout) — controller đó đi kèm 1 thanh tiến độ (TimeBar) nội bộ của
            // Media3 mà mình KHÔNG kiểm soát được: rất có thể dính đúng lỗi "spam seekTo()
            // khi kéo" y hệt RangeSlider từng bị (người dùng báo "thanh tiến độ trong khung
            // preview không phản ứng khi kéo"), nhưng vì là code nội bộ Media3 nên không áp
            // được bản sửa hàng-đợi-seek (scrubToPosition/watchdog) vào đó như đã làm với
            // RangeSlider. Thay vào đó: tự làm 1 nút play/pause riêng (`btnPlayPause`, ảnh
            // hệ thống Android có sẵn, không cần drawable riêng) — bấm vào khung preview để
            // hiện/ẩn nút, bấm vào nút để play/pause thật. Không có thanh tiến độ nào khác
            // ngoài RangeSlider — chỉ 1 chỗ kéo-thả duy nhất, đã hardening kỹ.
            binding.playerView.player = exoPlayer
            player = exoPlayer

            fun updatePlayPauseIcon() {
                binding.btnPlayPause.setImageResource(
                    if (exoPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            }
            exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { updatePlayPauseIcon() }
            })
            binding.playerView.setOnClickListener {
                // Bấm vào khung preview -> hiện/ẩn nút play/pause (giống hành vi controller
                // mặc định trước đây: bấm vào preview mới thấy nút, bấm ra ngoài thì ẩn).
                binding.btnPlayPause.visibility =
                    if (binding.btnPlayPause.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                if (binding.btnPlayPause.visibility == View.VISIBLE) updatePlayPauseIcon()
            }
            binding.btnPlayPause.setOnClickListener {
                try {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
            }

            var syncingFromCode = false

            binding.rangeSlider.addOnChangeListener { slider, value, fromUser ->
                if (syncingFromCode) return@addOnChangeListener
                val values = slider.values
                if (values.size >= 2) {
                    syncingFromCode = true
                    binding.edtStartSec.setText(secondsToHms(values.first()))
                    binding.edtEndSec.setText(secondsToHms(values.last()))
                    syncingFromCode = false
                    if (fromUser) {
                        try {
                            // Tua tới đúng vị trí của NÚT VỪA KÉO (value), không phải luôn
                            // luôn tua tới điểm cuối — đây là lỗi khiến kéo nút đầu không
                            // xem trước được, chỉ kéo nút sau mới thấy hình.
                            // Dùng scrubToPosition() thay vì gọi seekTo() thẳng — xem giải
                            // thích chi tiết ở chỗ khai báo hàm này (phía trên).
                            scrubToPosition((value * 1000).toLong())
                            // Seek này đến từ NGOÀI khung preview (kéo slider) -> đảm bảo
                            // nút play/pause đang ẩn, không che khung hình.
                            binding.btnPlayPause.visibility = View.GONE
                        } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                    }
                }
            }

            // QUAN TRỌNG: khi cắt bằng "-c copy" (không encode lại), FFmpeg BẮT BUỘC bắt
            // đầu file output đúng tại 1 khung hình khoá — không thể cắt giữa chừng vì
            // không giải mã lại được. Trong lúc kéo, preview tua chính xác tới đúng giây
            // bạn thả tay, NHƯNG video output thật có thể lùi về khung hình khoá gần nhất
            // trước đó -> đây là nguyên nhân số giây/preview "khớp lúc xem nhưng ra file
            // lại lệch". Để loại bỏ hẳn sự lệch này: ngay khi THẢ TAY khỏi slider, làm
            // tròn điểm bắt đầu về ĐÚNG khung hình khoá đó luôn (cùng cơ chế FFmpeg dùng
            // bên trong) — từ lúc này, số giây + khung hình xem trước hiển thị chính là
            // những gì sẽ có trong file output, không còn khác biệt.
            binding.rangeSlider.addOnSliderTouchListener(object :
                com.google.android.material.slider.RangeSlider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: com.google.android.material.slider.RangeSlider) {}
                override fun onStopTrackingTouch(slider: com.google.android.material.slider.RangeSlider) {
                    val values = slider.values
                    if (values.size < 2) return
                    val requestedStart = values.first().toDouble()
                    val currentEnd = values.last()
                    val safeMax = (currentEnd - 0.1f).coerceAtLeast(slider.valueFrom)
                    // LỖI ĐÃ SỬA (báo qua chat): "kéo thì đồng bộ mượt, nhưng THẢ TAY RA
                    // thì khựng 1 nhịp rồi frame mới nhảy tới chỗ kéo". Nguyên nhân: gọi
                    // findPrecedingKeyframeSec() (MediaExtractor đọc file) TRỰC TIẾP trên
                    // main thread ngay trong callback này — thao tác đọc file có thể mất
                    // vài chục-vài trăm ms, đủ để đứng hình UI đúng lúc thả tay. Phần kéo
                    // mượt lúc đang rê tay (addOnChangeListener ở trên) KHÔNG bị ảnh hưởng
                    // vì không đụng tới đoạn đó — chỉ đúng khoảnh khắc thả tay bị khựng do
                    // lệnh đọc file này. Sửa: đẩy việc đọc file ra thread nền (IO), chỉ
                    // quay lại main thread để cập nhật UI/seek sau khi có kết quả.
                    lifecycleScope.launch {
                        val snappedStart = withContext(Dispatchers.IO) {
                            FileUtils.findPrecedingKeyframeSec(file.absolutePath, requestedStart)
                        }.toFloat().coerceIn(slider.valueFrom, safeMax)
                        if (kotlin.math.abs(snappedStart - requestedStart.toFloat()) > 0.03f) {
                            syncingFromCode = true
                            slider.values = listOf(snappedStart, currentEnd)
                            binding.edtStartSec.setText(secondsToHms(snappedStart))
                            syncingFromCode = false
                            try {
                                scrubToPosition((snappedStart * 1000).toLong())
                                binding.btnPlayPause.visibility = View.GONE
                            } catch (e: Exception) { /* bỏ qua nếu player chưa sẵn sàng */ }
                        }
                    }
                }
            })

            val textWatcher = object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) {
                    if (syncingFromCode) return
                    val start = hmsToSeconds(binding.edtStartSec.text.toString()) ?: return
                    val end = hmsToSeconds(binding.edtEndSec.text.toString()) ?: return
                    // Ép giới hạn an toàn trong [valueFrom, valueTo] — RangeSlider sẽ
                    // âm thầm bỏ qua (không di chuyển) nếu giá trị nằm ngoài khoảng
                    // hoặc start >= end, đây là nguyên nhân "gõ số nhưng slider không nhích".
                    val safeStart = start.coerceIn(0f, videoDurationSec)
                    val safeEnd = end.coerceIn(0f, videoDurationSec)
                    if (safeStart >= safeEnd) return
                    syncingFromCode = true
                    try {
                        binding.rangeSlider.values = listOf(safeStart, safeEnd)
                        binding.rangeSlider.invalidate()
                    } catch (e: Exception) { /* giá trị tạm thời không hợp lệ khi đang gõ dở, bỏ qua */ }
                    syncingFromCode = false
                }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            }
            binding.edtStartSec.addTextChangedListener(textWatcher)
            binding.edtEndSec.addTextChangedListener(textWatcher)
        } catch (e: Exception) {
            Toast.makeText(this, "Không nạp được video xem trước: ${e.message}. Vẫn có thể nhập giờ:phút:giây thủ công.", Toast.LENGTH_LONG).show()
        }
    }

    private fun addSelectedRangeToList() {
        val values = binding.rangeSlider.values
        if (values.size < 2) return
        val end = values.last()
        val requestedStart = values.first().toDouble()
        val currentFile = selectedFilePaths.firstOrNull()
        // Làm tròn lần cuối về khung hình khoá gần nhất trước khi ghi vào danh sách —
        // phòng trường hợp giá trị đang có chưa được làm tròn (vd người dùng gõ tay số
        // giây rồi bấm "Thêm đoạn" luôn, chưa từng chạm/thả slider để kích hoạt làm tròn
        // ở addOnSliderTouchListener). Nhờ vậy con số ghi vào danh sách LUÔN khớp đúng
        // với điểm bắt đầu thật của file output (xem giải thích chi tiết ở loadPreview()).
        // Đọc file (MediaExtractor) tốn thời gian -> đẩy ra thread nền, tránh khựng UI
        // ngay lúc bấm nút (cùng nguyên nhân/cách sửa như addOnSliderTouchListener).
        lifecycleScope.launch {
            val start = if (currentFile != null) {
                withContext(Dispatchers.IO) {
                    FileUtils.findPrecedingKeyframeSec(currentFile, requestedStart)
                }.toFloat()
            } else requestedStart.toFloat()
            val currentText = binding.edtSegments.text.toString()
            // Vẫn lưu nội bộ theo giây (để lệnh FFmpeg dùng), chỉ hiển thị cho người dùng theo giờ:phút:giây
            // FIX QUAN TRỌNG: "%.1f".format() không có Locale sẽ dùng Locale mặc định của máy.
            // Ở Locale Tiếng Việt (vi_VN), dấu thập phân là DẤU PHẨY (vd 10.5 -> "10,5"), khiến
            // dòng ghi ra thành "10,5,20,3" thay vì "10.5,20.3" — dấu "," ngăn cách giây bị LẪN
            // với dấu "," thập phân. parseSegments() tách theo "," sẽ ra 4 phần thay vì 2, dòng
            // bị coi là KHÔNG HỢP LỆ và bị bỏ qua -> segments rỗng -> app tưởng người dùng
            // "không chọn đoạn nào" -> tự động tách/lấy audio TOÀN BỘ video dù đã chọn đoạn.
            // Đây chính là nguyên nhân lỗi "lấy audio toàn bộ video khi chỉ muốn lấy vài đoạn"
            // trên máy để Locale Tiếng Việt. Ép Locale.US để luôn ra dấu chấm.
            val newLine = "${"%.1f".format(java.util.Locale.US, start)},${"%.1f".format(java.util.Locale.US, end)}"
            binding.edtSegments.setText(if (currentText.isBlank()) newLine else "$currentText\n$newLine")
        }
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }

    private fun updateSelectedFilesText() {
        binding.txtSelectedFiles.text = if (selectedFilePaths.isEmpty()) {
            "Chưa chọn video nào"
        } else {
            "Đã chọn ${selectedFilePaths.size} file (bấm 'Xoá' nếu chọn nhầm):"
        }

        binding.containerFileList.removeAllViews()
        for (path in selectedFilePaths.toList()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = 4 }
            }
            val nameView = TextView(this).apply {
                text = path.substringAfterLast("/")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(0, 8, 8, 8)
            }
            val removeBtn = Button(this).apply {
                text = "Xoá"
                setOnClickListener {
                    selectedFilePaths.remove(path)
                    updateSelectedFilesText()
                    if (currentMode == VideoToolMode.COMPRESS) updateCompressEstimate()
                    if (selectedFilePaths.isEmpty()) releasePlayer()
                }
            }
            row.addView(nameView)
            row.addView(removeBtn)
            binding.containerFileList.addView(row)
        }
    }

    private fun onModeChanged() {
        val showTrimGroup = currentMode == VideoToolMode.TRIM_SPLIT || currentMode == VideoToolMode.EXTRACT_AUDIO || currentMode == VideoToolMode.REMOVE_MIDDLE
        binding.groupTrimSplit.visibility = if (showTrimGroup) View.VISIBLE else View.GONE
        binding.groupCompress.visibility = if (currentMode == VideoToolMode.COMPRESS) View.VISIBLE else View.GONE
        binding.btnAddMoreVideo.visibility = if (currentMode == VideoToolMode.MERGE || currentMode == VideoToolMode.COMPRESS) View.VISIBLE else View.GONE
        binding.txtResult.text = ""
        binding.txtProgress.text = ""
        binding.btnSaveAs.visibility = View.GONE
        binding.btnSaveAllAs.visibility = View.GONE
        if (!showTrimGroup) releasePlayer()
        if (currentMode == VideoToolMode.COMPRESS) updateCompressEstimate()
        binding.edtSegments.hint = if (currentMode == VideoToolMode.REMOVE_MIDDLE)
            "Đoạn muốn XOÁ (bắt_đầu,kết_thúc theo giây)" else "0,30\n30,90"
        binding.txtSegmentsHelp.text = when (currentMode) {
            VideoToolMode.REMOVE_MIDDLE -> "Đoạn nhập vào sẽ bị XOÁ khỏi video, 2 phần còn lại (đầu + cuối) sẽ được ghép lại thành 1 file."
            VideoToolMode.EXTRACT_AUDIO -> "Để trống = tách toàn bộ audio. Nhập 1 đoạn = chỉ tách audio trong đoạn đó."
            else -> "1 dòng = Cắt lấy 1 đoạn (Trim). Nhiều dòng = Tách thành nhiều file (Split)."
        }
    }

    /**
     * Nếu người dùng đã kéo thanh trượt chọn 1 đoạn nhưng QUÊN bấm "Thêm đoạn đã chọn
     * vào danh sách" (dễ xảy ra, đúng lỗi đã báo: "chọn đoạn nhưng vẫn tách toàn bộ"),
     * tự động dùng đúng vị trí thanh trượt hiện tại làm đoạn xử lý — thay vì im lặng
     * coi là "không chọn gì" rồi xử lý toàn bộ video.
     */
    private fun getEffectiveSegments(): List<Pair<Double, Double>> {
        val rawText = binding.edtSegments.text.toString()
        if (rawText.isNotBlank()) return parseSegments(rawText)

        val values = binding.rangeSlider.values
        if (values.size < 2) return emptyList()
        val start = values.first()
        val end = values.last()
        // Chỉ coi là "có chọn đoạn" nếu khác biệt rõ so với toàn bộ video (tránh việc
        // slider ở đúng [0, duration] mặc định bị hiểu nhầm thành "có chọn đoạn").
        val isFullRange = start <= 0.05f && end >= videoDurationSec - 0.05f
        return if (isFullRange) emptyList() else listOf(start.toDouble() to end.toDouble())
    }

    /**
     * Callback tiến độ dùng cho trim/split/merge/tách audio/xoá đoạn giữa. FFmpegKit gọi
     * callback thống kê từ THREAD NỀN (không phải main thread), nên phải post qua
     * runOnUiThread trước khi đụng vào View, nếu không sẽ crash
     * (CalledFromWrongThreadException).
     */
    private fun updateRunProgress(percent: Int) {
        runOnUiThread {
            binding.progressBar.progress = percent
            binding.txtProgress.text = "Đang xử lý... $percent%"
        }
    }

    private fun runCurrentAction() {
        if (selectedFilePaths.isEmpty()) {
            Toast.makeText(this, "Vui lòng chọn video trước", Toast.LENGTH_SHORT).show()
            return
        }

        if (currentMode == VideoToolMode.COMPRESS) {
            runCompressBatch()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.progressBar.progress = 0
        binding.btnRun.isEnabled = false
        binding.txtResult.text = ""
        binding.txtProgress.text = "Đang xử lý..."

        lifecycleScope.launch {
            val outputDir = FileUtils.getOutputDir(this@VideoToolsActivity).absolutePath

            val result: VideoOpResult = when (currentMode) {
                VideoToolMode.TRIM_SPLIT -> {
                    val segments = getEffectiveSegments()
                    if (segments.isEmpty()) {
                        VideoOpResult(false, log = "Vui lòng kéo thanh trượt chọn 1 đoạn khác toàn bộ video (hoặc bấm 'Thêm đoạn' để tách nhiều đoạn)")
                    } else if (segments.size == 1) {
                        VideoEngine.trim(selectedFilePaths.first(), outputDir, segments[0].first, segments[0].second, ::updateRunProgress)
                    } else {
                        VideoEngine.split(selectedFilePaths.first(), outputDir, segments, ::updateRunProgress)
                    }
                }
                VideoToolMode.REMOVE_MIDDLE -> {
                    val segments = getEffectiveSegments()
                    if (segments.isEmpty()) {
                        VideoOpResult(false, log = "Vui lòng kéo thanh trượt chọn đoạn muốn xoá (khác toàn bộ video)")
                    } else {
                        VideoEngine.removeSegmentAndJoin(selectedFilePaths.first(), outputDir, segments[0].first, segments[0].second, videoDurationSec.toDouble(), ::updateRunProgress)
                    }
                }
                VideoToolMode.MERGE -> VideoEngine.merge(selectedFilePaths, outputDir, ::updateRunProgress)
                VideoToolMode.EXTRACT_AUDIO -> {
                    val segments = getEffectiveSegments()
                    when {
                        segments.isEmpty() -> VideoEngine.extractAudio(selectedFilePaths.first(), outputDir, ::updateRunProgress)
                        segments.size == 1 -> VideoEngine.extractAudioSegment(selectedFilePaths.first(), outputDir, segments[0].first, segments[0].second, ::updateRunProgress)
                        else -> VideoEngine.extractAudioMultipleSegments(selectedFilePaths.first(), outputDir, segments, ::updateRunProgress)
                    }
                }
                VideoToolMode.COMPRESS -> throw IllegalStateException("Đã xử lý riêng ở nhánh trên")
            }

            finishRun(result)
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val compressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                CompressService.ACTION_PROGRESS -> {
                    val fileIndex = intent.getIntExtra("fileIndex", 0)
                    val totalFiles = intent.getIntExtra("totalFiles", 1)
                    val percent = intent.getIntExtra("percent", 0)
                    val useHardware = intent.getBooleanExtra("useHardware", true)
                    val prefix = if (totalFiles > 1) "File ${fileIndex + 1}/$totalFiles: " else ""
                    binding.progressBar.progress = percent
                    binding.txtProgress.text = "$prefix$percent% (${if (useHardware) "phần cứng" else "phần mềm"})"
                }
                CompressService.ACTION_COMPLETE -> {
                    val success = intent.getBooleanExtra("success", false)
                    val outputPaths = intent.getStringArrayListExtra("outputPaths") ?: arrayListOf()
                    val log = intent.getStringExtra("log") ?: ""
                    finishRun(VideoOpResult(success, outputPaths, log))
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        DebugLog.log(this, "VideoToolsActivity", "onStart() — isRunning=${CompressService.CompressResultHolder.isRunning}, lastResult=${if (CompressService.CompressResultHolder.lastResult != null) "có" else "null"}")
        val filter = IntentFilter().apply {
            addAction(CompressService.ACTION_PROGRESS)
            addAction(CompressService.ACTION_COMPLETE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(compressReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(compressReceiver, filter)
        }

        // Đồng bộ lại UI nếu Service đã chạy xong (hoặc đang chạy) trong lúc app ở nền
        if (CompressService.CompressResultHolder.isRunning) {
            binding.progressBar.visibility = View.VISIBLE
            binding.btnRun.isEnabled = false
            binding.btnCancelRunning.visibility = View.VISIBLE
            binding.txtProgress.text = "Đang nén ở chế độ nền... (mở thông báo để xem chi tiết)"
            // FIX: trước đây dòng "Chưa chọn video nào" (do selectedFilePaths bị reset
            // khi Activity tạo lại) khiến người dùng tưởng NHẦM là file đã mất, dù
            // Service vẫn đang xử lý đúng file đó — giờ hiện rõ tên file thật đang nén.
            val runningNames = CompressService.CompressResultHolder.runningFileNames
            if (runningNames.isNotEmpty()) {
                binding.txtSelectedFiles.text = "Đang nén (chạy nền): " + runningNames.joinToString(", ")
            }
        } else {
            binding.btnCancelRunning.visibility = View.GONE
            val inMemoryResult = CompressService.CompressResultHolder.lastResult
            if (inMemoryResult != null) {
                finishRun(inMemoryResult)
                CompressService.CompressResultHolder.lastResult = null
            } else {
                // FIX QUAN TRỌNG: nếu bản trong bộ nhớ (lastResult) đã bị Android xoá do
                // tiến trình app bị tắt SAU KHI compress xong (đúng lúc Service vừa
                // stopForeground() nên mất bảo vệ, rồi hệ thống thu hồi RAM) — bản trong
                // bộ nhớ mất, nhưng bản lưu trên đĩa (SharedPreferences) vẫn còn. Đây là
                // nguyên nhân của hiện tượng "thấy thông báo Nén thất bại/xong nhưng mở
                // app ra chả thấy gì" — giờ đọc từ đây như phương án dự phòng.
                CompressService.CompressResultStore.consumePending(applicationContext)?.let { persistedResult ->
                    finishRun(persistedResult)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        DebugLog.log(this, "VideoToolsActivity", "onStop()")
        try { unregisterReceiver(compressReceiver) } catch (e: Exception) { /* chưa đăng ký, bỏ qua */ }
    }

    /**
     * Luồng riêng cho Compress: dò phần cứng NHANH trên 1 đoạn ngắn trước (vài giây,
     * vẫn chạy trên lifecycleScope vì đây là thao tác nhanh) — sau đó GIAO VIỆC NÉN
     * THẬT cho Foreground Service, để tiến trình không bị huỷ khi rời app (đúng lỗi
     * đã gặp: "chuyển app khác thì nén dừng, không báo lỗi, quay lại thấy file hỏng").
     */
    private fun runCompressBatch() {
        // FIX: chặn từ phía UI luôn (không chỉ ở Service) — nếu đã có 1 tác vụ nén
        // đang chạy nền, báo rõ cho người dùng thay vì để họ tưởng nút "Chạy" không
        // phản ứng gì (Service giờ cũng tự chặn ở tầng dưới, xem CompressService,
        // nhưng chặn sớm ở đây giúp người dùng hiểu ngay lý do).
        if (CompressService.CompressResultHolder.isRunning) {
            Toast.makeText(this, "Đang có 1 tác vụ nén khác chạy nền — đợi xong rồi hẵng chạy tiếp.", Toast.LENGTH_LONG).show()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.progressBar.progress = 0
        binding.btnRun.isEnabled = false
        binding.txtResult.text = ""

        // QUYẾT ĐỊNH CẬP NHẬT (08/07/2026): bản đầu phiên này từng đổi mặc định sang
        // CHỈ dùng phần mềm để né vấn đề phình dung lượng — nhưng đó là né tránh, không
        // giải quyết yêu cầu gốc "phải chạy trên đúng chip video engine". Đã tìm ra và
        // sửa ĐÚNG GỐC RỄ trong VideoEngine.compressInternal(): đổi bitrate_mode từ 1
        // (VBR — được phép vượt bitrate mục tiêu ở cảnh phức tạp) sang 2 (CBR — ép cứng
        // bitrate đều suốt video). Giờ PHỤC HỒI phần cứng làm mặc định (đúng yêu cầu ban
        // đầu), phần mềm chỉ là lựa chọn thủ công dự phòng nếu người dùng tự bỏ tick.
        // Có thêm log chẩn đoán so sánh bitrate mục tiêu vs thật đạt được (xem
        // VideoEngine, tìm "[CHẨN ĐOÁN CBR]") để xác nhận CBR có thực sự khắc phục được
        // vấn đề hay chưa — xem qua nút "Xem / Gửi log debug".
        val useHardwareRequested = binding.checkboxUseHardware.isChecked

        lifecycleScope.launch {
            val preset = currentPreset()

            val useHardware = if (useHardwareRequested) {
                binding.txtProgress.text = "Đang kiểm tra khả năng mã hoá phần cứng..."
                val supported = VideoEngine.probeHardwareEncodeSupport(selectedFilePaths.first(), cacheDir)
                if (!supported) {
                    // Người dùng CHỦ ĐỘNG chọn phần cứng nhưng máy không hỗ trợ thật —
                    // đây là bất ngờ, nên vẫn cần hỏi xác nhận trước khi chạy phần mềm
                    // chậm hơn, khác với trường hợp mặc định (họ đã biết trước là chậm).
                    val totalDurationSec = selectedFilePaths.sumOf { FileUtils.getVideoDurationSec(it) }
                    val etaMinutes = (totalDurationSec / SOFTWARE_SPEED_FACTOR / 60).toInt().coerceAtLeast(1)
                    val proceed = confirmSoftwareFallback(etaMinutes)
                    if (!proceed) {
                        binding.progressBar.visibility = View.GONE
                        binding.btnRun.isEnabled = true
                        binding.txtProgress.text = ""
                        binding.txtResult.text = "Đã huỷ — máy không hỗ trợ phần cứng thật sự, chạy phần mềm sẽ mất khoảng $etaMinutes phút."
                        return@launch
                    }
                }
                supported
            } else {
                // Mặc định: phần mềm — người dùng đã biết trước qua checkbox và ước tính
                // dung lượng hiển thị sẵn trên màn hình, không cần hỏi xác nhận lại nữa.
                false
            }

            binding.txtProgress.text = "Đang chạy ở chế độ nền (${if (useHardware) "phần cứng" else "phần mềm"})... có thể rời app, sẽ có thông báo khi xong."
            binding.btnCancelRunning.visibility = View.VISIBLE

            // FIX: ghi lại tên file đang gửi đi nén nền — để nếu Activity bị tạo lại
            // (màn hình tắt/bật, rời app...) và selectedFilePaths bị reset về rỗng,
            // UI vẫn có thể hiện đúng "Đang nén: X" thay vì "Chưa chọn video nào".
            CompressService.CompressResultHolder.runningFileNames = selectedFilePaths.map { File(it).name }

            val serviceIntent = Intent(this@VideoToolsActivity, CompressService::class.java).apply {
                putStringArrayListExtra(CompressService.EXTRA_INPUT_PATHS, ArrayList(selectedFilePaths))
                putExtra(CompressService.EXTRA_PRESET_ORDINAL, preset.ordinal)
                putExtra(CompressService.EXTRA_USE_HARDWARE, useHardware)
            }
            ContextCompat.startForegroundService(this@VideoToolsActivity, serviceIntent)
        }
    }

    private suspend fun confirmSoftwareFallback(etaMinutes: Int): Boolean = kotlinx.coroutines.suspendCancellableCoroutine { cont ->
        AlertDialog.Builder(this)
            .setTitle("Máy không hỗ trợ mã hoá phần cứng")
            .setMessage("Sẽ chạy bằng phần mềm (CPU) — ước tính mất khoảng $etaMinutes phút, có thể làm nóng máy. Bạn có muốn tiếp tục không?")
            .setPositiveButton("Tiếp tục") { _, _ -> cont.resumeWith(Result.success(true)) }
            .setNegativeButton("Huỷ") { _, _ -> cont.resumeWith(Result.success(false)) }
            .setCancelable(false)
            .show()
    }

    /**
     * Hiện toàn bộ nội dung log debug đã ghi (xem `DebugLog.kt`) trong 1 hộp thoại, kèm
     * nút "Chia sẻ" để gửi thẳng qua Messenger/Zalo/Gmail/... — thay thế việc phải chụp
     * màn hình nhiều lần (dễ thiếu thông tin, dễ đoán sai nguyên nhân lỗi).
     */
    private fun showDebugLogDialog() {
        val logContent = DebugLog.readAll(applicationContext)
        AlertDialog.Builder(this)
            .setTitle("Log debug (${logContent.lines().size} dòng)")
            .setMessage(if (logContent.length > 6000) "...(cắt bớt, xem đầy đủ khi Chia sẻ)...\n" + logContent.takeLast(6000) else logContent)
            .setPositiveButton("Chia sẻ") { _, _ ->
                try {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, logContent)
                        putExtra(Intent.EXTRA_SUBJECT, "VideoAIStudio debug log")
                    }
                    startActivity(Intent.createChooser(shareIntent, "Gửi log debug"))
                } catch (e: Exception) {
                    Toast.makeText(this, "Không chia sẻ được: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNeutralButton("Xoá log") { _, _ ->
                DebugLog.clear(applicationContext)
                Toast.makeText(this, "Đã xoá log debug", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun finishRun(result: VideoOpResult) {
        binding.progressBar.visibility = View.GONE
        binding.btnRun.isEnabled = true
        binding.txtProgress.text = ""

        // FIX QUAN TRỌNG: trước đây khi result.success == true, result.log bị BỎ QUA
        // HOÀN TOÀN dù VideoEngine.compressWithKnownBackend có thể trả về success=true
        // KÈM cảnh báo "CẢNH BÁO: dung lượng sau nén không nhỏ hơn đáng kể so với gốc"
        // (trường hợp cả 2 đường phần cứng lẫn phần mềm đều không nén nhỏ đi được).
        // Vì UI chỉ hiện "Thành công!" nên người dùng không hề biết file gần như không
        // đổi dung lượng — đúng hiện tượng "chọn nén Vừa nhưng không có bất kỳ thay đổi
        // nào" mà không thấy báo lỗi gì. Giờ luôn hiện cảnh báo nếu log có chứa nó.
        val hasWarning = result.success && result.log.contains("CẢNH BÁO", ignoreCase = true)
        binding.txtResult.text = when {
            !result.success -> "Thất bại:\n${result.log}"
            hasWarning -> "Hoàn tất, NHƯNG CÓ CẢNH BÁO:\n${result.log}\n\nFile lưu tại:\n" + result.outputPaths.joinToString("\n")
            else -> "Thành công!\nFile lưu tại:\n" + result.outputPaths.joinToString("\n")
        }

        if (result.success && result.outputPaths.size == 1) {
            lastSingleOutputPath = result.outputPaths.first()
            binding.btnSaveAs.visibility = View.VISIBLE
            lastMultiOutputPaths = null
            binding.btnSaveAllAs.visibility = View.GONE
        } else if (result.success && result.outputPaths.size > 1) {
            // FIX: trước đây nhánh này chỉ hiện dòng disclaimer "chưa hỗ trợ Lưu vào tuỳ
            // chọn cho nhiều file" — đây chính là "lỗi lưu file" người dùng gặp khi tách
            // audio ra nhiều đoạn: file chỉ nằm trong thư mục riêng của app
            // (Android/data/com.videoaistudio.app/...), không có cách nào đưa ra ngoài.
            // Giờ hiện nút "Lưu TẤT CẢ file vào 1 thư mục..." để copy hết ra vị trí do
            // người dùng chọn (xem saveAllAsLauncher).
            lastSingleOutputPath = null
            binding.btnSaveAs.visibility = View.GONE
            lastMultiOutputPaths = result.outputPaths
            binding.btnSaveAllAs.visibility = View.VISIBLE
        } else {
            lastSingleOutputPath = null
            binding.btnSaveAs.visibility = View.GONE
            lastMultiOutputPaths = null
            binding.btnSaveAllAs.visibility = View.GONE
        }
    }

    /**
     * Parse "start,end" mỗi dòng thành cặp (giây, giây).
     *
     * FIX: chịu được trường hợp người dùng tự gõ tay số thập phân bằng DẤU PHẨY
     * (thói quen bàn phím tiếng Việt, vd "10,5,20,3" nghĩa là 10.5 và 20.3) thay vì
     * dùng nút "Thêm đoạn đã chọn" (nút đó đã ép Locale.US ra dấu chấm, xem
     * addSelectedRangeToList). Trước đây parts.size != 2 thì BỎ QUA CẢ DÒNG một cách
     * im lặng — khiến segments trống rỗng và app coi như "không chọn đoạn", dẫn tới
     * lấy nhầm toàn bộ video/audio. Giờ nếu tách theo dấu chấm ra đúng 2 phần thì dùng
     * luôn (chuẩn); nếu không, thử lại coi dấu phẩy đầu tiên trong mỗi số là thập phân.
     */
    private fun parseSegments(raw: String): List<Pair<Double, Double>> {
        return raw.lines()
            .mapNotNull { line ->
                val trimmedLine = line.trim()
                if (trimmedLine.isBlank()) return@mapNotNull null

                // Thử chuẩn trước: đúng 2 phần, mỗi phần là số hợp lệ (dấu chấm thập phân).
                val standardParts = trimmedLine.split(",")
                if (standardParts.size == 2) {
                    val start = standardParts[0].trim().toDoubleOrNull()
                    val end = standardParts[1].trim().toDoubleOrNull()
                    if (start != null && end != null && end > start) return@mapNotNull start to end
                }

                // Rớt về đây nghĩa là split(",") không cho đúng 2 số hợp lệ — khả năng cao
                // là số thập phân dùng dấu phẩy (vd 4 phần "10,5,20,3"). Thử ghép lại theo
                // quy tắc: có đúng 4 phần và tất cả đều là số nguyên -> ghép phần 1-2 thành
                // 1 số thập phân (start), phần 3-4 thành 1 số thập phân (end).
                if (standardParts.size == 4 && standardParts.all { it.trim().toIntOrNull() != null }) {
                    val start = "${standardParts[0].trim()}.${standardParts[1].trim()}".toDoubleOrNull()
                    val end = "${standardParts[2].trim()}.${standardParts[3].trim()}".toDoubleOrNull()
                    if (start != null && end != null && end > start) return@mapNotNull start to end
                }

                null
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
        FileUtils.clearVideoInputCache(applicationContext)
    }

    companion object {
        const val EXTRA_MODE = "extra_mode"
        // Tốc độ mã hoá phần mềm quan sát được thực tế (speed=0.3x trong log FFmpeg
        // của chính người dùng) — dùng để ước tính thời gian trước khi chạy.
        private const val SOFTWARE_SPEED_FACTOR = 0.3
    }
}
