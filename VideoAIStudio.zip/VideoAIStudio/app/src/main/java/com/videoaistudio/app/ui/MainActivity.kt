package com.videoaistudio.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.videoaistudio.app.databinding.ActivityMainBinding
import com.videoaistudio.app.inference.InferenceManager

/**
 * Màn hình chính chỉ điều hướng tới từng tính năng.
 * Các thao tác video (trim/split/merge/tách audio/tách phụ đề/nén) đều trỏ vào
 * VideoToolsActivity, chỉ khác chế độ khởi tạo ban đầu — Trim và Split đã được gộp
 * thành 1 (TRIM_SPLIT) vì bản chất cùng là "cắt theo mốc thời gian", chỉ khác số
 * lượng đoạn.
 *
 * 2 nút phụ đề (09/09/2026, cập nhật lại cùng ngày) — GOM CHUNG theo chủ đề "phụ đề"
 * chứ không theo việc tính năng đó dùng chung code với thao tác nào:
 *  - btnExtractSubtitle → EXTRACT_HARDSUB (tách phụ đề bằng OCR, đứng độc lập).
 *  - btnBurnSubtitle → vẫn mở TRIM_SPLIT (vì ghép phụ đề bắt buộc đi kèm chọn đoạn cắt,
 *    dùng lại đúng UI/logic đó), nhưng truyền thêm EXTRA_AUTO_BURN_SUBTITLE để
 *    VideoToolsActivity tự tick sẵn checkbox "Ghép cứng phụ đề" — người bấm nút này
 *    không cần tự biết checkbox nằm ở đâu bên trong màn hình Cắt/Tách.
 * Lưu ý: REMOVE_MIDDLE vẫn CHƯA có nút riêng ở đây, chỉ chọn được qua spinnerMode.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var inferenceManager: InferenceManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inferenceManager = InferenceManager(applicationContext)

        binding.btnTrimCut.setOnClickListener { openVideoTools(VideoToolMode.TRIM_SPLIT) }
        binding.btnMerge.setOnClickListener { openVideoTools(VideoToolMode.MERGE) }
        binding.btnExtractAudio.setOnClickListener { openVideoTools(VideoToolMode.EXTRACT_AUDIO) }
        binding.btnBurnSubtitle.setOnClickListener {
            openVideoTools(VideoToolMode.TRIM_SPLIT, autoBurnSubtitle = true)
        }
        binding.btnExtractSubtitle.setOnClickListener { openVideoTools(VideoToolMode.EXTRACT_HARDSUB) }
        binding.btnCompress.setOnClickListener { openVideoTools(VideoToolMode.COMPRESS) }

        binding.btnUpscale.setOnClickListener {
            startActivity(Intent(this, UpscaleActivity::class.java))
        }
        binding.btnObjectExtract.setOnClickListener {
            startActivity(Intent(this, ObjectExtractActivity::class.java))
        }

        binding.btnModelSettings.setOnClickListener {
            startActivity(Intent(this, ModelSettingsActivity::class.java))
        }
    }

    private fun openVideoTools(mode: VideoToolMode, autoBurnSubtitle: Boolean = false) {
        val intent = Intent(this, VideoToolsActivity::class.java)
        intent.putExtra(VideoToolsActivity.EXTRA_MODE, mode.name)
        if (autoBurnSubtitle) {
            intent.putExtra(VideoToolsActivity.EXTRA_AUTO_BURN_SUBTITLE, true)
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        inferenceManager.releaseAll()
    }
}
