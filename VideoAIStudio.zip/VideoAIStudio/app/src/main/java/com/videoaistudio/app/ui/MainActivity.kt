package com.videoaistudio.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.videoaistudio.app.databinding.ActivityMainBinding
import com.videoaistudio.app.inference.InferenceManager

/**
 * Màn hình chính chỉ điều hướng tới từng tính năng.
 * Các thao tác video (trim/split/merge/tách audio/nén) đều trỏ vào VideoToolsActivity,
 * chỉ khác chế độ khởi tạo ban đầu — Trim và Split đã được gộp thành 1 (TRIM_SPLIT)
 * vì bản chất cùng là "cắt theo mốc thời gian", chỉ khác số lượng đoạn.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var inferenceManager: InferenceManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inferenceManager = InferenceManager(applicationContext)

        binding.btnTrimCut.setOnClickListener { openVideoTools(VideoToolMode.TRIM_SPLIT) }
        binding.btnMerge.setOnClickListener { openVideoTools(VideoToolMode.MERGE) }
        binding.btnExtractAudio.setOnClickListener { openVideoTools(VideoToolMode.EXTRACT_AUDIO) }
        binding.btnCompress.setOnClickListener { openVideoTools(VideoToolMode.COMPRESS) }

        binding.btnUpscale.setOnClickListener {
            startActivity(Intent(this, UpscaleActivity::class.java))
        }
        binding.btnObjectExtract.setOnClickListener {
            startActivity(Intent(this, ObjectExtractActivity::class.java))
        }

        binding.btnModelSettings.setOnClickListener {
            startActivity(Intent(this, ModelSettingsActivity::class.java))
        }
    }

    private fun openVideoTools(mode: VideoToolMode) {
        val intent = Intent(this, VideoToolsActivity::class.java)
        intent.putExtra(VideoToolsActivity.EXTRA_MODE, mode.name)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        inferenceManager.releaseAll()
    }
}
