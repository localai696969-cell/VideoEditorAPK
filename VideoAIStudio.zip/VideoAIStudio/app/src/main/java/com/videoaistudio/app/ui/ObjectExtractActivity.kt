package com.videoaistudio.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.videoaistudio.app.databinding.ActivityObjectExtractBinding
import com.videoaistudio.app.inference.DetectionUtils
import com.videoaistudio.app.inference.ImageSharpness
import com.videoaistudio.app.inference.InferenceManager
import com.videoaistudio.app.inference.LocalModelProvider
import com.videoaistudio.app.inference.ModelConfig
import com.videoaistudio.app.inference.ProviderSource
import com.videoaistudio.app.inference.SimpleIouTracker
import com.videoaistudio.app.inference.TaskType
import com.videoaistudio.app.video.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Pipeline nhận diện + tách object THẬT:
 * lấy mẫu frame theo khoảng thời gian -> chạy detection (bất kỳ model YOLO-style nào,
 * số lớp tự đọc từ output model, tên lớp lấy từ file labels người dùng cung cấp)
 * -> NMS -> theo dõi IoU đơn giản xuyên suốt các frame mẫu -> lọc theo class người
 * dùng chọn -> lọc ảnh đủ nét -> lưu crop, sau đó copy ra thư mục người dùng chỉ định
 * (nếu có chọn) qua Storage Access Framework.
 *
 * Giới hạn thành thật (đã nói rõ với người dùng):
 * - Tracker chỉ là IoU đơn giản, KHÔNG phải Re-ID thật (không phân biệt được người
 *   này với người khác nếu bị che khuất rồi xuất hiện lại).
 * - Chỉ hỗ trợ họ model xuất output kiểu YOLOv8 (Ultralytics).
 * - Việc lọc theo class chỉ diễn ra SAU khi model đã chạy xong trên từng frame —
 *   không thể "bỏ qua" object không cần trước khi chạy model, vì phải chạy inference
 *   mới biết trong frame có gì. Lọc giúp giảm số ẢNH LƯU RA, không giảm được thời
 *   gian CHẠY MODEL trên từng frame.
 */
class ObjectExtractActivity : AppCompatActivity() {

    private lateinit var binding: ActivityObjectExtractBinding
    private lateinit var inferenceManager: InferenceManager
    private var configs: List<ModelConfig> = emptyList()
    private var selectedVideoPath: String? = null
    private var outputFolderUri: Uri? = null
    private val classCheckboxes = mutableListOf<CheckBox>()

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { importVideo(it) }
    }

    private val pickOutputFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let {
            contentResolver.takePersistableUriPermission(
                it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            outputFolderUri = it
            binding.txtOutputFolder.text = "Sẽ lưu vào: ${it.lastPathSegment ?: it.toString()}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityObjectExtractBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inferenceManager = InferenceManager(applicationContext)
        FileUtils.clearVideoInputCache(applicationContext)
        configs = inferenceManager.getAllConfigs().filter {
            it.taskType == TaskType.OBJECT_DETECTION && it.source == ProviderSource.LOCAL_MODEL
        }

        if (configs.isEmpty()) {
            Toast.makeText(this, "Chưa có model Object Detection local nào được cấu hình.", Toast.LENGTH_LONG).show()
        }

        binding.spinnerModel.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, configs.map { it.displayName }
        )
        updateLabelsInfo()
        binding.spinnerModel.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) = updateLabelsInfo()
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }

        binding.btnPickVideo.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        binding.btnPickOutputFolder.setOnClickListener { pickOutputFolder.launch(null) }
        binding.btnRun.setOnClickListener { runDetection() }
    }

    private fun currentConfig(): ModelConfig? = configs.getOrNull(binding.spinnerModel.selectedItemPosition)

    /** Đọc file labels (nếu có) và tạo checkbox cho từng class để người dùng chọn lọc. */
    private fun updateLabelsInfo() {
        val config = currentConfig()
        binding.containerClassCheckboxes.removeAllViews()
        classCheckboxes.clear()

        if (config?.labelsFilePath != null) {
            val labels = File(config.labelsFilePath).readLines().filter { it.isNotBlank() }
            binding.txtLabelsInfo.text = "Đã có file labels: ${labels.size} nhãn"
            for (label in labels) {
                val cb = CheckBox(this).apply { text = label }
                classCheckboxes.add(cb)
                binding.containerClassCheckboxes.addView(cb)
            }
        } else {
            binding.txtLabelsInfo.text = "Chưa có file labels — không lọc được theo tên lớp, sẽ tách TẤT CẢ (vào Cấu hình Model để thêm labels nếu muốn lọc)"
        }
    }

    /** Danh sách tên class được người dùng tick chọn. Rỗng = không lọc, tách tất cả. */
    private fun selectedClassNames(): Set<String> =
        classCheckboxes.filter { it.isChecked }.map { it.text.toString() }.toSet()

    private fun importVideo(uri: Uri) {
        try {
            val name = FileUtils.queryDisplayName(this, uri)
            val file = FileUtils.copyUriToCache(this, uri, name)
            selectedVideoPath = file.absolutePath
            binding.txtSelectedVideo.text = "Đã chọn: $name"
        } catch (e: Exception) {
            Toast.makeText(this, "Không đọc được video: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun runDetection() {
        val config = currentConfig()
        val videoPath = selectedVideoPath
        if (config == null || videoPath == null) {
            Toast.makeText(this, "Vui lòng chọn model và video trước", Toast.LENGTH_SHORT).show()
            return
        }
        val confThreshold = binding.edtConfThreshold.text.toString().toFloatOrNull() ?: 0.5f
        val sampleInterval = binding.edtSampleInterval.text.toString().toDoubleOrNull() ?: 1.0
        val classFilter = selectedClassNames()

        val labels = config.labelsFilePath?.let { File(it).readLines().filter { l -> l.isNotBlank() } } ?: emptyList()

        binding.progressBar.visibility = android.view.View.VISIBLE
        binding.btnRun.isEnabled = false
        binding.txtResult.text = ""

        lifecycleScope.launch {
            val workDir = File(cacheDir, "detect_work_${System.currentTimeMillis()}")
            val framesDir = File(workDir, "samples")

            binding.txtProgress.text = "Đang lấy mẫu frame (mỗi ${sampleInterval}s)..."
            val fps = 1.0 / sampleInterval
            val sampleResult = withContext(Dispatchers.IO) { sampleFrames(videoPath, framesDir, fps) }
            if (!sampleResult) {
                finishWithError("Lấy mẫu frame thất bại")
                return@launch
            }

            val frameFiles = framesDir.listFiles { f -> f.extension == "png" }?.sortedBy { it.name } ?: emptyList()
            if (frameFiles.isEmpty()) {
                finishWithError("Không lấy được frame mẫu nào")
                return@launch
            }

            val outputDir = File(FileUtils.getOutputDir(this@ObjectExtractActivity), "objects_${System.currentTimeMillis()}")
            outputDir.mkdirs()

            val provider = LocalModelProvider(applicationContext, config)

            // TÍNH NĂNG MỚI (08/07/2026): kiểm tra tương thích model NGAY TRÊN FRAME ĐẦU
            // TIÊN, trước khi xử lý toàn bộ video — giống cách UpscaleActivity đã làm
            // (detectUpscaleModelSpec chạy thử ảnh giả trước). Trước đây model không
            // tương thích (shape output không đúng chuẩn YOLOv8-style) chỉ bị phát hiện
            // SAU KHI đã xử lý xong toàn bộ frame mẫu của cả video — lãng phí thời gian,
            // và thông báo lỗi cuối cùng ("không tìm thấy object nào") dễ khiến người
            // dùng tưởng nhầm là do video không có gì đáng tách, chứ không phải do model
            // sai định dạng.
            binding.txtProgress.text = "Đang kiểm tra tương thích model..."
            val firstFrameBitmap = BitmapFactory.decodeFile(frameFiles.first().absolutePath)
            val compatCheck = firstFrameBitmap?.let { bmp ->
                withContext(Dispatchers.Default) {
                    val raw = provider.runRawDetection(bmp)
                    bmp.recycle()
                    raw
                }
            }
            val compatNumFeatures = compatCheck?.second?.getOrNull(1)?.toInt() ?: -1
            if (compatCheck == null || compatNumFeatures - 4 <= 0) {
                finishWithError(
                    "Model không tương thích: output không đúng định dạng YOLOv8-style " +
                    "mà tính năng này hỗ trợ (cần shape dạng [1, 4+số_lớp, số_box]). " +
                    "Kiểm tra lại file .onnx đã chọn, hoặc thử model khác."
                )
                return@launch
            }

            val tracker = SimpleIouTracker()
            var savedCount = 0
            var numClassesDetected = -1
            val savedFiles = mutableListOf<File>()

            withContext(Dispatchers.Default) {
                for ((frameIdx, frameFile) in frameFiles.withIndex()) {
                    val bitmap = BitmapFactory.decodeFile(frameFile.absolutePath) ?: continue
                    val rawResult = provider.runRawDetection(bitmap)
                    if (rawResult == null) {
                        bitmap.recycle()
                        continue
                    }
                    val (flatArray, outShape) = rawResult
                    val numFeatures = outShape.getOrNull(1)?.toInt() ?: continue
                    val numBoxes = outShape.getOrNull(2)?.toInt() ?: continue
                    val numClasses = numFeatures - 4
                    if (numClasses <= 0) continue
                    numClassesDetected = numClasses
                    val inputSize = provider.getSquareInputSize()

                    val detections = DetectionUtils.decodeYoloV8Style(
                        flatArray, numClasses, numBoxes, confThreshold, bitmap.width, bitmap.height, inputSize
                    )
                    val afterNms = DetectionUtils.nms(detections)
                    val tracked = tracker.update(afterNms)

                    for ((box, trackId) in tracked) {
                        val label = labels.getOrNull(box.classId) ?: "class_${box.classId}"

                        // Lọc theo class người dùng chọn — bỏ trống checkbox nghĩa là lấy tất cả
                        if (classFilter.isNotEmpty() && label !in classFilter) continue

                        val cropped = cropSafe(bitmap, box) ?: continue
                        val sharpness = ImageSharpness.computeScore(cropped)

                        if (sharpness < MIN_SHARPNESS_SCORE) {
                            cropped.recycle()
                            continue
                        }

                        val classDir = File(outputDir, "${label}_track$trackId").apply { mkdirs() }
                        val outFile = File(classDir, "frame${frameIdx}_${"%.0f".format(java.util.Locale.US, box.confidence * 100)}pct.jpg")
                        outFile.outputStream().use { out -> cropped.compress(Bitmap.CompressFormat.JPEG, 92, out) }
                        cropped.recycle()
                        savedFiles.add(outFile)
                        savedCount++
                    }
                    bitmap.recycle()

                    withContext(Dispatchers.Main) {
                        binding.progressBar.max = frameFiles.size
                        binding.progressBar.progress = frameIdx + 1
                        binding.txtProgress.text = "Đã xử lý ${frameIdx + 1} / ${frameFiles.size} frame mẫu, lưu được $savedCount ảnh"
                    }
                }
            }
            provider.release()
            workDir.deleteRecursively()

            var finalLocationNote = outputDir.absolutePath
            val folderUri = outputFolderUri
            if (savedCount > 0 && folderUri != null) {
                binding.txtProgress.text = "Đang copy ảnh ra thư mục đã chọn..."
                val copiedOk = withContext(Dispatchers.IO) { copyFilesToTree(savedFiles, outputDir, folderUri) }
                if (copiedOk) {
                    finalLocationNote = "thư mục bạn đã chọn"
                    outputDir.deleteRecursively() // đã copy ra ngoài xong, dọn bản trong app tránh trùng dung lượng
                } else {
                    finalLocationNote = "${outputDir.absolutePath}\n(Copy ra thư mục đã chọn thất bại, ảnh vẫn còn trong bộ nhớ app)"
                }
            }

            binding.progressBar.visibility = android.view.View.GONE
            binding.btnRun.isEnabled = true

            binding.txtResult.text = if (savedCount > 0) {
                "Hoàn tất! Đã lưu $savedCount ảnh object vào:\n$finalLocationNote\n" +
                (if (numClassesDetected > 0 && labels.size != numClassesDetected)
                    "\nLưu ý: model có $numClassesDetected lớp nhưng file labels có ${labels.size} dòng — tên lớp có thể không khớp, kiểm tra lại file labels."
                 else "")
            } else {
                "Không tìm thấy object nào đạt ngưỡng tự tin/độ nét/loại đã chọn. Thử giảm ngưỡng tự tin, bỏ chọn lọc class, hoặc kiểm tra model."
            }
        }
    }

    /** Copy toàn bộ file/thư mục con từ outputDir (bộ nhớ app) ra thư mục người dùng chọn qua SAF. */
    private fun copyFilesToTree(savedFiles: List<File>, baseDir: File, targetTreeUri: Uri): Boolean {
        return try {
            val targetRoot = DocumentFile.fromTreeUri(this, targetTreeUri) ?: return false
            for (file in savedFiles) {
                val relativeDir = file.parentFile?.name ?: "objects"
                var subDir = targetRoot.findFile(relativeDir)
                if (subDir == null || !subDir.isDirectory) {
                    subDir = targetRoot.createDirectory(relativeDir) ?: continue
                }
                val destDoc = subDir.createFile("image/jpeg", file.nameWithoutExtension) ?: continue
                contentResolver.openOutputStream(destDoc.uri)?.use { out ->
                    file.inputStream().use { input -> input.copyTo(out) }
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun cropSafe(bitmap: Bitmap, box: com.videoaistudio.app.inference.DetectionBox): Bitmap? {
        val padding = 8
        val x1 = (box.x1 - padding).toInt().coerceIn(0, bitmap.width - 1)
        val y1 = (box.y1 - padding).toInt().coerceIn(0, bitmap.height - 1)
        val x2 = (box.x2 + padding).toInt().coerceIn(x1 + 1, bitmap.width)
        val y2 = (box.y2 + padding).toInt().coerceIn(y1 + 1, bitmap.height)
        return try {
            Bitmap.createBitmap(bitmap, x1, y1, x2 - x1, y2 - y1)
        } catch (e: Exception) {
            null
        }
    }

    private fun sampleFrames(inputPath: String, outDir: File, fps: Double): Boolean {
        outDir.mkdirs()
        val pattern = File(outDir, "frame_%06d.png").absolutePath
        val cmd = "-y -i \"$inputPath\" -vf fps=$fps \"$pattern\""
        val session = com.arthenica.ffmpegkit.FFmpegKit.execute(cmd)
        return com.arthenica.ffmpegkit.ReturnCode.isSuccess(session.returnCode)
    }

    private fun finishWithError(message: String) {
        binding.progressBar.visibility = android.view.View.GONE
        binding.btnRun.isEnabled = true
        binding.txtResult.text = message
    }

    companion object {
        private const val MIN_SHARPNESS_SCORE = 15.0
    }
}
