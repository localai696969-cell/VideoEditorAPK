package com.videoaistudio.app.inference

/**
 * Interface chung cho MỌI nguồn chạy AI — đây là "chìa khoá" của toàn bộ kiến trúc
 * "không hardcode model/API". Dù là model local (.tflite/.onnx) hay gọi API cloud,
 * phần code gọi ra bên ngoài (VideoEngine, UI) chỉ biết tới interface này,
 * không cần quan tâm bên dưới là gì.
 *
 * => Muốn thêm 1 nguồn model mới (vd: model dạng .pte, hoặc API khác)
 *    chỉ cần viết thêm 1 class implement interface này, không sửa code cũ.
 */
interface IInferenceProvider {

    /** Model/API này có sẵn sàng chạy không (đã load xong, hoặc network ok). */
    suspend fun isReady(): Boolean

    /** Chạy inference, trả kết quả thống nhất theo InferenceOutput. */
    suspend fun runInference(input: InferenceInput): InferenceOutput

    /** Giải phóng tài nguyên (đóng model, đóng kết nối...). */
    fun release()
}
