# Video AI Studio — Phase 1 (Kiến trúc khung)

Đây là bộ khung (skeleton) cho app chỉnh sửa video + AI trên Android, thiết kế để dễ mở
rộng thêm tính năng (upscale, nhận diện object, tạo ảnh động...) mà không phải viết lại
kiến trúc mỗi lần thêm model mới.

## Đã có trong Phase 1
- Cấu trúc project Gradle chuẩn, build ra APK cài được lên điện thoại (test trên Zenfone 8).
- Kiến trúc chọn model **local hoặc API** hoàn toàn do người dùng cấu hình
  (`inference/ModelConfig.kt`, `InferenceManager.kt`), không hardcode bất kỳ model/API nào.
- `LocalModelProvider`: khung load model `.tflite`, hỗ trợ chọn chạy CPU / GPU / NNAPI
  (route qua NPU nếu thiết bị hỗ trợ).
- `ApiProvider`: khung gọi API bất kỳ do người dùng nhập endpoint + API key.
- Màn hình chính liệt kê các tính năng, màn hình "Cấu hình Model" để khai báo model.

## Chưa có (sẽ làm ở các phase sau)
- Logic xử lý video thật (FFmpeg: trim/split/merge/tách audio/nén).
- Logic tiền xử lý/hậu xử lý cho từng loại model AI cụ thể (upscale, detect object...).
- Pipeline nhận diện + tách ảnh object theo nhiều góc độ.

## Cách build APK KHÔNG CẦN máy tính (dùng GitHub Actions)

1. Tạo tài khoản GitHub (miễn phí) nếu chưa có: https://github.com/signup
2. Tạo 1 repository mới (ví dụ tên `video-ai-studio`), để **Private** hoặc **Public** tuỳ bạn.
3. Upload toàn bộ nội dung thư mục này lên repo đó. Có thể làm ngay trên web GitHub:
   - Vào repo → nút **"Add file" → "Upload files"** → kéo thả toàn bộ file/thư mục vào.
   - Nhấn **Commit changes**.
4. Vào tab **Actions** của repo → sẽ thấy workflow **"Build Debug APK"** tự động chạy
   (vì đã cấu hình chạy khi có commit vào nhánh `main`).
5. Đợi vài phút cho tới khi thấy dấu ✅ màu xanh.
6. Bấm vào lần chạy đó → kéo xuống mục **Artifacts** → tải file
   `video-ai-studio-debug-apk` về điện thoại.
7. Trên điện thoại: bật "Cài đặt ứng dụng không rõ nguồn gốc" (Install unknown apps) cho
   trình duyệt/File Manager, rồi mở file APK vừa tải để cài.

Toàn bộ quá trình build diễn ra trên máy chủ GitHub — bạn chỉ cần điện thoại/trình duyệt,
không cần PC hay Android Studio.

## Bước tiếp theo
Sau khi xác nhận Phase 1 build & cài thành công, các phase sau sẽ bổ sung dần từng tính năng
theo đúng interface đã dựng sẵn ở đây (không phải sửa lại kiến trúc gốc).
